/**
 * Updater Service — Client-side update checking for unpacked extension installs.
 *
 * Since BYOM machines are not domain-joined, Chrome disables off-store policy
 * installs (DISABLE_NOT_VERIFIED). This service lets the extension check for
 * updates itself and, when the user clicks "Update Now", delegate the file
 * write/extract operation to a Native Messaging host.
 */

const UPDATE_URL = 'https://hokagez.github.io/extension-update-pipeline/update.xml';
const PUBLIC_ZIP_URL = 'https://hokagez.github.io/extension-update-pipeline/extension.zip';
const RELEASES_API = 'https://api.github.com/repos/HokageZ/hungerstation-fraud-detection/releases/latest';
const NATIVE_HOST_NAME = 'com.hungerstation.fd_updater';
const UPDATE_CHECK_INTERVAL_MS = 2 * 60 * 60 * 1000; // 2 hours

let latestVersion = null;
let latestZipUrl = PUBLIC_ZIP_URL;
let releaseNotes = null;
let updateAvailable = false;
let updateCheckTimer = null;

function getCurrentVersion() {
  try {
    return chrome.runtime.getManifest().version;
  } catch (_) {
    return '0.0.0';
  }
}

function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

async function fetchUpdateManifest() {
  const res = await fetch(UPDATE_URL, { cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const xml = await res.text();
  const match = xml.match(/<updatecheck[^>]+version=["']([^"']+)["']/i);
  if (!match || !match[1]) throw new Error('version not found in update.xml');
  return match[1].trim();
}

async function fetchLatestReleaseInfo(version) {
  try {
    const res = await fetch(RELEASES_API, { cache: 'no-store' });
    if (!res.ok) return null;
    const data = await res.json();
    const zipAsset = (data.assets || []).find(a => a.name === 'extension.zip');
    return {
      tagName: data.tag_name,
      name: data.name,
      body: data.body,
      publishedAt: data.published_at,
      zipUrl: zipAsset ? zipAsset.browser_download_url : null
    };
  } catch (_) {
    return null;
  }
}

async function checkForUpdates({ notify = true } = {}) {
  try {
    const current = getCurrentVersion();
    const remote = await fetchUpdateManifest();

    latestVersion = remote;
    latestZipUrl = PUBLIC_ZIP_URL;
    updateAvailable = compareVersions(remote, current) > 0;

    // Try to fetch release notes from GitHub API. This will fail if the
    // repository is private, so we silently ignore errors and just show the
    // version number. The actual update ZIP is always served from the public
    // GitHub Pages pipeline.
    let info = null;
    if (updateAvailable) {
      info = await fetchLatestReleaseInfo(remote);
      releaseNotes = info && info.body ? info.body : '';
    }

    if (notify) {
      sendUpdateStatus({
        type: 'UPDATE_AVAILABLE',
        payload: {
          current,
          latest: remote,
          hasUpdate: updateAvailable,
          zipUrl: latestZipUrl,
          releaseNotes: releaseNotes || '',
          publishedAt: info ? info.publishedAt : null
        }
      });
    }

    return {
      current,
      latest: remote,
      hasUpdate: updateAvailable,
      zipUrl: latestZipUrl,
      releaseNotes: releaseNotes || '',
      error: null
    };
  } catch (err) {
    if (notify) {
      sendUpdateStatus({
        type: 'UPDATE_CHECK_ERROR',
        payload: { error: err.message }
      });
    }
    return { error: err.message, hasUpdate: false };
  }
}

function sendUpdateStatus(msg) {
  // Provided by background.js. Dashboard and sidepanel both connect on the
  // 'dashboard' port, so a single broadcast reaches both UIs.
  if (typeof self.sendToDashboard === 'function') {
    self.sendToDashboard(msg);
  }
}

function startUpdateChecker() {
  if (updateCheckTimer) clearInterval(updateCheckTimer);
  // Run once shortly after startup, then periodically
  setTimeout(() => checkForUpdates({ notify: true }), 30 * 1000);
  updateCheckTimer = setInterval(() => checkForUpdates({ notify: true }), UPDATE_CHECK_INTERVAL_MS);
}

function stopUpdateChecker() {
  if (updateCheckTimer) {
    clearInterval(updateCheckTimer);
    updateCheckTimer = null;
  }
}

/**
 * Trigger the update via Native Messaging host.
 * The host downloads extension.zip and extracts it over the extension folder,
 * then we call chrome.runtime.reload() to apply the new code.
 */
function triggerUpdate() {
  return new Promise((resolve, reject) => {
    if (!latestZipUrl || !latestVersion) {
      reject(new Error('No update available'));
      return;
    }

    let port;
    try {
      port = chrome.runtime.connectNative(NATIVE_HOST_NAME);
    } catch (err) {
      reject(new Error('Native Messaging host not found. Run install-updater.bat.'));
      return;
    }

    sendUpdateStatus({ type: 'UPDATE_PROGRESS', payload: { message: 'Connecting to updater...', percent: 10 } });

    const message = {
      action: 'update',
      version: latestVersion,
      url: latestZipUrl,
      extensionId: chrome.runtime.id
    };

    let resolved = false;
    const timeout = setTimeout(() => {
      if (resolved) return;
      resolved = true;
      try { port.disconnect(); } catch (_) {}
      sendUpdateStatus({ type: 'UPDATE_ERROR', payload: { error: 'Updater timed out after 60 seconds' } });
      reject(new Error('Updater timed out'));
    }, 60000);

    port.onMessage.addListener((response) => {
      if (resolved) return;
      if (response && response.status === 'ok') {
        resolved = true;
        clearTimeout(timeout);
        sendUpdateStatus({ type: 'UPDATE_PROGRESS', payload: { message: 'Update applied. Reloading extension...', percent: 100 } });
        sendUpdateStatus({ type: 'UPDATE_COMPLETE', payload: { version: latestVersion } });
        resolve(response);
        // Give the host time to finish writing before reload.
        setTimeout(() => chrome.runtime.reload(), 1500);
      } else {
        resolved = true;
        clearTimeout(timeout);
        try { port.disconnect(); } catch (_) {}
        const error = response && response.error ? response.error : 'Update failed';
        sendUpdateStatus({ type: 'UPDATE_ERROR', payload: { error } });
        reject(new Error(error));
      }
    });

    port.onDisconnect.addListener(() => {
      if (resolved) return;
      resolved = true;
      clearTimeout(timeout);
      const lastErr = chrome.runtime.lastError;
      const error = lastErr ? lastErr.message : 'Native host disconnected unexpectedly';
      sendUpdateStatus({ type: 'UPDATE_ERROR', payload: { error } });
      reject(new Error(error));
    });

    try {
      port.postMessage(message);
      sendUpdateStatus({ type: 'UPDATE_PROGRESS', payload: { message: 'Downloading update...', percent: 30 } });
    } catch (err) {
      resolved = true;
      clearTimeout(timeout);
      sendUpdateStatus({ type: 'UPDATE_ERROR', payload: { error: err.message } });
      reject(err);
    }
  });
}

// Expose globals for background.js importScripts()
self.Updater = {
  getCurrentVersion,
  checkForUpdates,
  startUpdateChecker,
  stopUpdateChecker,
  triggerUpdate,
  get latestVersion() { return latestVersion; },
  get updateAvailable() { return updateAvailable; },
  get latestZipUrl() { return latestZipUrl; }
};
