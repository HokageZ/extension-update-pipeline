/**
 * Updater Service — Lightweight update notification for unpacked installs.
 *
 * The extension is distributed as an unpacked ZIP and updated by re-running
 * install.bat. This service only checks the public update.xml to notify the
 * dashboard/sidepanel when a newer version is available.
 */

const UPDATE_URL = 'https://hokagez.github.io/extension-update-pipeline/update.xml';
const INSTALL_BAT_URL = 'https://hokagez.github.io/extension-update-pipeline/install.bat';
const RELEASES_API = 'https://api.github.com/repos/HokageZ/hungerstation-fraud-detection/releases/latest';
const UPDATE_CHECK_INTERVAL_MS = 2 * 60 * 60 * 1000; // 2 hours

let latestVersion = null;
let releaseNotes = null;
let updateAvailable = false;
let updateCheckTimer = null;

function getCurrentVersion() {
  try {
    return chrome.runtime.getManifest().version;
  } catch (_) {
    return '0.0.0';
  }
}

function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

async function fetchUpdateManifest() {
  const res = await fetch(UPDATE_URL, { cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const xml = await res.text();
  const match = xml.match(/<updatecheck[^>]+version=["']([^"']+)["']/i);
  if (!match || !match[1]) throw new Error('version not found in update.xml');
  return match[1].trim();
}

async function fetchLatestReleaseInfo(version) {
  try {
    const res = await fetch(RELEASES_API, { cache: 'no-store' });
    if (!res.ok) return null;
    const data = await res.json();
    const zipAsset = (data.assets || []).find(a => a.name === 'extension.zip');
    return {
      tagName: data.tag_name,
      name: data.name,
      body: data.body,
      publishedAt: data.published_at,
      zipUrl: zipAsset ? zipAsset.browser_download_url : null
    };
  } catch (_) {
    return null;
  }
}

async function checkForUpdates({ notify = true } = {}) {
  try {
    const current = getCurrentVersion();
    const remote = await fetchUpdateManifest();

    latestVersion = remote;
    updateAvailable = compareVersions(remote, current) > 0;

    let info = null;
    if (updateAvailable) {
      info = await fetchLatestReleaseInfo(remote);
      releaseNotes = info && info.body ? info.body : '';
    }

    const result = {
      current,
      latest: remote,
      hasUpdate: updateAvailable,
      installBatUrl: INSTALL_BAT_URL,
      releaseNotes: releaseNotes || '',
      publishedAt: info ? info.publishedAt : null,
      error: null
    };

    if (notify) {
      sendUpdateStatus({ type: 'UPDATE_AVAILABLE', payload: result });
    }

    return result;
  } catch (err) {
    const result = { error: err.message, hasUpdate: false, installBatUrl: INSTALL_BAT_URL };
    if (notify) {
      sendUpdateStatus({ type: 'UPDATE_CHECK_ERROR', payload: result });
    }
    return result;
  }
}

function sendUpdateStatus(msg) {
  if (typeof self.sendToDashboard === 'function') {
    self.sendToDashboard(msg);
  }
}

function startUpdateChecker() {
  if (updateCheckTimer) clearInterval(updateCheckTimer);
  setTimeout(() => checkForUpdates({ notify: true }), 30 * 1000);
  updateCheckTimer = setInterval(() => checkForUpdates({ notify: true }), UPDATE_CHECK_INTERVAL_MS);
}

function stopUpdateChecker() {
  if (updateCheckTimer) {
    clearInterval(updateCheckTimer);
    updateCheckTimer = null;
  }
}

/**
 * Auto-update via Native Messaging has been removed. Unpacked extension installs
 * are updated by re-running install.bat, which downloads the latest ZIP and
 * extracts it over the extension folder. This function exists only to provide a
 * clear message if any old code calls it.
 */
function triggerUpdate() {
  return Promise.reject(new Error('Please re-run install.bat to update the extension.'));
}

self.Updater = {
  getCurrentVersion,
  checkForUpdates,
  startUpdateChecker,
  stopUpdateChecker,
  triggerUpdate,
  get installBatUrl() { return INSTALL_BAT_URL; },
  get latestVersion() { return latestVersion; },
  get updateAvailable() { return updateAvailable; }
};
