/**
 * Gemini Flash service
 * - Photo comparison for rider vs customer complaint photos (Check #4)
 */

const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

const FOCUS_QUESTIONS = {
  contradiction: 'Does the rider\'s delivery photo contradict the customer\'s complaint?',
  missing: 'The customer claims item(s) are missing or incomplete. Does the rider\'s delivery photo clearly show those item(s) present, contradicting the customer\'s claim?',
  wrong: 'The customer claims they received the wrong item or order. Do the rider and customer photos show clearly different items or orders, suggesting the customer\'s claim is false?',
  damaged: 'The customer claims the order arrived damaged or spilled. Does the rider\'s delivery photo show the order intact and undamaged, contradicting the damage claim?',
  quality: 'The customer claims a food quality issue. Based only on the customer\'s photo, is there NO visible quality problem that supports the complaint? If the photo is unclear or could be normal, say NEEDS_HUMAN_REVIEW.'
};

async function fetchImageAsBase64(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Image fetch failed: ${res.status}`);
  const blob = await res.blob();
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
  return dataUrl.split(',')[1];
}

async function callGeminiMultimodal(apiKey, model, textPrompt, imageUrls) {
  const url = `${GEMINI_BASE}/${model}:generateContent?key=${apiKey}`;
  const parts = [{ text: textPrompt }];

  for (const imageUrl of imageUrls) {
    const base64 = await fetchImageAsBase64(imageUrl);
    const mime = imageUrl.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
    parts.push({ inlineData: { mimeType: mime, data: base64 } });
  }

  const body = {
    contents: [{ role: 'user', parts }],
    generationConfig: { temperature: 0.0, maxOutputTokens: 10 }
  };

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Gemini API ${res.status}: ${text}`);
  }

  const json = await res.json();
  return json?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '';
}

function normalizeGeminiAnswer(answer) {
  const raw = String(answer || '').trim();
  const upper = raw.toUpperCase().replace(/[.,!?]/g, '');

  if (upper === 'YES' || /\bYES\b/.test(upper)) return { status: 'YES', reason: raw };
  if (upper === 'NO' || /\bNO\b/.test(upper)) return { status: 'NO', reason: raw };

  const reviewTerms = ['HUMAN', 'REVIEW', 'UNSURE', 'UNCLEAR', 'UNKNOWN', 'CANNOT', 'CANT', 'INSUFFICIENT', 'NOT ENOUGH'];
  if (reviewTerms.some(term => upper.includes(term))) {
    return { status: 'NEEDS_HUMAN_REVIEW', reason: raw };
  }

  return { status: 'NEEDS_HUMAN_REVIEW', reason: `Unclear Gemini response: ${raw}` };
}

/**
 * Compare photos based on complaint type and configured rules.
 * @param {Object} params
 * @param {string[]} params.riderPhotos
 * @param {string[]} params.customerPhotos
 * @param {string} params.complaintType
 * @param {string} [params.complaintRaw]
 * @param {string} params.focus - one of contradiction/missing/wrong/damaged/quality
 * @param {string} params.apiKey
 * @param {string} [params.model]
 * @returns {{ status: 'YES'|'NO'|'NEEDS_HUMAN_REVIEW', reason: string }}
 */
async function comparePhotos(params) {
  const {
    riderPhotos = [],
    customerPhotos = [],
    complaintType = 'unknown',
    complaintRaw = '',
    focus = 'contradiction',
    apiKey,
    model = 'gemini-2.0-flash'
  } = params;

  if (!apiKey) return { status: 'NEEDS_HUMAN_REVIEW', reason: 'No Gemini API key' };
  if (customerPhotos.length === 0) {
    return { status: 'NEEDS_HUMAN_REVIEW', reason: 'No customer photo(s) provided' };
  }
  if (focus !== 'quality' && riderPhotos.length === 0) {
    return { status: 'NEEDS_HUMAN_REVIEW', reason: 'No rider photo(s) provided' };
  }

  const focusQuestion = FOCUS_QUESTIONS[focus] || FOCUS_QUESTIONS.contradiction;
  const imageUrls = [];
  if (focus !== 'quality') imageUrls.push(...riderPhotos.slice(0, 3));
  imageUrls.push(...customerPhotos.slice(0, 3));

  const riderBlock = focus === 'quality' ? '' : `Rider delivery photo(s) attached first.`;
  const customerBlock = `Customer complaint photo(s) attached ${focus === 'quality' ? '' : 'after the rider photo(s)'}.`;

  const prompt = `You are investigating a food delivery fraud case. The customer is already suspected of fraud based on other signals. Be skeptical of the customer's claim.

Complaint type: ${complaintType}
Customer's complaint: ${complaintRaw || 'not provided'}

${riderBlock}
${customerBlock}

${focusQuestion}

You must reply with EXACTLY ONE of these words and nothing else:
YES — if the photo evidence contradicts the customer's claim (suggests the customer may be lying)
NO — if the photo evidence does NOT contradict the customer's claim
NEEDS_HUMAN_REVIEW — if you cannot decide, the images are unclear, or information is insufficient

One word only. No explanation. No punctuation.`;

  try {
    const answer = await callGeminiMultimodal(apiKey, model, prompt, imageUrls);
    return normalizeGeminiAnswer(answer);
  } catch (e) {
    return { status: 'NEEDS_HUMAN_REVIEW', reason: e.message };
  }
}

if (typeof module !== 'undefined') {
  module.exports = { comparePhotos, normalizeGeminiAnswer };
}

if (typeof self !== 'undefined') {
  self.comparePhotos = comparePhotos;
  self.normalizeGeminiAnswer = normalizeGeminiAnswer;
}
