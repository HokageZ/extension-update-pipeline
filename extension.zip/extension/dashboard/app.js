/**
 * Dashboard App — Tactical Telemetry Interface
 * Now runs as an extension page and talks directly to the background worker.
 */

let port = null;
let currentState = {};
let decisionLog = [];
let shiftStartTime = null;
let shiftInterval = null;
let consoleFilter = 'all';
let settingsPopulated = false;

// Built-in default note templates (Arabic) — used when user hasn't customized
const BUILTIN_NOTE_DEFAULTS = {
  rate: 'سجل سيء - عدد تعويضات عالية وشكاوي بالنسبة للطلبات الناجحه - اعتذار',
  same_day_frequency: 'سجل سيء تعويضات مرتفعه اخر فتره اعتذار',
  bulk_drinks: 'حساب جيد -كميه مشروبات - اعتذار',
  all_system_comps: 'سجل سئ تعويضات متكرره اعتذار',
  photo_mismatch: 'حساب العميل غير جيد بسبب تناقض صور التسليم مع شكوى العميل. تم الاعتذار.',
  blocked_device: 'سيئ على البوابة +مرتبط بحساب سيئ +اعتذار',
  new_account_abuse: 'حساب العميل غير جيد بسبب طلب تعويضات على حساب جديد. تم الاعتذار.',
  duplicate_order_comp: 'حساب العميل غير جيد بسبب تكرار التعويض لنفس الطلب. تم الاعتذار.',
  same_reason_pattern: 'سجل سئ تعويضات متكرره اعتذار',
  excessive_comp_ratio: 'سجل سيء - تعويضات مرتفعة اخر فتره - و شكاوي متكرره - اعتذار',
  connected_accounts: 'سجل سئ //مرتبط بحساب محظور// اعتذار'
};

/** Auto-resize a textarea to fit its content (min 1 row).
 *  Guards against scrollHeight == 0 when element is hidden (display:none),
 *  which would set height to 0px and make the textarea invisible. */
function autoResize(ta) {
  ta.style.height = 'auto';
  const sh = ta.scrollHeight;
  if (sh > 0) ta.style.height = sh + 'px';
}

/** Wire auto-resize on a textarea (input + initial). */
function wireAutoResize(ta) {
  ta.addEventListener('input', () => autoResize(ta));
  // Run once after paint so scrollHeight is accurate
  requestAnimationFrame(() => autoResize(ta));
}

// DOM
const $ = id => document.getElementById(id);
const systemStatus = $('systemStatus');
const shiftTimer = $('shiftTimer');
const modeSelect = $('modeSelect');
const pausePlayBtn = $('pausePlayBtn');
const stopScrapeBtn = $('stopScrapeBtn');
const skipBtn = $('skipBtn');

const confirmPanel = $('confirmPanel');
const confirmDetails = $('confirmDetails');
const confirmBtn = $('confirmBtn');
const overrideBtn = $('overrideBtn');
const confirmSkipBtn = $('confirmSkipBtn');
const phaseBadge = $('phaseBadge');
const ticketInfo = $('ticketInfo');
const logEntries = $('logEntries');
const logCount = $('logCount');
const consoleOutput = $('consoleOutput');
const clearConsoleBtn = $('clearConsoleBtn');
const saveSettingsBtn = $('saveSettingsBtn');
const pipelineBar = $('pipelineBar');
const onboardingPanel = $('onboardingPanel');
const throughputEl = $('throughput');

const investigateBtn = $('investigateBtn');
const caseInput = $('caseInput');
const caseHint = $('caseHint');

// Updates
const helpUpdateBadge = $('helpUpdateBadge');
const updateCurrentVersion = $('updateCurrentVersion');
const updateLatestVersion = $('updateLatestVersion');
const latestVersionPill = $('latestVersionPill');
const updateStatus = $('updateStatus');
const updateProgress = $('updateProgress');
const updateProgressFill = $('updateProgressFill');
const updateProgressText = $('updateProgressText');
const checkUpdateBtn = $('checkUpdateBtn');
const updateNowBtn = $('updateNowBtn');
const releaseNotesPanel = $('releaseNotesPanel');
const releaseNotesBody = $('releaseNotesBody');
const manualInstallNote = $('manualInstallNote');

let currentUpdateState = {
  current: null,
  latest: null,
  hasUpdate: false,
  checking: false,
  updating: false,
  error: null,
  releaseNotes: '',
  installBatUrl: 'https://hokagez.github.io/extension-update-pipeline/install.bat'
};

// Stats
const processedCount = $('processedCount');
const fraudCount = $('fraudCount');
const notFraudCount = $('notFraudCount');
const errorCount = $('errorCount');
const skippedCount = $('skippedCount');
const avgTime = $('avgTime');

let extensionConnected = false;

function updateSystemStatus() {
  systemStatus.className = 'system-status';
  if (!extensionConnected) {
    systemStatus.classList.add('awaiting');
    systemStatus.querySelector('.text').textContent = 'Awaiting Extension';
  } else {
    systemStatus.classList.add('ready');
    systemStatus.querySelector('.text').textContent = 'Extension Ready';
  }
}

// ===== EXTENSION MESSAGING =====

function connect() {
  if (port) {
    try { port.disconnect(); } catch (_) {}
  }
  port = chrome.runtime.connect({ name: 'dashboard' });

  port.onMessage.addListener((msg) => {
    extensionConnected = true;
    updateSystemStatus();
    updateOnboarding();
    handleMessage(msg);
  });

  port.onDisconnect.addListener(() => {
    port = null;
    extensionConnected = false;
    updateSystemStatus();
    updateOnboarding();
    consoleLog('warn', 'ext', 'Extension disconnected, retrying in 3s...');
    setTimeout(connect, 3000);
  });

  send({ type: 'GET_STATE' });
  send({ type: 'GET_LOG' });
}

function send(msg) {
  try {
    if (!chrome.runtime?.id) { consoleLog('warn', 'ext', 'Cannot send — extension context invalid'); return; }
    return chrome.runtime.sendMessage(msg).catch(err => {
      consoleLog('error', 'ext', `Cannot send - ${err.message}`);
    });
  } catch (err) {
    consoleLog('error', 'ext', `Cannot send - ${err.message}`);
  }
}

connect();
// ===== MESSAGE HANDLING =====

function handleMessage(msg) {
  switch (msg.type) {
    case 'STATE_UPDATE':
      if (!extensionConnected) {
        extensionConnected = true;
        updateSystemStatus();
        updateOnboarding();
      }
      updateState(msg.payload);
      break;

    case 'DECISION_LOG':
      addDecisionEntry(msg.payload);
      break;

    case 'LOG':
      consoleLog(msg.payload.level, msg.payload.source, msg.payload.message, msg.payload.data);
      break;

    case 'LOG_HISTORY':
      // Sync decision log & console with live worker history on connection load
      if (Array.isArray(msg.payload)) {
        logEntries.innerHTML = '';
        consoleOutput.innerHTML = '';
        decisionLog = [];
        
        // Re-populate Console with full historical log
        const historyCopy = [...msg.payload];
        historyCopy.reverse().forEach(entry => {
          consoleLog(entry.level, entry.source, entry.message, entry.data, entry.ts);
        });

        // Filter and re-populate Decision Log
        const decisionLogs = msg.payload.filter(entry => 
          entry.source?.startsWith('decision') || 
          entry.verdict !== undefined || 
          entry.type === 'escalation' ||
          (entry.level === 'warn' && entry.source?.startsWith('orchestrator')) ||
          (entry.level === 'error' && entry.source?.startsWith('orchestrator'))
        );
        decisionLogs.reverse().forEach(entry => {
          addDecisionEntry(entry);
        });
      }
      break;

    case 'AWAITING_CONFIRMATION':
      showConfirmation(msg.payload);
      break;

    case 'DIAGNOSTIC_RESULT':
      showDiagnosticResult(msg.payload);
      break;

    case 'PHOTO_REVIEW_NEEDED':
      // DISABLED — photo comparison is not a fraud checklist item per agent feedback.
      // handlePhotoReviewNeeded(msg.payload);
      break;

    case 'NOT_FRAUD_ALERT':
      handleNotFraudAlert(msg.payload);
      break;

    case 'AUTONOMOUS_COUNTDOWN':
      showAutonomousCountdown(msg.payload);
      break;

    case 'UPDATE_AVAILABLE':
    case 'UPDATE_CHECK_RESULT':
      handleUpdateStatus(msg.payload);
      break;

    case 'UPDATE_PROGRESS':
      // No-op: updates are now applied externally via install.bat.
      break;

    case 'UPDATE_COMPLETE':
      currentUpdateState.updating = false;
      renderUpdatePanel();
      consoleLog('info', 'updater', `Update to v${msg.payload?.version || 'latest'} reported complete.`);
      break;

    case 'UPDATE_INFO':
      currentUpdateState.updating = false;
      if (msg.payload?.installBatUrl) {
        currentUpdateState.installBatUrl = msg.payload.installBatUrl;
      }
      renderUpdatePanel();
      consoleLog('info', 'updater', msg.payload?.message || 'Update info received');
      break;

    case 'UPDATE_ERROR':
      currentUpdateState.updating = false;
      currentUpdateState.error = msg.payload?.error || 'Update failed';
      renderUpdatePanel();
      consoleLog('error', 'updater', currentUpdateState.error);
      break;
  }
}

// ===== AUTONOMOUS COUNTDOWN UI =====

let countdownInterval = null;
let countdownEndTime = 0;

function showAutonomousCountdown(payload) {
  const orderId = payload?.orderId;
  const verdict = payload?.verdict || '?';
  const totalSeconds = payload?.seconds || 0;
  if (totalSeconds <= 0) return;

  const alert = createHumanLoopAlert({
    type: 'countdown',
    orderId,
    title: `Autonomous execution in <span id="hlaCount">${totalSeconds}</span>s`,
    meta: `${verdict} · cancel to review manually`,
    icon: 'ph-warning-circle',
    tone: 'tertiary',
    actions: [
      { label: 'CANCEL & SWITCH TO SUPERVISED', icon: 'ph-pause', primary: true, id: 'hlaActionBtn' }
    ]
  });

  countdownEndTime = Date.now() + totalSeconds * 1000;
  if (countdownInterval) clearInterval(countdownInterval);
  countdownInterval = setInterval(() => {
    const remaining = Math.max(0, Math.ceil((countdownEndTime - Date.now()) / 1000));
    const countEl = document.getElementById('hlaCount');
    if (countEl) countEl.textContent = remaining;
    if (remaining <= 0) {
      clearInterval(countdownInterval);
      countdownInterval = null;
      alert.remove();
    }
  }, 200);

  alert.querySelector('#hlaActionBtn').addEventListener('click', () => {
    clearInterval(countdownInterval);
    countdownInterval = null;
    alert.remove();
    send({ type: 'SET_MODE', payload: 'supervised' });
    send({ type: 'SET_PAUSE', payload: true });
    consoleLog('info', 'mode', 'Agent cancelled countdown — switched to supervised + paused');
  });
}

function clearAutonomousCountdown() {
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
  }
  const banner = document.getElementById('humanLoopAlert-countdown');
  if (banner) banner.remove();
}

// ===== NOT_FRAUD ALERT BANNER =====

let activeNotFraudAlerts = new Set();

function handleNotFraudAlert(payload) {
  const orderId = payload?.orderId;
  if (!orderId || activeNotFraudAlerts.has(orderId)) return;
  activeNotFraudAlerts.add(orderId);

  maybePlayVerdictSound({ verdict: 'NOT_FRAUD' });

  const alert = createHumanLoopAlert({
    type: 'not-fraud',
    orderId,
    title: 'NOT FRAUD — Manual Refund Required',
    meta: `Order #${escapeHtml(orderId)} · ${escapeHtml(payload.reason || 'review required')}`,
    icon: 'ph-hand-palm',
    tone: 'secondary',
    actions: [
      { label: 'DISMISS', icon: 'ph-x', primary: false, id: 'hlaDismissBtn' }
    ]
  });

  alert.querySelector('#hlaDismissBtn').addEventListener('click', () => {
    alert.remove();
    activeNotFraudAlerts.delete(orderId);
    send({ type: 'DISMISS_NOT_FRAUD', payload: { orderId } });
  });

  // System notification: enabled by default, but gracefully degrade if blocked.
  // Try permission request + notification creation; if it fails, the persistent
  // banner + audible alarm still remain so the agent cannot miss it.
  requestNotificationPermission().then(() => {
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') {
      consoleLog('warn', 'notify', 'System notifications permission not granted — falling back to persistent banner + sound');
      return;
    }
    try {
      const n = new Notification('Fraud Cockpit — human review required', {
        body: `Order #${orderId} requires manual review.`,
        tag: `human-loop-${orderId}`,
        requireInteraction: true
      });
      n.onerror = () => {
        consoleLog('warn', 'notify', 'System notification failed to display — falling back to banner + sound');
      };
    } catch (err) {
      consoleLog('warn', 'notify', `System notification error: ${err?.message || err}`);
    }
  });
}

// Unified human-in-the-loop alert banner (NOT_FRAUD alerts + autonomous countdown)
function createHumanLoopAlert({ type, orderId, title, meta, icon, tone, actions = [] }) {
  const alert = document.createElement('div');
  alert.id = `humanLoopAlert-${type}-${orderId || 'global'}`;
  alert.className = `human-loop-alert tone-${tone}`;
  alert.dataset.orderId = orderId || '';

  const toneColor = tone === 'secondary' ? 'var(--md-sys-color-secondary-container)' :
                    tone === 'tertiary' ? 'var(--md-sys-color-tertiary-container)' :
                    'var(--md-sys-color-error-container)';

  const actionHtml = actions.map(a => `
    <button class="hla-action${a.primary ? ' primary' : ''}" id="${a.id}">
      ${a.icon ? `<i class="ph-bold ${a.icon}"></i>` : ''}${a.label}
    </button>
  `).join('');

  alert.innerHTML = `
    <div class="hla-icon"><i class="ph-bold ${icon}"></i></div>
    <div class="hla-body">
      <div class="hla-title">${title}</div>
      <div class="hla-meta">${meta}</div>
    </div>
    <div class="hla-actions">${actionHtml}</div>
  `;

  let container = document.getElementById('humanLoopAlertContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'humanLoopAlertContainer';
    container.className = 'human-loop-alert-container';
    document.body.appendChild(container);
  }
  container.appendChild(alert);
  return alert;
}

function requestNotificationPermission() {
  if (!('Notification' in window)) return Promise.resolve('unsupported');
  if (Notification.permission === 'granted') return Promise.resolve('granted');
  if (Notification.permission === 'denied') return Promise.resolve('denied');
  return Notification.requestPermission().catch(() => 'denied');
}

// Request notification permission early on dashboard load so the first alert
// doesn't fail due to a denied-by-default browser state.
requestNotificationPermission();

// ===== SHIFT TIMER =====

function startShiftClock() {
  shiftStartTime = Date.now();
  
  function updateTimer() {
    const elapsed = Date.now() - shiftStartTime;
    const hours = Math.floor(elapsed / 3600000);
    const minutes = Math.floor((elapsed % 3600000) / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);
    
    shiftTimer.textContent = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }
  
  updateTimer(); // Initial update
  shiftInterval = setInterval(updateTimer, 1000); // Update every 1 second
}

function stopShiftClock() {
  if (shiftInterval) {
    clearInterval(shiftInterval);
    shiftInterval = null;
  }
  shiftStartTime = null;
  shiftTimer.textContent = '00:00:00';
}

// ===== STATE =====

function updateState(data) {
  if (!data) return;
  currentState = data;

  // Mode
  if (data.mode) {
    modeSelect.value = data.mode;
    const segmentBtns = document.querySelectorAll('.segment-btn');
    segmentBtns.forEach(b => {
      if (b.getAttribute('data-mode') === data.mode) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });
  }

  // Pause/Play button
  if (data.isPaused) {
    pausePlayBtn.textContent = 'START PROCESSING';
    pausePlayBtn.className = 'btn btn-lg btn-start';
  } else {
    pausePlayBtn.textContent = 'PAUSE';
    pausePlayBtn.className = 'btn btn-lg btn-pause';
    if (!shiftStartTime) startShiftClock();
  }

  const phase = data.state || 'idle';

  // Stop Scraping button: only visible while actively extracting data
  if (stopScrapeBtn) {
    stopScrapeBtn.style.display = (!data.isPaused && phase === 'extraction') ? 'inline-flex' : 'none';
  }

  // Clear autonomous countdown banner once execution starts or we return to idle
  if (phase === 'execution' || phase === 'idle' || data.isPaused) {
    clearAutonomousCountdown();
  }
  phaseBadge.textContent = phase.toUpperCase();
  phaseBadge.className = 'phase-badge' + (phase !== 'idle' ? ' active' : '');
  updatePipeline(phase);

  // Ticket
  if (data.ticket && data.ticket.orderId) {
    ticketInfo.innerHTML = `
      <div class="row"><span class="label">ORDER ID</span><span class="value">${data.ticket.orderId}</span></div>
      <div class="row"><span class="label">EMAIL</span><span class="value">${data.ticket.customerEmail || '—'}</span></div>
      <div class="row"><span class="label">AMOUNT</span><span class="value">${data.ticket.amountPaid || '—'}</span></div>
      <div class="row"><span class="label">PHASE</span><span class="value">${phase.toUpperCase()}</span></div>
    `;
  } else {
    ticketInfo.innerHTML = '<div class="empty">[ NO TICKET IN PROGRESS ]</div>';
  }

  // Stats
  if (data.stats) {
    const total = data.stats.processed || 0;
    const fCount = data.stats.fraud || 0;
    const nfCount = data.stats.notFraud || 0;
    const eCount = data.stats.errors || 0;

    const fPct = total > 0 ? ((fCount / total) * 100).toFixed(1) : '0.0';
    const nfPct = total > 0 ? ((nfCount / total) * 100).toFixed(1) : '0.0';
    const ePct = total > 0 ? ((eCount / total) * 100).toFixed(1) : '0.0';

    processedCount.textContent = total;
    fraudCount.innerHTML = `${fCount}<span style="font-size: 11px; opacity: 0.6; font-weight: normal; margin-left: 4px;">(${fPct}%)</span>`;
    notFraudCount.innerHTML = `${nfCount}<span style="font-size: 11px; opacity: 0.6; font-weight: normal; margin-left: 4px;">(${nfPct}%)</span>`;
    errorCount.innerHTML = `${eCount}<span style="font-size: 11px; opacity: 0.6; font-weight: normal; margin-left: 4px;">(${ePct}%)</span>`;
    if (skippedCount) skippedCount.textContent = data.stats.skipped || 0;
  }

  // Confirmation panel is driven by state.pendingConfirmation
  if (data.pendingConfirmation) {
    showConfirmation(data.pendingConfirmation);
  } else {
    hideConfirmation();
  }

  // Throughput
  updateThroughput(data.stats?.processed || 0);

  // Populate settings once on first state update that includes them
  if (data.settings && !settingsPopulated) {
    populateSettings(data.settings);
    settingsPopulated = true;
  }
}

// ===== PIPELINE =====

const PIPELINE_PHASES = ['idle', 'intake', 'extraction', 'calculation', 'checklist', 'verdict', 'execution'];

function updatePipeline(currentPhase) {
  const steps = pipelineBar.querySelectorAll('.pipeline-step');
  const currentIndex = PIPELINE_PHASES.indexOf(currentPhase);

  steps.forEach((step) => {
    const stepPhase = step.getAttribute('data-phase');
    const stepIndex = PIPELINE_PHASES.indexOf(stepPhase);

    step.classList.remove('active', 'done', 'error');

    if (stepIndex === currentIndex) {
      step.classList.add('active');
    } else if (stepIndex < currentIndex && currentIndex > 0) {
      step.classList.add('done');
    }
  });
}

// ===== ONBOARDING =====

function updateOnboarding() {
  if (extensionConnected) {
    onboardingPanel.style.display = 'none';
  } else {
    onboardingPanel.style.display = '';
  }
}

// ===== THROUGHPUT =====

function updateThroughput(processed) {
  if (!shiftStartTime || processed === 0) {
    throughputEl.innerHTML = 'RATE: <span class="rate">0</span>/HR';
    return;
  }
  const elapsedHours = (Date.now() - shiftStartTime) / 3600000;
  const rate = elapsedHours > 0 ? Math.round(processed / elapsedHours) : 0;
  throughputEl.innerHTML = `RATE: <span class="rate">${rate}</span>/HR`;
}

// ===== DECISION LOG =====

function addDecisionEntry(entry) {
  decisionLog.unshift(entry);
  logCount.textContent = decisionLog.length;

  // Audible cue on a NOT-FRAUD verdict
  maybePlayVerdictSound(entry);

  const empty = logEntries.querySelector('.empty');
  if (empty) empty.remove();

  const div = document.createElement('div');
  div.className = 'log-entry';
  const time = entry.timestamp ? new Date(entry.timestamp).toLocaleTimeString() : new Date().toLocaleTimeString();

  let verdictHtml = '';
  if (entry.type === 'error') {
    verdictHtml = `<span class="verdict error">ERROR</span><span class="detail">${entry.message}</span>`;
  } else if (entry.type === 'escalation') {
    verdictHtml = `<span class="verdict info">ESCALATE</span><span class="detail">${entry.reason}</span>`;
  } else if (entry.verdict) {
    const cls = entry.verdict === 'FRAUD' ? 'fraud' : 'ok';
    verdictHtml = `<span class="verdict ${cls}">${entry.verdict}</span>`;
    if (entry.rate !== undefined) verdictHtml += `<span class="detail">${entry.rate}%</span>`;
    if (entry.reason) verdictHtml += `<span class="detail">${entry.reason}</span>`;
  } else {
    verdictHtml = `<span class="detail">${entry.message || entry.type || '?'}</span>`;
  }

  div.innerHTML = `<span class="time">${time}</span>${entry.orderId ? `<strong>${entry.orderId}</strong>` : ''}${verdictHtml}`;
  logEntries.prepend(div);

  while (logEntries.children.length > 200) logEntries.removeChild(logEntries.lastChild);
}

// ===== CONSOLE =====

function consoleLog(level, source, message, data, timestamp) {
  const ts = timestamp ? new Date(timestamp).toLocaleTimeString() : new Date().toLocaleTimeString();
  const div = document.createElement('div');
  div.className = `console-line ${level}`;
  div.setAttribute('data-level', level);
  let text = `<span class="ts">${ts}</span><span class="src">[${source}]</span> ${escapeHtml(message)}`;
  if (data && typeof data === 'object') {
    text += ` <span style="color:var(--text-dim)">${escapeHtml(JSON.stringify(data).slice(0, 120))}</span>`;
  }
  div.innerHTML = text;

  if (consoleFilter !== 'all' && level !== consoleFilter) {
    div.style.display = 'none';
  }

  consoleOutput.appendChild(div);
  consoleOutput.scrollTop = consoleOutput.scrollHeight;

  while (consoleOutput.children.length > 500) consoleOutput.removeChild(consoleOutput.firstChild);
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ===== TABS SYSTEM =====
document.addEventListener('DOMContentLoaded', () => {
  const tabs = document.querySelectorAll('.tab-btn');
  const contents = document.querySelectorAll('.tab-content');

  // Load saved tab from localStorage
  const savedTab = localStorage.getItem('active_dashboard_tab');
  if (savedTab) {
    const targetTab = Array.from(tabs).find(t => t.getAttribute('data-tab') === savedTab);
    const targetContent = $(savedTab);
    if (targetTab && targetContent) {
      tabs.forEach(t => t.classList.remove('active'));
      contents.forEach(c => c.classList.remove('active-content'));
      targetTab.classList.add('active');
      targetContent.classList.add('active-content');
    }
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Remove active from all tabs
      tabs.forEach(t => t.classList.remove('active'));
      contents.forEach(c => c.classList.remove('active-content'));

      // Add active to current
      tab.classList.add('active');
      const target = tab.getAttribute('data-tab');
      const targetContent = $(target);
      if (targetContent) {
        targetContent.classList.add('active-content');
        localStorage.setItem('active_dashboard_tab', target);
        // Re-run auto-resize on all textareas inside the activated tab,
        // because the initial wireAutoResize ran while the tab was hidden
        // (display: none) and scrollHeight was 0.
        targetContent.querySelectorAll('textarea').forEach(autoResize);
      }
    });
  });
});

// ===== SETTINGS =====

let lastSettings = {};

function setVal(id, v) { const el = $(id); if (el && v !== undefined && v !== null) el.value = v; }
function setNum(id, v, dflt) { const el = $(id); if (el) el.value = (v !== undefined && v !== null) ? v : dflt; }
function setChk(id, v, dfltTrue) { const el = $(id); if (el) el.checked = (v === undefined ? !!dfltTrue : !!v); }

function populateSettings(s) {
  if (!s) return;
  lastSettings = s;

  // General
  setNum('maxTicketsPerSession', s.max_tickets_per_session, 0);
  setNum('maxTicketsPerMinute', s.max_tickets_per_minute, 3);
  setVal('logLevel', s.log_level || 'info');

  // Notifications
  setChk('notificationsEnabled', s.notifications_enabled !== false, true);
  setChk('soundOnNotFraud', s.sound_on_not_fraud, true);
  setVal('soundType', s.sound_type || 'chime');
  setNum('soundVolume', s.sound_volume != null ? s.sound_volume : 70);
  setNum('autonomousCountdown', s.autonomous_execution_delay_ms != null ? s.autonomous_execution_delay_ms / 1000 : 0, 0);

  // Timing
  setNum('delayActionsMin', s.delays?.between_actions_ms?.min, 800);
  setNum('delayActionsMax', s.delays?.between_actions_ms?.max, 2500);
  setNum('delayPagesMin', s.delays?.between_pages_ms?.min, 1500);
  setNum('delayPagesMax', s.delays?.between_pages_ms?.max, 4000);
  setNum('delayTicketsMin', s.delays?.between_tickets_ms?.min, 3000);
  setNum('delayTicketsMax', s.delays?.between_tickets_ms?.max, 8000);
  setNum('typingMin', s.delays?.typing_speed_ms_per_char?.min, 30);
  setNum('typingMax', s.delays?.typing_speed_ms_per_char?.max, 80);
  setNum('keepaliveInterval', s.session_keepalive_interval_ms, 60000);
  setNum('supervisedTimeout', s.supervised_confirmation_timeout_ms, 300000);
  setNum('extractionSettle', s.extraction_settle_ms, 1500);

  // Thresholds
  setNum('thresholdRate', s.thresholds?.adjusted_rate_fraud_percent, 39);
  setNum('thresholdSameDay', s.thresholds?.same_day_comp_min_count, 2);
  setNum('thresholdBulkDrinks', s.thresholds?.bulk_drinks_min_quantity, 20);
  setNum('thresholdSameReason', s.thresholds?.same_reason_dominance_percent, 90);
  setNum('thresholdNewAccount', s.thresholds?.new_account_abuse_days, 2);
  setNum('thresholdExcessiveRatio', s.thresholds?.excessive_ratio_threshold, 0.30);

  // Checklist & connected accounts
  setNum('checklistWindowDays', s.checklist_window_days, 30);
  setChk('checkConnectedAccounts', s.check_connected_accounts, true);
  setNum('connectedMaxDevices', s.connected_max_devices, 5);
  setNum('connectedMaxAccounts', s.connected_max_accounts, 6);
  setNum('connectedMaxDepth', s.connected_max_depth, 2);

  // Operation Portal
  setChk('vpnCheckBeforeOp', s.vpn_check_before_op, true);
  setNum('opReadyTimeout', s.op_ready_timeout_ms, 25000);
  setVal('opBaseUrl', s.op_base_url || 'https://hungerstation.com/operation/en');

  // Fraud responses (bilingual)
  renderApologies(s.fraud_responses, s.fraud_responses_en, 'apologiesContainer');
  const noteVal = s.fraud_note || (Array.isArray(s.fraud_notes) ? s.fraud_notes[0] : '') || '';
  setVal('fraudNote', noteVal);

  // Populate reason-specific fraud notes
  const notes = s.fraud_notes || {};
  setVal('note_rate', notes.rate || BUILTIN_NOTE_DEFAULTS.rate);
  setVal('note_same_day_frequency', notes.same_day_frequency || BUILTIN_NOTE_DEFAULTS.same_day_frequency);
  setVal('note_bulk_drinks', notes.bulk_drinks || BUILTIN_NOTE_DEFAULTS.bulk_drinks);
  setVal('note_all_system_comps', notes.all_system_comps || BUILTIN_NOTE_DEFAULTS.all_system_comps);
  setVal('note_photo_mismatch', notes.photo_mismatch || BUILTIN_NOTE_DEFAULTS.photo_mismatch);
  setVal('note_blocked_device', notes.blocked_device || BUILTIN_NOTE_DEFAULTS.blocked_device);
  setVal('note_new_account_abuse', notes.new_account_abuse || BUILTIN_NOTE_DEFAULTS.new_account_abuse);
  setVal('note_duplicate_order_comp', notes.duplicate_order_comp || BUILTIN_NOTE_DEFAULTS.duplicate_order_comp);
  setVal('note_same_reason_pattern', notes.same_reason_pattern || BUILTIN_NOTE_DEFAULTS.same_reason_pattern);
  setVal('note_excessive_comp_ratio', notes.excessive_comp_ratio || BUILTIN_NOTE_DEFAULTS.excessive_comp_ratio);
  setVal('note_connected_accounts', notes.connected_accounts || BUILTIN_NOTE_DEFAULTS.connected_accounts);

  // Wire auto-direction and auto-resize for note templates
  const noteIds = [
    'note_rate', 'note_same_day_frequency', 'note_bulk_drinks', 'note_all_system_comps',
    'note_photo_mismatch', 'note_blocked_device', 'note_new_account_abuse',
    'note_duplicate_order_comp', 'note_same_reason_pattern', 'note_excessive_comp_ratio',
    'note_connected_accounts'
  ];
  noteIds.forEach(id => {
    const ta = $(id);
    if (ta) {
      const card = ta.closest('.apology-card');
      const indicator = card ? card.querySelector('.text-direction-indicator') : null;
      
      const adjust = () => {
        const value = ta.value.trim();
        if (!value) {
          ta.dir = 'auto';
          if (indicator) indicator.textContent = 'AUTO-DIR';
          return;
        }
        const isArabic = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(value);
        if (isArabic) {
          ta.dir = 'rtl';
          if (indicator) indicator.textContent = 'RTL (Arabic)';
        } else {
          ta.dir = 'ltr';
          if (indicator) indicator.textContent = 'LTR (English)';
        }
      };
      
      ta.addEventListener('input', adjust);
      adjust();
      wireAutoResize(ta);
    }
  });

  // API
  $('geminiKey').value = s.gemini_api_key ? '********' : '';
  setVal('geminiModel', s.gemini_model || 'gemini-2.0-flash');
}

function renderApologies(arArr, enArr, containerId) {
  const container = $(containerId);
  if (!container) return;
  container.innerHTML = '';
  const arList = Array.isArray(arArr) ? arArr : [];
  const enList = Array.isArray(enArr) ? enArr : [];
  const count = Math.max(arList.length, enList.length, 1);
  for (let i = 0; i < count; i++) {
    addApologyCard(container, arList[i] || '', enList[i] || '');
  }
}

function addApologyCard(container, arText, enText) {
  const card = document.createElement('div');
  card.className = 'apology-card bilingual-card';
  const idx = container.children.length + 1;
  card.innerHTML = `
    <div class="bilingual-header">
      <span class="bilingual-number">${idx}</span>
      <button type="button" class="btn-remove-apology" title="Delete this apology pair">
        <i class="ph-bold ph-trash"></i>
      </button>
    </div>
    <div class="bilingual-pair">
      <div class="bilingual-field">
        <div class="bilingual-label"><span class="lang-pill ar">AR</span> Arabic</div>
        <textarea class="apology-ar" placeholder="Arabic apology text..." rows="2" dir="rtl">${escapeHtml(arText)}</textarea>
      </div>
      <div class="bilingual-field">
        <div class="bilingual-label"><span class="lang-pill en">EN</span> English</div>
        <textarea class="apology-en" placeholder="English translation..." rows="2" dir="ltr">${escapeHtml(enText)}</textarea>
      </div>
    </div>
  `;

  card.querySelector('.btn-remove-apology').addEventListener('click', () => {
    card.remove();
    renumberApologyCards(container);
    if (container.children.length === 0) {
      addApologyCard(container, '', '');
    }
  });
  container.appendChild(card);

  // Auto-resize both textareas to fit content
  card.querySelectorAll('textarea').forEach(wireAutoResize);
}

function renumberApologyCards(container) {
  container.querySelectorAll('.bilingual-number').forEach((el, i) => {
    el.textContent = i + 1;
  });
}

// Wire up the add button listeners once DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  const addBtn = $('addApologyBtn');
  if (addBtn && !addBtn.hasAttribute('data-action-wired')) {
    addBtn.setAttribute('data-action-wired', '1');
    addBtn.addEventListener('click', () => {
      addApologyCard($('apologiesContainer'), '', '');
    });
  }
  const noteBtn = $('addFraudNoteBtn');
  if (noteBtn && !noteBtn.hasAttribute('data-action-wired')) {
    noteBtn.setAttribute('data-action-wired', '1');
    noteBtn.addEventListener('click', () => {
      addApologyCard($('fraudNotesContainer'), '', '');
    });
  }
});

// Since the dashboard script might run immediately if DOM is already parsed,
// also register the click events directly.
setTimeout(() => {
  const addBtn = $('addApologyBtn');
  if (addBtn && !addBtn.hasAttribute('data-action-wired')) {
    addBtn.setAttribute('data-action-wired', '1');
    addBtn.addEventListener('click', () => {
      addApologyCard($('apologiesContainer'), '', '');
    });
  }
  const noteBtn = $('addFraudNoteBtn');
  if (noteBtn && !noteBtn.hasAttribute('data-action-wired')) {
    noteBtn.setAttribute('data-action-wired', '1');
    noteBtn.addEventListener('click', () => {
      addApologyCard($('fraudNotesContainer'), '', '');
    });
  }
}, 500);

function collectSettings() {
  const geminiVal = $('geminiKey').value;
  const num = (id, dflt) => { const v = parseFloat($(id).value); return isNaN(v) ? dflt : v; };

  const collectBilingualApologies = (containerId) => {
    const container = $(containerId);
    if (!container) return { ar: [], en: [] };
    const ar = [], en = [];
    container.querySelectorAll('.bilingual-card').forEach(card => {
      const arVal = (card.querySelector('.apology-ar')?.value || '').trim();
      const enVal = (card.querySelector('.apology-en')?.value || '').trim();
      if (arVal || enVal) { ar.push(arVal); en.push(enVal); }
    });
    return { ar, en };
  };

  const apologies = collectBilingualApologies('apologiesContainer');

  const result = {
    max_tickets_per_session: num('maxTicketsPerSession', 0),
    max_tickets_per_minute: num('maxTicketsPerMinute', 3),
    log_level: $('logLevel').value,

    notifications_enabled: $('notificationsEnabled').checked,
    sound_on_not_fraud: $('soundOnNotFraud').checked,
    sound_type: $('soundType').value,
    sound_volume: num('soundVolume', 70),
    autonomous_execution_delay_ms: num('autonomousCountdown', 0) * 1000,

    session_keepalive_interval_ms: num('keepaliveInterval', 60000),
    supervised_confirmation_timeout_ms: num('supervisedTimeout', 300000),
    extraction_settle_ms: num('extractionSettle', 1500),

    // Send nested objects COMPLETE (background replaces them wholesale on merge),
    // preserving any keys not exposed in the UI from the last known settings.
    delays: {
      ...(lastSettings.delays || {}),
      between_actions_ms: { min: num('delayActionsMin', 800), max: num('delayActionsMax', 2500) },
      between_pages_ms: { min: num('delayPagesMin', 1500), max: num('delayPagesMax', 4000) },
      between_tickets_ms: { min: num('delayTicketsMin', 3000), max: num('delayTicketsMax', 8000) },
      typing_speed_ms_per_char: { min: num('typingMin', 30), max: num('typingMax', 80) }
    },
    thresholds: {
      ...(lastSettings.thresholds || {}),
      adjusted_rate_fraud_percent: num('thresholdRate', 39),
      same_day_comp_min_count: num('thresholdSameDay', 2),
      bulk_drinks_min_quantity: num('thresholdBulkDrinks', 20),
      same_reason_dominance_percent: num('thresholdSameReason', 90),
      new_account_abuse_days: num('thresholdNewAccount', 2),
      excessive_ratio_threshold: num('thresholdExcessiveRatio', 0.30)
    },

    checklist_window_days: num('checklistWindowDays', 30),
    check_connected_accounts: $('checkConnectedAccounts').checked,
    connected_max_devices: num('connectedMaxDevices', 5),
    connected_max_accounts: num('connectedMaxAccounts', 6),
    connected_max_depth: num('connectedMaxDepth', 1),

    vpn_check_before_op: $('vpnCheckBeforeOp').checked,
    op_ready_timeout_ms: num('opReadyTimeout', 25000),
    op_base_url: $('opBaseUrl').value.trim() || 'https://hungerstation.com/operation/en',

    fraud_responses: apologies.ar,
    fraud_responses_en: apologies.en,
    fraud_note: $( 'note_rate' ) ? $( 'note_rate' ).value.trim() : '',
    fraud_notes: {
      rate: $( 'note_rate' ) ? $( 'note_rate' ).value.trim() : '',
      same_day_frequency: $( 'note_same_day_frequency' ) ? $( 'note_same_day_frequency' ).value.trim() : '',
      bulk_drinks: $( 'note_bulk_drinks' ) ? $( 'note_bulk_drinks' ).value.trim() : '',
      all_system_comps: $( 'note_all_system_comps' ) ? $( 'note_all_system_comps' ).value.trim() : '',
      photo_mismatch: $( 'note_photo_mismatch' ) ? $( 'note_photo_mismatch' ).value.trim() : '',
      blocked_device: $( 'note_blocked_device' ) ? $( 'note_blocked_device' ).value.trim() : '',
      new_account_abuse: $( 'note_new_account_abuse' ) ? $( 'note_new_account_abuse' ).value.trim() : '',
      duplicate_order_comp: $( 'note_duplicate_order_comp' ) ? $( 'note_duplicate_order_comp' ).value.trim() : '',
      same_reason_pattern: $( 'note_same_reason_pattern' ) ? $( 'note_same_reason_pattern' ).value.trim() : '',
      excessive_comp_ratio: $( 'note_excessive_comp_ratio' ) ? $( 'note_excessive_comp_ratio' ).value.trim() : '',
      connected_accounts: $( 'note_connected_accounts' ) ? $( 'note_connected_accounts' ).value.trim() : ''
    },

    gemini_model: $('geminiModel').value.trim() || 'gemini-2.0-flash'
  };

  if (!geminiVal.includes('*') && geminiVal.length > 0) {
    result.gemini_api_key = geminiVal;
  }

  return result;
}

// ===== NOTIFICATION SOUND =====

let audioCtx = null;
function getAudioCtx() {
  if (!audioCtx) {
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch (_) { return null; }
  }
  if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
  return audioCtx;
}

const SOUND_PRESETS = {
  chime: [
    { f: 523.25, t: 0, d: 0.15, type: 'sine' },
    { f: 659.25, t: 0.12, d: 0.15, type: 'sine' },
    { f: 783.99, t: 0.24, d: 0.3, type: 'sine' }
  ],
  beep: [
    { f: 880, t: 0, d: 0.1, type: 'square' },
    { f: 880, t: 0.15, d: 0.1, type: 'square' }
  ],
  ding: [
    { f: 987.77, t: 0, d: 0.08, type: 'sine' },
    { f: 1318.51, t: 0.04, d: 0.4, type: 'sine' }
  ],
  alarm: [
    { f: 600, t: 0, d: 0.12, type: 'sawtooth' },
    { f: 450, t: 0.12, d: 0.12, type: 'sawtooth' },
    { f: 600, t: 0.24, d: 0.12, type: 'sawtooth' },
    { f: 450, t: 0.36, d: 0.2, type: 'sawtooth' }
  ]
};

function playTone({ f, d, type = 'sine', t = 0, vol = 0.5 }) {
  const ctx = getAudioCtx();
  if (!ctx) return;
  setTimeout(() => {
    try {
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(f, ctx.currentTime);
      gainNode.gain.setValueAtTime(vol, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + d);
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + d);
    } catch (_) {}
  }, t * 1000);
}

function playNotificationSound() {
  const type = $('soundType') ? $('soundType').value : (currentState.settings?.sound_type || 'chime');
  const vol = $('soundVolume') ? +$('soundVolume').value : (currentState.settings?.sound_volume ?? 70);
  const factor = vol / 100 * 0.15; // cap gain to avoid clipping

  if (type === 'none') return;

  if (type === 'custom') {
    const dataUrl = localStorage.getItem('custom_alert_sound');
    if (dataUrl) {
      try {
        const audio = new Audio(dataUrl);
        audio.volume = vol / 100;
        audio.play().catch(() => {});
      } catch (_) {}
    } else {
      const preset = SOUND_PRESETS.chime;
      preset.forEach(n => playTone({ ...n, vol: factor }));
    }
    return;
  }

  const notes = SOUND_PRESETS[type] || SOUND_PRESETS.chime;
  notes.forEach(n => playTone({ ...n, vol: factor }));
}

function maybePlayVerdictSound(entry) {
  if (currentState.settings?.sound_on_not_fraud && entry.verdict === 'NOT_FRAUD') {
    playNotificationSound();
  }
}

function handlePhotoReviewNeeded(payload) {
  // DISABLED — photo comparison is not a fraud checklist item per agent feedback.
  // Kept for future use.
  consoleLog('info', 'review', `Photo review notification handler called for order ${payload?.orderId || '?'} (currently disabled)`);
}

// Custom Sound File Handling
const customSoundFile = $('customSoundFile');
const uploadSoundBtn = $('uploadSoundBtn');
const clearSoundBtn = $('clearSoundBtn');
const customSoundName = $('customSoundName');
const testSoundBtn = $('testSoundBtn');

if (localStorage.getItem('custom_alert_sound')) {
  customSoundName.textContent = localStorage.getItem('custom_alert_sound_name') || 'custom_sound.mp3';
}

uploadSoundBtn?.addEventListener('click', () => customSoundFile.click());
clearSoundBtn?.addEventListener('click', () => {
  localStorage.removeItem('custom_alert_sound');
  localStorage.removeItem('custom_alert_sound_name');
  customSoundName.textContent = 'No custom sound';
  consoleLog('info', 'notify', 'Custom sound cleared');
});

customSoundFile?.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(evt) {
    try {
      localStorage.setItem('custom_alert_sound', evt.target.result);
      localStorage.setItem('custom_alert_sound_name', file.name);
      customSoundName.textContent = file.name;
      consoleLog('info', 'notify', `Custom sound set: ${file.name}`);
    } catch (_) {
      alert('Could not store the sound (browser storage full). Try a smaller file.');
    }
  };
  reader.readAsDataURL(file);
});

testSoundBtn?.addEventListener('click', () => {
  playNotificationSound();
});

// Enable browser notifications button
$('enableNotifBtn')?.addEventListener('click', () => {
  if (!('Notification' in window)) return;
  Notification.requestPermission().then(p => {
    consoleLog('info', 'notify', `Notification permission: ${p}`);
  });
});

// ===== CONFIRM PANEL =====

function showConfirmation(pc) {
  confirmPanel.style.display = '';
  const who = pc.customerName
    ? `${escapeHtml(pc.customerName)}${pc.mainUserId ? ' (user ' + escapeHtml(pc.mainUserId) + ')' : ''}`
    : (pc.mainUserId ? 'user ' + escapeHtml(pc.mainUserId) : '—');

  const rateColor = pc.ratePercent >= 39 ? 'var(--accent)' : 'var(--text)';
  const verdictClass = pc.verdict === 'FRAUD' ? 'fraud' : 'ok';
  const checksHtml = (pc.checks || []).map(c => {
    const icon = c.hit ? '✕' : (c.needsReview ? '?' : '✓');
    const cls = c.hit ? 'fraud' : (c.needsReview ? 'warn' : 'ok');
    return `<div class="chk-line">
      <span class="chk-icon ${cls}">${icon}</span>
      <span class="chk-name">${c.n}. ${escapeHtml(c.name)}</span>
      <span class="chk-reason">${escapeHtml(c.reason || '')}</span>
    </div>`;
  }).join('');

  const noteLabels = {
    rate: 'Rate / high compensation ratio',
    same_day_frequency: 'Same-day compensation frequency',
    bulk_drinks: 'Bulk drinks',
    all_system_comps: 'All-system compensations',
    photo_mismatch: 'Photo mismatch',
    blocked_device: 'Blocked device/account',
    new_account_abuse: 'New account abuse',
    duplicate_order_comp: 'Duplicate order compensation',
    same_reason_pattern: 'Same reason pattern',
    excessive_comp_ratio: 'Excessive compensation ratio',
    connected_accounts: 'Connected fraudulent accounts'
  };

  // Use noteDefaults from pending confirmation (already merged defaults + user overrides) — F4 fix.
  const noteDefaults = pc.noteDefaults || currentState.settings?.fraud_notes || {};
  const noteKeys = Object.keys(noteLabels);

  // Determine which note the system would auto-select.
  let selectedKey = 'rate';
  if (pc.verdict === 'FRAUD') {
    const keyMap = {
      1: 'same_day_frequency', 2: 'bulk_drinks', 3: 'all_system_comps', 4: 'photo_mismatch',
      5: 'blocked_device', 6: 'new_account_abuse', 7: 'duplicate_order_comp',
      8: 'same_reason_pattern', 9: 'excessive_comp_ratio', 10: 'connected_accounts'
    };
    if (pc.source === 'rate') {
      selectedKey = 'rate';
    } else if (pc.checks?.length) {
      const firstHit = pc.checks.find(c => c.hit);
      selectedKey = keyMap[firstHit?.n] || 'rate';
    }
  }

  const noteOptionsHtml = noteKeys.map(key => {
    const label = noteLabels[key];
    const isSelected = key === selectedKey ? ' selected' : '';
    return `<option value="${key}"${isSelected}>${label}</option>`;
  }).join('');

  const notePreviewHtml = noteKeys.map(key => {
    const text = noteDefaults[key] || '';
    const label = noteLabels[key];
    const cls = key === selectedKey ? ' active' : '';
    return `<div class="note-preview${cls}" data-note-key="${key}">
      <div class="note-preview-label">${label}</div>
      <textarea class="note-edit-text" rows="3" dir="rtl">${escapeHtml(text)}</textarea>
    </div>`;
  }).join('');

  const noteSelectorHtml = `
    <div class="note-selector">
      <div class="row"><span class="label">NOTE REASON</span>
        <select id="fraudNoteSelect" class="input-sm">${noteOptionsHtml}</select>
      </div>
      <div class="note-preview-list">${notePreviewHtml}</div>
    </div>
  `;

  // Apology preview (FRAUD only)
  let apologySection = '';
  if (pc.verdict === 'FRAUD') {
    const lang = pc.chatLanguage || 'ar';
    const apologyText = pc.apologyPreview || '';
    if (apologyText) {
      apologySection = `
        <div class="apology-preview-section">
          <div class="apology-preview-header">
            <span class="apology-preview-lang ${lang}">${lang.toUpperCase()}</span>
            Apology to send (${lang === 'ar' ? 'Arabic' : 'English'})
          </div>
          <textarea id="dashEditApology" rows="3" dir="${lang === 'ar' ? 'rtl' : 'ltr'}" style="min-height:48px;">${escapeHtml(apologyText)}</textarea>
        </div>`;
    } else {
      apologySection = `
        <div class="apology-preview-section">
          <div class="apology-preview-header">Apology to send</div>
          <div class="apology-preview-empty">No apologies configured. Add them in Settings &gt; Decline Apologies. Chat message will be skipped.</div>
        </div>`;
    }
  }

  confirmDetails.innerHTML = `
    <div class="row"><span class="label">VERDICT</span><span class="value verdict ${verdictClass}" style="padding:0 5px; font-weight:700;">${pc.verdict}</span></div>
    <div class="row"><span class="label">REASONS</span><span class="value">${(pc.reasons || []).map(escapeHtml).join('; ') || 'None'}</span></div>
    <div class="row"><span class="label">CUSTOMER</span><span class="value">${who}</span></div>
    <div class="row"><span class="label">RATE</span><span class="value" style="color:${rateColor}; font-weight:700;">${pc.ratePercent != null ? pc.ratePercent + '%' : '—'}</span></div>
    <div class="row"><span class="label">COMPS</span><span class="value">${pc.extracted?.compRows ?? '?'}</span></div>
    <div class="row"><span class="label">ORDERS</span><span class="value">${pc.extracted?.totalOrders ?? '?'} total / ${pc.extracted?.failedOrders ?? '?'} failed</span></div>
    <div class="row"><span class="label">COMPLAINT</span><span class="value">${escapeHtml(pc.extracted?.complaintType || '—')}</span></div>
    <div class="row"><span class="label">RISK STATUS</span><span class="value">${escapeHtml(pc.extracted?.risk || '—')}${pc.extracted?.preExisting ? ' (Pre-existing)' : ''}</span></div>
    ${checksHtml ? `<div class="chk-list">${checksHtml}</div>` : ''}
    ${apologySection}
    ${noteSelectorHtml}
  `;

  const noteSelect = document.getElementById('fraudNoteSelect');
  if (noteSelect) {
    noteSelect.addEventListener('change', () => {
      document.querySelectorAll('.note-preview').forEach(el => el.classList.remove('active'));
      const active = document.querySelector(`.note-preview[data-note-key="${noteSelect.value}"]`);
      if (active) active.classList.add('active');
    });
  }

  confirmBtn.innerHTML = pc.verdict === 'FRAUD'
    ? '<i class="ph-bold ph-shield-check btn-icon"></i> DENY & CLOSE'
    : '<i class="ph-bold ph-check-circle btn-icon"></i> CONFIRM NOT FRAUD';
  overrideBtn.innerHTML = pc.verdict === 'FRAUD'
    ? '<i class="ph-bold ph-shield-slash btn-icon"></i> NOT FRAUD'
    : '<i class="ph-bold ph-warning-circle btn-icon"></i> FRAUD';
}

function hideConfirmation() {
  confirmPanel.style.display = 'none';
  confirmDetails.innerHTML = '';
}

// ===== DIAGNOSTICS DISPLAY =====

function showDiagnosticResult(result) {
  const container = $('diagOutput');
  if (!result) { container.innerHTML = '<div class="empty">No diagnostic data</div>'; return; }

  let html = '';
  if (result.timestamp) {
    html += `<div class="diag-line"><span class="diag-key">Checked At</span><span class="diag-val">${new Date(result.timestamp).toLocaleTimeString()}</span></div>`;
  }

  if (result.tabs) {
    html += `<div class="diag-section">TABS FOUND: ${result.tabs.length}</div>`;
    for (const tab of result.tabs) {
      const csClass = tab.contentScript === 'connected' ? 'ok' : 'err';
      html += `<div class="diag-line"><span class="diag-key">${tab.system.toUpperCase()} #${tab.id}</span><span class="diag-val ${csClass}">${tab.contentScript}</span></div>`;
      if (tab.ticketsFound !== undefined) {
        html += `<div class="diag-line"><span class="diag-key">  Tickets</span><span class="diag-val">${tab.ticketsFound}</span></div>`;
      }
      if (tab.vpnActive !== undefined) {
        html += `<div class="diag-line"><span class="diag-key">  VPN</span><span class="diag-val ${tab.vpnActive ? 'ok' : 'err'}">${tab.vpnActive ? 'ACTIVE' : 'INACTIVE'}</span></div>`;
      }
    }
  }

  if (result.ok !== undefined) {
    const okClass = result.ok ? 'ok' : 'err';
    html += `<div class="diag-section">TEST RESULT</div>`;
    html += `<div class="diag-line"><span class="diag-key">Status</span><span class="diag-val ${okClass}">${result.ok ? 'PASS' : 'FAIL'}</span></div>`;
    if (result.system) html += `<div class="diag-line"><span class="diag-key">System</span><span class="diag-val">${result.system}</span></div>`;
    if (result.error) html += `<div class="diag-line"><span class="diag-key">Error</span><span class="diag-val err">${escapeHtml(result.error)}</span></div>`;
    if (result.message) html += `<div class="diag-line"><span class="diag-key">Message</span><span class="diag-val">${escapeHtml(result.message)}</span></div>`;
    if (result.status) html += `<div class="diag-line"><span class="diag-key">Gemini Status</span><span class="diag-val">${escapeHtml(result.status)}</span></div>`;
    if (result.reason) html += `<div class="diag-line"><span class="diag-key">Reason</span><span class="diag-val">${escapeHtml(result.reason)}</span></div>`;
    if (result.ticketsInQueue !== undefined) html += `<div class="diag-line"><span class="diag-key">Queue Size</span><span class="diag-val">${result.ticketsInQueue}</span></div>`;
    if (result.intake) {
      html += `<div class="diag-line"><span class="diag-key">Order ID</span><span class="diag-val">${result.intake.orderId || '—'}</span></div>`;
      html += `<div class="diag-line"><span class="diag-key">Email</span><span class="diag-val">${result.intake.customerEmail || '—'}</span></div>`;
      html += `<div class="diag-line"><span class="diag-key">Amount</span><span class="diag-val">${result.intake.amountPaid || '—'}</span></div>`;
    }
    if (result.vpnActive !== undefined) {
      html += `<div class="diag-line"><span class="diag-key">VPN</span><span class="diag-val ${result.vpnActive ? 'ok' : 'err'}">${result.vpnActive ? 'ACTIVE' : 'INACTIVE'}</span></div>`;
    }
    if (result.pageType) {
      html += `<div class="diag-line"><span class="diag-key">Page Type</span><span class="diag-val">${result.pageType}</span></div>`;
    }
    if (result.connected_max_depth !== undefined) {
      html += `<div class="diag-line"><span class="diag-key">Enabled</span><span class="diag-val">${result.enabled ? 'YES' : 'NO'}</span></div>`;
      html += `<div class="diag-line"><span class="diag-key">Max Depth</span><span class="diag-val">${result.connected_max_depth}</span></div>`;
      html += `<div class="diag-line"><span class="diag-key">Max Devices</span><span class="diag-val">${result.connected_max_devices}</span></div>`;
      html += `<div class="diag-line"><span class="diag-key">Max Accounts</span><span class="diag-val">${result.connected_max_accounts}</span></div>`;
    }
    if (result.stopScrapingFlag !== undefined) {
      html += `<div class="diag-line"><span class="diag-key">Stop Scraping Flag</span><span class="diag-val">${result.stopScrapingFlag}</span></div>`;
    }
    if (Array.isArray(result.results)) {
      html += `<div class="diag-section">TEST CASES</div>`;
      result.results.forEach((r, i) => {
        const passClass = r.pass ? 'ok' : 'err';
        html += `<div class="diag-line"><span class="diag-key">Case ${i + 1}</span><span class="diag-val ${passClass}">${r.pass ? 'PASS' : 'FAIL'}</span></div>`;
        if (r.input !== undefined) html += `<div class="diag-line"><span class="diag-key">  Input</span><span class="diag-val">${escapeHtml(String(r.input))}</span></div>`;
        if (r.parsed !== undefined) html += `<div class="diag-line"><span class="diag-key">  Parsed</span><span class="diag-val">${escapeHtml(JSON.stringify(r.parsed))}</span></div>`;
        if (r.notes !== undefined) html += `<div class="diag-line"><span class="diag-key">  Notes</span><span class="diag-val">${escapeHtml(JSON.stringify(r.notes))}</span></div>`;
        if (r.detected !== undefined) html += `<div class="diag-line"><span class="diag-key">  Detected</span><span class="diag-val">${r.detected ? 'YES' : 'NO'}</span></div>`;
        if (r.expected !== undefined) html += `<div class="diag-line"><span class="diag-key">  Expected</span><span class="diag-val">${r.expected ? 'YES' : 'NO'}</span></div>`;
      });
    }
  }

  if (result.warning) {
    html += `<div class="diag-section">WARNING</div>`;
    html += `<div class="diag-line"><span class="diag-val warn">${escapeHtml(result.warning)}</span></div>`;
  }

   container.innerHTML = html || '<div class="empty">No diagnostic data</div>';
}

// ===== UPDATER UI =====

function handleUpdateStatus(payload) {
  if (!payload) return;
  currentUpdateState.checking = false;
  currentUpdateState.current = payload.current || currentUpdateState.current;
  currentUpdateState.latest = payload.latest || currentUpdateState.latest;
  currentUpdateState.hasUpdate = !!payload.hasUpdate;
  currentUpdateState.error = payload.error || null;
  currentUpdateState.releaseNotes = payload.releaseNotes || '';
  currentUpdateState.installBatUrl = payload.installBatUrl || currentUpdateState.installBatUrl;

  renderUpdatePanel();

  if (payload.hasUpdate) {
    showUpdateNotification(payload.latest);
  }
}

function renderUpdatePanel() {
  const { current, latest, hasUpdate, checking, updating, error, releaseNotes } = currentUpdateState;

  // Current version
  updateCurrentVersion.textContent = current || chrome.runtime.getManifest().version || '—';

  // Latest version pill
  if (latest && latest !== current) {
    latestVersionPill.style.display = 'flex';
    updateLatestVersion.textContent = latest;
    latestVersionPill.classList.toggle('update-available', hasUpdate);
  } else {
    latestVersionPill.style.display = 'none';
  }

  // Status text
  if (error) {
    updateStatus.textContent = `Error: ${error}`;
    updateStatus.classList.remove('update-available');
    manualInstallNote.style.display = 'flex';
  } else if (checking) {
    updateStatus.textContent = 'Checking for updates...';
    updateStatus.classList.remove('update-available');
    manualInstallNote.style.display = 'none';
  } else if (hasUpdate) {
    updateStatus.textContent = `A new version is available: v${latest}`;
    updateStatus.classList.add('update-available');
    manualInstallNote.style.display = 'flex';
  } else {
    updateStatus.textContent = `You are on the latest version. Last checked: ${new Date().toLocaleTimeString()}`;
    updateStatus.classList.remove('update-available');
    manualInstallNote.style.display = 'none';
  }

  // Buttons
  checkUpdateBtn.disabled = checking;
  updateNowBtn.disabled = !hasUpdate || checking;

  if (checking) {
    checkUpdateBtn.innerHTML = '<i class="ph-bold ph-spinner spin-animation"></i> Checking...';
  } else {
    checkUpdateBtn.innerHTML = '<i class="ph-bold ph-magnifying-glass"></i> Check for Updates';
  }

  updateProgress.style.display = 'none';
  updateNowBtn.innerHTML = '<i class="ph-bold ph-download-simple"></i> Get install.bat';

  // Badge on tab
  helpUpdateBadge.style.display = hasUpdate ? 'block' : 'none';

  // Release notes
  if (releaseNotes) {
    releaseNotesPanel.style.display = 'block';
    releaseNotesBody.textContent = stripMarkdown(releaseNotes);
  } else {
    releaseNotesPanel.style.display = 'none';
    releaseNotesBody.textContent = '';
  }
}

function stripMarkdown(md) {
  if (!md) return '';
  return md
    .replace(/#{1,6}\s+/g, '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/`(.+?)`/g, '$1')
    .replace(/\[(.+?)\]\((.+?)\)/g, '$1 ($2)')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function showUpdateNotification(version) {
  if (!('Notification' in window)) return;
  if (Notification.permission !== 'granted') return;

  const notification = new Notification('Fraud Detection Update Available', {
    body: `Version ${version} is ready to install.`,
    icon: chrome.runtime.getURL('icons/icon48.png'),
    requireInteraction: true
  });

  notification.onclick = () => {
    ensureDashboardOpen();
    // Switch to Help & Updates tab
    const helpBtn = document.querySelector('.tab-btn[data-tab="tab-help"]');
    if (helpBtn) helpBtn.click();
    notification.close();
  };
}

function checkForUpdate() {
  currentUpdateState.checking = true;
  currentUpdateState.error = null;
  renderUpdatePanel();
  send({ type: 'CHECK_FOR_UPDATE' });
}

function executeUpdate() {
  if (!currentUpdateState.hasUpdate) return;
  // Updates are applied externally by re-running install.bat, which downloads
  // the latest extension.zip and extracts it over the install folder.
  const url = currentUpdateState.installBatUrl || 'https://hokagez.github.io/extension-update-pipeline/install.bat';
  try {
    chrome.tabs.create({ url });
  } catch (_) {
    window.open(url, '_blank');
  }
  updateStatus.textContent = 'Download install.bat, close the browser, run it, then reload the extension.';
}

// ===== AUTO-DIAGNOSTICS HEALTH CHECK TIMER =====
let autoCheckTimer = null;
const AUTO_CHECK_INTERVAL_MS = 20 * 60 * 1000; // 20 minutes

function startAutoHealthCheck() {
  if (autoCheckTimer) clearInterval(autoCheckTimer);
  
  const updateNextCheckHint = () => {
    const nextCheck = new Date(Date.now() + AUTO_CHECK_INTERVAL_MS);
    const hintEl = $('nextAutoCheckHint');
    if (hintEl) {
      hintEl.textContent = `Next auto check: ${nextCheck.toLocaleTimeString()}`;
    }
  };

  updateNextCheckHint();

  autoCheckTimer = setInterval(() => {
    consoleLog('info', 'sys', 'Running auto-health diagnostics check...');
    send({ type: 'DIAGNOSE' });
    updateNextCheckHint();
  }, AUTO_CHECK_INTERVAL_MS);
}

// Diagnostic buttons
$('runDiagnosticsBtn').addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Running diagnostics...</div>';
  send({ type: 'DIAGNOSE' });
});

$('testHeroCareBtn').addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Testing HeroCare ticket detection...</div>';
  send({ type: 'TEST_TICKET_DETECTION' });
});

$('testOpBtn').addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Testing Operation Portal...</div>';
  send({ type: 'DIAGNOSE' });
});

$('testVpnBtn').addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Testing VPN status...</div>';
  send({ type: 'TEST_VPN' });
});

// Feature tests (added since commit e8ceec4)
$('testOpUrlParsingBtn')?.addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Testing OP order URL parsing...</div>';
  send({ type: 'TEST_OP_URL_PARSING' });
});

/* DISABLED — photo comparison not a fraud checklist item per agent feedback
$('testPhotoComparisonBtn')?.addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Testing Gemini photo comparison...</div>';
  send({ type: 'TEST_PHOTO_COMPARISON' });
});
*/

$('testStopScrapingBtn')?.addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Testing stop scraping signal...</div>';
  send({ type: 'TEST_STOP_SCRAPING' });
});

$('testDeletedAccountNotesBtn')?.addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Testing deleted-account note keyword detection...</div>';
  send({ type: 'TEST_DELETED_ACCOUNT_NOTES' });
});

$('testConnectedDepthBtn')?.addEventListener('click', () => {
  $('diagOutput').innerHTML = '<div class="empty">Testing connected account depth controls...</div>';
  send({ type: 'TEST_CONNECTED_DEPTH' });
});

// Console Filters & Clear
document.querySelectorAll('.console-filter').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.console-filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    consoleFilter = btn.getAttribute('data-filter');
    
    document.querySelectorAll('.console-line').forEach(line => {
      const lineLevel = line.getAttribute('data-level');
      if (consoleFilter === 'all' || lineLevel === consoleFilter) {
        line.style.display = '';
      } else {
        line.style.display = 'none';
      }
    });
  });
});

clearConsoleBtn.addEventListener('click', () => {
  consoleOutput.innerHTML = '';
});

// ===== HOME TAB INTERACTIVE CONTROLS =====
pausePlayBtn.addEventListener('click', () => {
  const isPaused = currentState.isPaused ?? true;
  if (isPaused) {
    send({ type: 'SET_PAUSE', payload: false });
    send({ type: 'START_PROCESSING' });
  } else {
    send({ type: 'SET_PAUSE', payload: true });
  }
});

skipBtn.addEventListener('click', () => {
  send({ type: 'SKIP_TICKET' });
});

if (stopScrapeBtn) {
  stopScrapeBtn.addEventListener('click', () => {
    send({ type: 'STOP_SCRAPING' });
  });
}

confirmBtn.addEventListener('click', () => {
  const noteKey = document.getElementById('fraudNoteSelect')?.value;
  const editedApology = document.getElementById('dashEditApology')?.value?.trim();
  const activeNote = document.querySelector('.note-preview.active textarea');
  const editedNote = activeNote ? activeNote.value.trim() : undefined;
  send({ type: 'CONFIRM_EXECUTION', payload: { action: 'execute', noteKey, editedApology, editedNote } });
});

overrideBtn.addEventListener('click', () => {
  const newVerdict = currentState.pendingConfirmation?.verdict === 'FRAUD' ? 'NOT_FRAUD' : 'FRAUD';
  const noteKey = document.getElementById('fraudNoteSelect')?.value;
  const editedApology = document.getElementById('dashEditApology')?.value?.trim();
  const activeNote = document.querySelector('.note-preview.active textarea');
  const editedNote = activeNote ? activeNote.value.trim() : undefined;
  // If overriding NOT_FRAUD -> FRAUD, agent must confirm the note reason.
  if (newVerdict === 'FRAUD') {
    if (!noteKey) {
      alert('Please select a fraud note reason before overriding to FRAUD.');
      return;
    }
  }
  send({ type: 'CONFIRM_EXECUTION', payload: { action: 'override', verdict: newVerdict, noteKey, editedApology, editedNote } });
});

confirmSkipBtn.addEventListener('click', () => {
  send({ type: 'CONFIRM_EXECUTION', payload: { action: 'skip' } });
});

modeSelect.addEventListener('change', () => {
  send({ type: 'SET_MODE', payload: modeSelect.value });
});

// Update controls
if (checkUpdateBtn) {
  checkUpdateBtn.addEventListener('click', checkForUpdate);
}
if (updateNowBtn) {
  updateNowBtn.addEventListener('click', executeUpdate);
}

// Save Settings Button
if (saveSettingsBtn) {
  saveSettingsBtn.addEventListener('click', () => {
    const updated = collectSettings();
    send({ type: 'UPDATE_SETTINGS', payload: updated });
    
    // Visual feedback
    const originalText = saveSettingsBtn.innerHTML;
    saveSettingsBtn.innerHTML = '<i class="ph-bold ph-check btn-icon"></i> Settings Saved!';
    saveSettingsBtn.disabled = true;
    setTimeout(() => {
      saveSettingsBtn.innerHTML = originalText;
      saveSettingsBtn.disabled = false;
    }, 1500);
  });
}

// Segmented Mode Switcher click listener
document.addEventListener('DOMContentLoaded', () => {
  const segmentBtns = document.querySelectorAll('.segment-btn');
  segmentBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const mode = btn.getAttribute('data-mode');
      if (modeSelect) {
        modeSelect.value = mode;
        modeSelect.dispatchEvent(new Event('change'));
      }
      segmentBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });
});

function investigate() {
  const val = (caseInput.value || '').trim();
  if (!val) {
    caseHint.style.color = 'var(--warning)';
    caseHint.textContent = 'Paste a case URL or UUID first.';
    return;
  }
  caseHint.style.color = 'var(--text-muted)';
  caseHint.textContent = 'Opening case…';
  send({ type: 'INVESTIGATE_CASE', payload: { input: val } });
  caseInput.value = '';
}

investigateBtn.addEventListener('click', investigate);
caseInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') investigate(); });

// ===== INIT =====
connect();
consoleLog('info', 'sys', 'Dashboard loaded, connecting to extension...');
updateOnboarding();
startAutoHealthCheck();
renderUpdatePanel();
