@echo off
setlocal EnableDelayedExpansion

REM Native Messaging host wrapper for the Fraud Detection extension updater.
REM Chrome launches this .cmd file and communicates via stdin/stdout.
REM We delegate the actual work to helper.ps1.

set "PS1PATH=%~dp0helper.ps1"

if not exist "%PS1PATH%" (
  echo helper.ps1 not found at %PS1PATH% >&2
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1PATH%"
