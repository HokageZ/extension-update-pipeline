# Native Messaging host for Fraud Detection Extension Updater.
# Chrome launches helper.cmd, which calls this PowerShell script.
# Communication protocol: 4-byte length prefix + UTF-8 JSON.

$ErrorActionPreference = 'Stop'

$logFile = Join-Path $env:TEMP 'fd-updater-host.log'

function Write-Log($message) {
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    "$ts $message" | Out-File -FilePath $logFile -Append -Encoding UTF8
}

function Read-Message {
    $stdin = [System.Console]::OpenStandardInput()
    $lengthBytes = New-Object byte[] 4
    $read = $stdin.Read($lengthBytes, 0, 4)
    if ($read -lt 4) { return $null }
    # Chrome sends length in little-endian
    $length = [BitConverter]::ToInt32($lengthBytes, 0)
    if ($length -le 0 -or $length -gt 10MB) { return $null }
    $buffer = New-Object byte[] $length
    $totalRead = 0
    while ($totalRead -lt $length) {
        $read = $stdin.Read($buffer, $totalRead, $length - $totalRead)
        if ($read -eq 0) { break }
        $totalRead += $read
    }
    $json = [System.Text.Encoding]::UTF8.GetString($buffer, 0, $totalRead)
    return $json | ConvertFrom-Json
}

function Write-Message($obj) {
    $json = $obj | ConvertTo-Json -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $lengthBytes = [BitConverter]::GetBytes([int]$bytes.Length)
    $stdout = [System.Console]::OpenStandardOutput()
    $stdout.Write($lengthBytes, 0, 4)
    $stdout.Write($bytes, 0, $bytes.Length)
    $stdout.Flush()
}

function Send-Error($message) {
    Write-Log "ERROR: $message"
    Write-Message @{ status = 'error'; error = $message }
}

function Send-Ok($version) {
    Write-Log "OK: update applied to $version"
    Write-Message @{ status = 'ok'; version = $version }
}

function Copy-FilesWithRetry($source, $destination, $maxRetries = 5) {
    $retry = 0
    while ($retry -lt $maxRetries) {
        try {
            Copy-Item -Path "$source\*" -Destination $destination -Recurse -Force -ErrorAction Stop
            return
        } catch {
            $retry++
            Write-Log "Copy attempt $retry failed: $($_.Exception.Message)"
            if ($retry -ge $maxRetries) { throw }
            Start-Sleep -Milliseconds (500 * $retry)
        }
    }
}

try {
    Write-Log 'Host started'
    $message = Read-Message
    if (-not $message) {
        Send-Error 'No message received from extension'
        exit 1
    }

    Write-Log ("Received action: {0}" -f $message.action)

    if ($message.action -ne 'update') {
        Send-Error "Unknown action: $($message.action)"
        exit 1
    }

    $extensionId = $message.extensionId
    $zipUrl = $message.url
    $version = $message.version

    if (-not $zipUrl) {
        Send-Error 'Missing update URL'
        exit 1
    }

    # Read the extension folder path from config
    $configPath = Join-Path $env:APPDATA 'FD-Updater\config.json'
    if (-not (Test-Path $configPath)) {
        Send-Error "Updater not configured. Run install-updater.bat first."
        exit 1
    }

    $config = Get-Content $configPath | ConvertFrom-Json
    $extensionPath = $config.extensionPath

    if (-not $extensionPath) {
        Send-Error 'Extension path not configured'
        exit 1
    }

    if (-not (Test-Path $extensionPath)) {
        Send-Error "Extension path not found: $extensionPath"
        exit 1
    }

    # Verify the folder contains our extension manifest
    $manifestPath = Join-Path $extensionPath 'manifest.json'
    if (-not (Test-Path $manifestPath)) {
        Send-Error "manifest.json not found in $extensionPath"
        exit 1
    }

    # Download the update zip
    Write-Log "Downloading update from $zipUrl"
    $tempFile = Join-Path $env:TEMP "fd-extension-update-$version.zip"
    if (Test-Path $tempFile) {
        Remove-Item -Path $tempFile -Force
    }
    Invoke-WebRequest -Uri $zipUrl -OutFile $tempFile -UseBasicParsing

    if (-not (Test-Path $tempFile)) {
        Send-Error 'Download failed'
        exit 1
    }

    Write-Log "Downloaded $tempFile"

    # Extract to a temp staging folder first, then copy to extension path
    $stagingPath = Join-Path $env:TEMP "fd-extension-staging-$version"
    if (Test-Path $stagingPath) {
        Remove-Item -Path $stagingPath -Recurse -Force
    }
    Expand-Archive -Path $tempFile -DestinationPath $stagingPath -Force

    # The zip contains an `extension/` folder at the root (from build-crx.js).
    # Move its contents to the actual extension path.
    $innerExtensionPath = Join-Path $stagingPath 'extension'
    if (-not (Test-Path $innerExtensionPath)) {
        # Fallback: the zip root might be the extension contents directly
        $innerExtensionPath = $stagingPath
    }

    Write-Log "Copying update to $extensionPath"
    Copy-FilesWithRetry -source $innerExtensionPath -destination $extensionPath

    # Clean up
    Remove-Item -Path $tempFile -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $stagingPath -Recurse -Force -ErrorAction SilentlyContinue

    Write-Log 'Update copied successfully'
    Send-Ok $version
} catch {
    Send-Error $_.Exception.Message
    exit 1
}
