# Native Messaging host for Fraud Detection Extension Updater.
# Chrome launches helper.cmd, which calls this PowerShell script.
# Communication protocol: 4-byte length prefix + UTF-8 JSON.

$ErrorActionPreference = 'Stop'

function Read-Message {
    $stdin = [System.Console]::OpenStandardInput()
    $lengthBytes = New-Object byte[] 4
    $read = $stdin.Read($lengthBytes, 0, 4)
    if ($read -lt 4) { return $null }
    # Chrome sends length in little-endian
    $length = [BitConverter]::ToInt32($lengthBytes, 0)
    if ($length -le 0 -or $length -gt 10MB) { return $null }
    $buffer = New-Object byte[] $length
    $totalRead = 0
    while ($totalRead -lt $length) {
        $read = $stdin.Read($buffer, $totalRead, $length - $totalRead)
        if ($read -eq 0) { break }
        $totalRead += $read
    }
    $json = [System.Text.Encoding]::UTF8.GetString($buffer, 0, $totalRead)
    return $json | ConvertFrom-Json
}

function Write-Message($obj) {
    $json = $obj | ConvertTo-Json -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $lengthBytes = [BitConverter]::GetBytes([int]$bytes.Length)
    $stdout = [System.Console]::OpenStandardOutput()
    $stdout.Write($lengthBytes, 0, 4)
    $stdout.Write($bytes, 0, $bytes.Length)
    $stdout.Flush()
}

function Send-Error($message) {
    Write-Message @{ status = 'error'; error = $message }
}

function Send-Ok($version) {
    Write-Message @{ status = 'ok'; version = $version }
}

try {
    $message = Read-Message
    if (-not $message) {
        Send-Error 'No message received from extension'
        exit 1
    }

    if ($message.action -ne 'update') {
        Send-Error "Unknown action: $($message.action)"
        exit 1
    }

    $extensionId = $message.extensionId
    $zipUrl = $message.url
    $version = $message.version

    if (-not $zipUrl) {
        Send-Error 'Missing update URL'
        exit 1
    }

    # Read the extension folder path from config
    $configPath = Join-Path $env:APPDATA 'FD-Updater\config.json'
    if (-not (Test-Path $configPath)) {
        Send-Error "Updater not configured. Run install-updater.bat first."
        exit 1
    }

    $config = Get-Content $configPath | ConvertFrom-Json
    $extensionPath = $config.extensionPath

    if (-not $extensionPath) {
        Send-Error 'Extension path not configured'
        exit 1
    }

    if (-not (Test-Path $extensionPath)) {
        Send-Error "Extension path not found: $extensionPath"
        exit 1
    }

    # Verify the folder contains our extension manifest with matching ID
    $manifestPath = Join-Path $extensionPath 'manifest.json'
    if (-not (Test-Path $manifestPath)) {
        Send-Error "manifest.json not found in $extensionPath"
        exit 1
    }

    $manifest = Get-Content $manifestPath | ConvertFrom-Json
    if ($manifest.key) {
        # Unpacked extensions loaded from source don't have an ID in manifest.
        # Chrome derives the ID from the public key in the .crx, but unpacked
        # extensions loaded without a key will have a generated ID.
        # We trust the path from config as long as manifest.json exists.
    }

    # Download the update zip
    $tempFile = Join-Path $env:TEMP "fd-extension-update-$version.zip"
    Invoke-WebRequest -Uri $zipUrl -OutFile $tempFile -UseBasicParsing

    if (-not (Test-Path $tempFile)) {
        Send-Error 'Download failed'
        exit 1
    }

    # Extract to a temp staging folder first, then copy to extension path
    $stagingPath = Join-Path $env:TEMP "fd-extension-staging-$version"
    if (Test-Path $stagingPath) {
        Remove-Item -Path $stagingPath -Recurse -Force
    }
    Expand-Archive -Path $tempFile -DestinationPath $stagingPath -Force

    # The zip contains an `extension/` folder at the root (from build-crx.js).
    # Move its contents to the actual extension path.
    $innerExtensionPath = Join-Path $stagingPath 'extension'
    if (-not (Test-Path $innerExtensionPath)) {
        # Fallback: the zip root might be the extension contents directly
        $innerExtensionPath = $stagingPath
    }

    # Copy files recursively, overwriting existing
    Copy-Item -Path "$innerExtensionPath\*" -Destination $extensionPath -Recurse -Force

    # Clean up
    Remove-Item -Path $tempFile -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $stagingPath -Recurse -Force -ErrorAction SilentlyContinue

    Send-Ok $version
} catch {
    Send-Error $_.Exception.Message
    exit 1
}
