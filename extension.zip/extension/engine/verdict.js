/**
 * Verdict Engine — determines FRAUD or NOT_FRAUD based on rate + checklist
 */

function determineVerdict(rateResult, checklistResult, thresholds = {}) {
  const fraudRateThreshold = (thresholds.adjusted_rate_fraud_percent || 39) / 100;
  const reasons = [];

  // Phase 3 check: adjusted rate >= threshold
  if (rateResult && rateResult.rate >= fraudRateThreshold) {
    reasons.push(`Adjusted rate ${rateResult.ratePercent}% >= ${fraudRateThreshold * 100}% threshold`);
    return {
      verdict: 'FRAUD',
      confidence: 'high',
      source: 'rate',
      reasons,
      rateResult,
      checklistResult: null
    };
  }

  // Phase 4 check: any checklist hit
  if (checklistResult && checklistResult.anyHit) {
    checklistResult.hits.forEach(hit => {
      reasons.push(`Check #${hit.checkNumber} (${hit.checkName}): ${hit.reason}`);
    });
    return {
      verdict: 'FRAUD',
      confidence: checklistResult.hitCount >= 3 ? 'high' : 'medium',
      source: 'checklist',
      reasons,
      rateResult,
      checklistResult
    };
  }

  // No fraud indicators
  return {
    verdict: 'NOT_FRAUD',
    confidence: 'high',
    source: 'clear',
    reasons: ['Adjusted rate below threshold', 'All checklist items passed'],
    rateResult,
    checklistResult
  };
}

// Canned responses (defaults). The dashboard can override these with MULTIPLE
// responses per case; the system then picks a random one each time so replies
// don't look templated.
const RESPONSES = {
  R1: 'نعتذر لك على الإشكاليه الحاصلة بطلبك. للأسف لا نستطيع التعويض في الوقت الحالي.',
  R3: 'نعتذر لك على الإشكاليه الحاصلة بطلبك. تم تصعيد التذكرة مسبقًا ويمكنك التحقق من رد القسم المختص من خلال إتباع الخطوات التالية:\n1. حسابي\n2. المساعدة والدعم\n3. تتبع التذاكر'
};

function pickRandom(list, fallback) {
  const arr = (list || []).map(s => (s == null ? '' : String(s)).trim()).filter(Boolean);
  if (arr.length === 0) return fallback;
  return arr[Math.floor(Math.random() * arr.length)];
}

// isPreExistingTicket parameter retained for interface compatibility in tests/verdict.js
// but we pull randomly from the single shared pool (settings.fraud_responses).
function getFraudResponse(isPreExistingTicket, settings = {}) {
  const defaults = [
    'نعتذر لك على الإشكاليه الحاصلة بطلبك. للأسف لا نستطيع التعويض في الوقت الحالي.',
    'نعتذر لك على الإشكاليه الحاصلة بطلبك. تم تصعيد التذكرة مسبقًا ويمكنك التحقق من رد القسم المختص من خلال إتباع الخطوات التالية:\n1. حسابي\n2. المساعدة والدعم\n3. تتبع التذاكر'
  ];
  return pickRandom(settings.fraud_responses, defaults[isPreExistingTicket ? 1 : 0]);
}

const DEFAULT_NOTE = 'سجل سيء - عدد تعويضات عالية وشكاوي بالنسبة للطلبات الناجحه - اعتذار';

function getFraudNote(verdictOrReasonText, settings = {}) {
  const defaults = {
    rate: 'سجل سيء - عدد تعويضات عالية وشكاوي بالنسبة للطلبات الناجحه - اعتذار',
    same_day_frequency: 'سجل سيء تعويضات مرتفعه اخر فتره اعتذار',
    bulk_drinks: 'حساب جيد -كميه مشروبات - اعتذار',
    all_system_comps: 'سجل سئ تعويضات متكرره اعتذار',
    photo_mismatch: 'حساب العميل غير جيد بسبب تناقض صور التسليم مع شكوى العميل. تم الاعتذار.',
    blocked_device: 'سيئ على البوابة +مرتبط بحساب سيئ +اعتذار',
    new_account_abuse: 'حساب العميل غير جيد بسبب طلب تعويضات على حساب جديد. تم الاعتذار.',
    duplicate_order_comp: 'حساب العميل غير جيد بسبب تكرار التعويض لنفس الطلب. تم الاعتذار.',
    same_reason_pattern: 'سجل سئ تعويضات متكرره اعتذار',
    excessive_comp_ratio: 'سجل سيء - تعويضات مرتفعة اخر فتره - و شكاوي متكرره - اعتذار',
    connected_accounts: 'سجل سئ //مرتبط بحساب محظور// اعتذار'
  };

  // 1. Support legacy string reason text (e.g. for unit tests)
  if (typeof verdictOrReasonText === 'string') {
    const singlePattern = settings.fraud_note || 
      (Array.isArray(settings.fraud_notes) ? settings.fraud_notes[0] : null) || 
      (settings.fraud_notes && typeof settings.fraud_notes === 'object' ? settings.fraud_notes.rate : null) ||
      DEFAULT_NOTE;
    return singlePattern.replace(/{reason}/g, verdictOrReasonText).replace(/{rate}/g, '39');
  }

  // 2. Modern reason-specific dictionary lookup by verdict object
  const verdict = verdictOrReasonText;
  const keyMap = {
    1: 'same_day_frequency',
    2: 'bulk_drinks',
    3: 'all_system_comps',
    4: 'photo_mismatch',
    5: 'blocked_device',
    6: 'new_account_abuse',
    7: 'duplicate_order_comp',
    8: 'same_reason_pattern',
    9: 'excessive_comp_ratio',
    10: 'connected_accounts'
  };

  let reasonKey = 'rate'; // default fallback for rate-based fraud
  if (verdict && verdict._selectedNoteKey) {
    reasonKey = verdict._selectedNoteKey;
  } else if (verdict && verdict.source === 'checklist' && verdict.checklistResult?.hits?.length) {
    const firstHitNum = verdict.checklistResult.hits[0].checkNumber;
    reasonKey = keyMap[firstHitNum] || 'rate';
  }

  const notesObj = settings.fraud_notes || {};
  let pattern = notesObj[reasonKey] || defaults[reasonKey] || defaults.rate;

  // Replace {rate} if present and rateResult is available
  if (verdict && verdict.rateResult && verdict.rateResult.ratePercent !== undefined) {
    pattern = pattern.replace(/{rate}/g, verdict.rateResult.ratePercent);
  } else {
    pattern = pattern.replace(/{rate}/g, '39');
  }
  
  return pattern;
}

if (typeof module !== 'undefined') {
  module.exports = { determineVerdict, getFraudResponse, getFraudNote, RESPONSES };
}
