/**
 * 9-Item Investigation Checklist
 * Each check returns { hit: boolean, reason: string }
 * Any single hit = FRAUD
 *
 * The checklist operates on a TRAILING WINDOW (default 30 days) of compensation
 * history. The FULL history is used only for the adjusted-rate calculation
 * (see rate-calculator.js) — not here. Pass thresholds.checklist_window_days
 * to change the window, and `referenceDate` to make windowing deterministic
 * in tests.
 */

// Keep rows whose date falls within `windowDays` of referenceDate.
// Rows with a missing/unparseable date are KEPT (fraud-safe: don't silently
// drop evidence just because a cell didn't parse).
function filterToWindow(rows, windowDays, referenceDate) {
  if (!rows || !Array.isArray(rows)) return [];
  if (!windowDays || windowDays <= 0) return rows;

  const ref = referenceDate ? new Date(referenceDate) : new Date();
  if (isNaN(ref.getTime())) return rows;
  const cutoff = ref.getTime() - windowDays * 24 * 60 * 60 * 1000;

  return rows.filter(row => {
    if (!row || !row.date) return true; // keep undated rows
    const d = new Date(String(row.date).replace(' ', 'T'));
    if (isNaN(d.getTime())) return true; // keep unparseable rows
    return d.getTime() >= cutoff;
  });
}

function runChecklist(data, thresholds = {}) {
  const t = {
    same_day_comp_min_count: thresholds.same_day_comp_min_count || 2,
    bulk_drinks_min_quantity: thresholds.bulk_drinks_min_quantity || 20,
    same_reason_dominance_percent: thresholds.same_reason_dominance_percent || 90,
    new_account_abuse_days: thresholds.new_account_abuse_days || 2,
    excessive_ratio_threshold: thresholds.excessive_ratio_threshold || 0.5,
    checklist_window_days: 30,
    ...thresholds
  };

  // Window the compensation rows BEFORE every date-based check. The full,
  // unwindowed history stays in rate-calculator (the rate is lifetime).
  const windowedRows = filterToWindow(
    data.compensationRows,
    t.checklist_window_days,
    data.referenceDate
  );

  const results = [
    checkSameDayFrequency(windowedRows, t.same_day_comp_min_count),
    checkBulkDrinks(windowedRows, data.orderDetails, t.bulk_drinks_min_quantity),
    checkAllSystemCompensations(windowedRows),
    /* DISABLED — photo comparison is not a fraud checklist item per agent feedback.
       The checkPhotoMismatch() function and Gemini service remain in the codebase
       for future use.
    checkPhotoMismatch(data.photoComparison),
    */
    { hit: false, reason: 'Photo comparison disabled from fraud checklist', checkName: 'Photo Mismatch' },
    checkBlockedDevice(data.blockedDevice, data.blockedAccount),
    checkNewAccountAbuse(data.userCreatedAt, windowedRows, t.new_account_abuse_days),
    checkDuplicateOrderComp(windowedRows),
    checkSameReasonPattern(windowedRows, t.same_reason_dominance_percent),
    checkExcessiveRatio(data.adjustedRate, t.excessive_ratio_threshold),
    checkConnectedAccounts(data.connectedAccounts)
  ];

  return {
    windowDays: t.checklist_window_days,
    windowedRowCount: windowedRows.length,
    totalRowCount: (data.compensationRows || []).length,
    results,
    anyHit: results.some(r => r.hit),
    hitCount: results.filter(r => r.hit).length,
    hits: results.reduce((acc, r, i) => {
      if (r.hit) acc.push({ checkNumber: i + 1, ...r });
      return acc;
    }, [])
  };
}

// Check 1: Same-Day Compensation Frequency
function checkSameDayFrequency(rows, minCount) {
  if (!rows || rows.length === 0) return { hit: false, reason: 'No compensation data', checkName: 'Same-Day Comp Frequency' };

  const dateMap = {};
  rows.forEach(row => {
    if (!row.date) return;
    const day = row.date.split(' ')[0].split('T')[0];
    if (!dateMap[day]) dateMap[day] = new Set();
    dateMap[day].add(row.orderId);
  });

  const multiDays = Object.entries(dateMap).filter(([_, orders]) => orders.size >= minCount);

  if (multiDays.length > 0) {
    return {
      hit: true,
      reason: `${multiDays.length} day(s) with ${minCount}+ distinct orders compensated. Dates: ${multiDays.map(d => d[0]).join(', ')}`,
      checkName: 'Same-Day Comp Frequency'
    };
  }
  return { hit: false, reason: 'No same-day multi-order compensations found', checkName: 'Same-Day Comp Frequency' };
}

// Check 2: Bulk Drinks
function checkBulkDrinks(rows, orderDetails, minQuantity) {
  if (!rows || rows.length === 0) return { hit: false, reason: 'No compensation data', checkName: 'Bulk Drinks' };

  const drinkKeywords = [
    'pepsi', 'بيبسي', 'coca', 'كوكا', 'sprite', 'سبرايت', 'fanta', 'فانتا',
    'mirinda', 'ميرندا', 'mountain dew', 'ماونتن', 'red bull', 'ريد بول',
    'water', 'مياه', 'ماء', 'juice', 'عصير', 'milk', 'حليب', 'مشروب',
    'drink', 'can', 'bottle', 'علبة', 'زجاجة', 'seven up', 'سفن اب'
  ];

  if (orderDetails && Array.isArray(orderDetails)) {
    const drinkItems = orderDetails.filter(item => {
      const name = (item.name || '').toLowerCase();
      return drinkKeywords.some(kw => name.includes(kw));
    });
    const totalDrinkQty = drinkItems.reduce((sum, item) => sum + (item.quantity || 1), 0);
    const totalItems = orderDetails.reduce((sum, item) => sum + (item.quantity || 1), 0);

    if (totalDrinkQty >= minQuantity && totalDrinkQty > totalItems * 0.6) {
      return {
        hit: true,
        reason: `${totalDrinkQty} drink items out of ${totalItems} total (${Math.round(totalDrinkQty / totalItems * 100)}%)`,
        checkName: 'Bulk Drinks'
      };
    }
  }

  return { hit: false, reason: 'No bulk drink pattern detected', checkName: 'Bulk Drinks' };
}

// Check 3: All-System Compensations
function checkAllSystemCompensations(rows) {
  if (!rows || rows.length === 0) return { hit: false, reason: 'No compensation data', checkName: 'All-System Compensations' };
  if (rows.length <= 1) return { hit: false, reason: 'Not enough compensation history', checkName: 'All-System Compensations' };

  const systemKeywords = ['system', 'auto', 'نظام', 'autocomp'];
  const systemRows = rows.filter(row => {
    const agent = (row.agent || '').toLowerCase();
    const type = (row.type || '').toLowerCase();
    return systemKeywords.some(kw => agent.includes(kw) || type.includes(kw));
  });

  if (systemRows.length === rows.length) {
    return {
      hit: true,
      reason: `All ${rows.length} compensations were processed by system (zero manual agent approvals)`,
      checkName: 'All-System Compensations'
    };
  }
  return {
    hit: false,
    reason: `${systemRows.length}/${rows.length} system-processed`,
    checkName: 'All-System Compensations'
  };
}

// Check 4: Rider vs Customer Photo Mismatch
function checkPhotoMismatch(photoComparison) {
  if (!photoComparison) return { hit: false, reason: 'No photo comparison available', checkName: 'Photo Mismatch', needsReview: true };
  if (photoComparison.status === 'NEEDS_HUMAN_REVIEW') return { hit: false, reason: photoComparison.reason || 'Photo comparison needs human review', checkName: 'Photo Mismatch', needsReview: true };

  if (photoComparison.status === 'YES') {
    return {
      hit: true,
      reason: `Photo contradiction detected: ${photoComparison.reason || 'rider photo contradicts customer claim'}`,
      checkName: 'Photo Mismatch'
    };
  }
  return { hit: false, reason: 'No photo contradiction', checkName: 'Photo Mismatch' };
}

// Check 5: Blocked Device/Account
function checkBlockedDevice(blockedDevice, blockedAccount) {
  if (blockedDevice || blockedAccount) {
    const reasons = [];
    if (blockedDevice) reasons.push('Device previously blocked');
    if (blockedAccount) reasons.push('Account previously blocked');
    return { hit: true, reason: reasons.join('; '), checkName: 'Blocked Device/Account' };
  }
  return { hit: false, reason: 'No blocked device or account', checkName: 'Blocked Device/Account' };
}

// Check 6: New Account Abuse
function checkNewAccountAbuse(userCreatedAt, rows, maxDays) {
  if (!userCreatedAt || !rows || rows.length === 0) {
    return { hit: false, reason: 'Missing account creation date or comp data', checkName: 'New Account Abuse' };
  }

  const createdDate = new Date(userCreatedAt);
  if (isNaN(createdDate.getTime())) {
    return { hit: false, reason: 'Invalid account creation date', checkName: 'New Account Abuse' };
  }

  const earliestComp = rows
    .map(r => new Date(r.date))
    .filter(d => !isNaN(d.getTime()))
    .sort((a, b) => a - b)[0];

  if (!earliestComp) return { hit: false, reason: 'No valid comp dates', checkName: 'New Account Abuse' };

  const diffDays = (earliestComp - createdDate) / (1000 * 60 * 60 * 24);

  if (diffDays <= maxDays) {
    return {
      hit: true,
      reason: `First compensation ${diffDays.toFixed(1)} days after account creation (threshold: ${maxDays} days)`,
      checkName: 'New Account Abuse'
    };
  }
  return { hit: false, reason: `First comp ${diffDays.toFixed(1)} days after creation`, checkName: 'New Account Abuse' };
}

// Check 7: Duplicate Order Comp
function checkDuplicateOrderComp(rows) {
  if (!rows || rows.length === 0) return { hit: false, reason: 'No compensation data', checkName: 'Duplicate Order Comp' };

  const orderCounts = {};
  rows.forEach(row => {
    if (row.orderId) {
      orderCounts[row.orderId] = (orderCounts[row.orderId] || 0) + 1;
    }
  });

  const duplicates = Object.entries(orderCounts).filter(([_, count]) => count > 1);

  if (duplicates.length > 0) {
    return {
      hit: true,
      reason: `${duplicates.length} order(s) compensated multiple times: ${duplicates.map(d => `${d[0]} (${d[1]}x)`).join(', ')}`,
      checkName: 'Duplicate Order Comp'
    };
  }
  return { hit: false, reason: 'No duplicate order compensations', checkName: 'Duplicate Order Comp' };
}

// Check 8: Same Reason Pattern
function checkSameReasonPattern(rows, dominancePercent) {
  if (!rows || rows.length < 3) return { hit: false, reason: 'Not enough data for pattern analysis', checkName: 'Same Reason Pattern' };

  const reasonCounts = {};
  rows.forEach(row => {
    const reason = (row.rule || row.reason || 'unknown').toLowerCase().trim();
    reasonCounts[reason] = (reasonCounts[reason] || 0) + 1;
  });

  const sorted = Object.entries(reasonCounts).sort((a, b) => b[1] - a[1]);
  const topReason = sorted[0];
  const topPercent = (topReason[1] / rows.length) * 100;

  if (topPercent >= dominancePercent) {
    return {
      hit: true,
      reason: `"${topReason[0]}" dominates at ${topPercent.toFixed(1)}% (${topReason[1]}/${rows.length} rows, threshold: ${dominancePercent}%)`,
      checkName: 'Same Reason Pattern'
    };
  }
  return { hit: false, reason: `Top reason "${topReason[0]}" at ${topPercent.toFixed(1)}%`, checkName: 'Same Reason Pattern' };
}

// Check 9: Excessive Comp Ratio
// NOTE on thresholds: this hard-coded default (0.5) is only a fallback for the
// rare caller that passes no thresholds. The LIVE value comes from
// config/default-settings.json → thresholds.excessive_ratio_threshold (0.30).
// Because rate >= adjusted_rate_fraud_percent (0.39) short-circuits to FRAUD via
// the rate gate BEFORE the checklist runs, this check can only actually fire in
// the 0.30–0.39 band (and inside the connected-account sub-evaluations, which
// run the checklist directly without the rate gate). CLAUDE.md still documents
// 0.5 — the settings file is the source of truth.
function checkExcessiveRatio(adjustedRate, threshold) {
  if (adjustedRate === null || adjustedRate === undefined) {
    return { hit: false, reason: 'No adjusted rate available', checkName: 'Excessive Comp Ratio' };
  }

  if (adjustedRate >= threshold) {
    return {
      hit: true,
      reason: `Adjusted rate ${(adjustedRate * 100).toFixed(1)}% exceeds threshold ${(threshold * 100).toFixed(1)}%`,
      checkName: 'Excessive Comp Ratio'
    };
  }
  return { hit: false, reason: `Rate ${(adjustedRate * 100).toFixed(1)}% below threshold`, checkName: 'Excessive Comp Ratio' };
}

// Check 10: Connected Accounts (device-linked accounts)
// data.connectedAccounts = {
//   evaluated: boolean,            // false if OP/VPN unavailable
//   accounts: [{ userId, deviceId, anyHit, hits: [...] }]
// }
// Hit if ANY linked account is itself fraudulent on its last-30-day history.
function checkConnectedAccounts(connectedAccounts) {
  const name = 'Connected Accounts';
  if (!connectedAccounts || !connectedAccounts.evaluated) {
    return { hit: false, reason: 'Connected accounts not evaluated (OP/VPN unavailable)', checkName: name, needsReview: true };
  }

  const accounts = connectedAccounts.accounts || [];
  if (accounts.length === 0) {
    return { hit: false, reason: 'No linked accounts found on device(s)', checkName: name };
  }

  const bad = accounts.filter(a => a && a.anyHit);
  if (bad.length > 0) {
    const detail = bad.map(a => {
      const reasons = (a.hits || []).map(h => h.checkName || `#${h.checkNumber}`).join(', ');
      const dev = a.viaDeviceId || a.deviceId || '?';
      return `account ${a.userId || '?'} (device ${dev})${reasons ? ': ' + reasons : ''}`;
    }).join('; ');
    return {
      hit: true,
      reason: `${bad.length}/${accounts.length} linked account(s) show fraud indicators — ${detail}`,
      checkName: name
    };
  }

  return { hit: false, reason: `All ${accounts.length} linked account(s) clean in last 30 days`, checkName: name };
}

if (typeof module !== 'undefined') {
  module.exports = {
    runChecklist,
    filterToWindow,
    checkSameDayFrequency,
    checkBulkDrinks,
    checkAllSystemCompensations,
    checkPhotoMismatch,
    checkBlockedDevice,
    checkNewAccountAbuse,
    checkDuplicateOrderComp,
    checkSameReasonPattern,
    checkExcessiveRatio,
    checkConnectedAccounts
  };
}
