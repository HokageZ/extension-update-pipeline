/**
 * Refund Mapper — maps complaint type + payment method to refund codes/amounts
 * Used for NOT_FRAUD cases only.
 */

const COMPLAINT_TYPES = {
  MISSING_ITEM: 'missing_item',
  WRONG_ITEM: 'wrong_item',
  WRONG_ORDER: 'wrong_order',
  QUALITY_ISSUE: 'quality_issue',
  DAMAGED_ORDER: 'damaged_order',
  INCOMPLETE_ORDER: 'incomplete_order'
};

const PAYMENT_METHODS = {
  VISA: 'visa',
  MASTERCARD: 'mastercard',
  MADA: 'mada',
  TABBY: 'tabby',
  TAMARA: 'tamara',
  WALLET: 'wallet',
  COD: 'cod',
  APPLE_PAY: 'apple_pay'
};

const REFUND_CONFIG = {
  [COMPLAINT_TYPES.MISSING_ITEM]: {
    refundReasonCode: 'missing_item',
    compensationReasonCode: 'sorry_missing',
    compensationAmount: 10,
    fullRefundItem: true
  },
  [COMPLAINT_TYPES.WRONG_ITEM]: {
    refundReasonCode: 'wrong_item',
    compensationReasonCode: 'sorry_wrong_item',
    compensationAmount: 10,
    fullRefundItem: true
  },
  [COMPLAINT_TYPES.WRONG_ORDER]: {
    refundReasonCode: 'wrong_order',
    compensationReasonCode: 'sorry_wrong_order',
    compensationAmount: 15,
    fullRefundOrder: true
  },
  [COMPLAINT_TYPES.QUALITY_ISSUE]: {
    refundReasonCode: 'quality',
    compensationReasonCode: 'sorry_quality',
    compensationAmount: 10,
    fullRefundItem: true
  },
  [COMPLAINT_TYPES.DAMAGED_ORDER]: {
    refundReasonCode: 'damaged',
    compensationReasonCode: 'sorry_damaged',
    compensationAmount: 15,
    fullRefundOrder: true
  },
  [COMPLAINT_TYPES.INCOMPLETE_ORDER]: {
    refundReasonCode: 'incomplete',
    compensationReasonCode: 'sorry_incomplete',
    compensationAmount: 10,
    fullRefundItem: true
  }
};

const PAYMENT_DESTINATIONS = {
  [PAYMENT_METHODS.VISA]: ['bank_account', 'wallet'],
  [PAYMENT_METHODS.MASTERCARD]: ['bank_account', 'wallet'],
  [PAYMENT_METHODS.MADA]: ['bank_account', 'wallet'],
  [PAYMENT_METHODS.TABBY]: ['online'],
  [PAYMENT_METHODS.TAMARA]: ['online', 'wallet', 'bank_account'],
  [PAYMENT_METHODS.WALLET]: ['wallet'],
  [PAYMENT_METHODS.COD]: ['wallet'],
  [PAYMENT_METHODS.APPLE_PAY]: ['bank_account', 'wallet']
};

function mapRefund(complaintType, paymentMethod, itemAmount) {
  const config = REFUND_CONFIG[complaintType];
  if (!config) {
    return { error: `Unknown complaint type: ${complaintType}` };
  }

  const destinations = PAYMENT_DESTINATIONS[paymentMethod] || ['wallet'];
  const refundAmount = config.fullRefundOrder ? itemAmount : (config.fullRefundItem ? itemAmount : 0);

  return {
    refundReasonCode: config.refundReasonCode,
    compensationReasonCode: config.compensationReasonCode,
    compensationAmount: config.compensationAmount,
    refundAmount,
    destination: destinations[0],
    availableDestinations: destinations,
    fullRefund: config.fullRefundOrder || false
  };
}

// Cases that are too complex for the bot to auto-refund. We do NOT escalate
// these — the bot SKIPS them and leaves the ticket for a human agent.
function needsManualReview(orderDate, itemCount, amountPaid, amountVoucher, orderTotal) {
  const now = new Date();
  const orderDateObj = new Date(orderDate);
  const daysDiff = (now - orderDateObj) / (1000 * 60 * 60 * 24);

  if (daysDiff > 7) return { skip: true, reason: 'Order older than 7 days' };
  if (itemCount >= 4) return { skip: true, reason: '4+ sub-items to refund' };

  // Discount mismatch: paid + voucher should equal order total
  // Only flag if we have all three values and they don't add up
  if (orderTotal && amountPaid !== null && amountPaid !== undefined) {
    const sumPaid = (amountPaid || 0) + (amountVoucher || 0);
    const diff = Math.abs(sumPaid - orderTotal);
    if (diff > 0.5) { // 0.5 SAR tolerance for rounding
      return { skip: true, reason: `Payment mismatch: paid ${sumPaid} SAR vs order total ${orderTotal} SAR` };
    }
  }

  return { skip: false };
}

if (typeof module !== 'undefined') {
  module.exports = {
    mapRefund,
    needsManualReview,
    COMPLAINT_TYPES,
    PAYMENT_METHODS,
    REFUND_CONFIG,
    PAYMENT_DESTINATIONS
  };
}
