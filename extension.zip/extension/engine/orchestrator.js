/**
 * Orchestrator — wires the full pipeline together
 * Handles: Supervised / Autonomous / Audit modes
 * Runs in the background service worker context
 */

class Orchestrator {
  constructor(settings) {
    this.settings = settings;
    this.state = 'idle';
    this.isPaused = false;
    this.currentTicket = null;
    this.log = [];
    this.stats = { processed: 0, fraud: 0, notFraud: 0, errors: 0, skipped: 0 };
    this.pendingConfirmation = null;
    this.targetTicketId = null; // when set, doIntake opens this specific ticket
    this.investigateCaseId = null; // when set, doIntake navigates straight to a case
    this.investigateOrderId = null; // when set, doIntake runs directly against an OP order
    this.stopScraping = false; // when set, current extraction aborts after present data
    this.oneShot = false; // manual single-ticket runs don't auto-advance the queue
    this.doneThisRun = new Set(); // ticketIds already handled this batch — never re-open
    this.currentTicketId = null;  // the queue ticketId currently open (for doneThisRun)
    this.dismissedNotFraud = new Set(); // orderIds the agent has dismissed as not-fraud
  }

  // Process one specific ticket chosen from the popup queue selector (one-shot).
  solveTicket(ticketId) {
    this.targetTicketId = ticketId || null;
    this.oneShot = true;
    return this.processTicket();
  }

  // Manual investigation: open a specific HeroCare case by id and run the flow (one-shot).
  solveCase(caseId) {
    this.investigateCaseId = caseId || null;
    this.oneShot = true;
    this.stopScraping = false;
    return this.processTicket();
  }

  // Manual investigation: run a specific Operation Portal order id directly (one-shot).
  solveOrder(orderId) {
    this.investigateOrderId = orderId || null;
    this.oneShot = true;
    this.stopScraping = false;
    return this.processTicket();
  }

  // After finishing a ticket: in batch mode advance to the next one; for a
  // manual one-shot run, stop and reset the flag (no queue auto-advance).
  continueIfBatch() {
    if (this.oneShot) { this.oneShot = false; return; }
    if (!this.isPaused) this.processTicket();
  }

  // Mark the open queue ticket as handled this run so the batch loop advances
  // past it (tickets aren't closed in audit/supervised, so we can't rely on the
  // queue dropping them).
  markTicketDone() {
    if (this.currentTicketId) this.doneThisRun.add(this.currentTicketId);
    this.currentTicketId = null;
  }

  async processTicket() {
    if (this.isPaused || this.state !== 'idle') return;

    try {
      // Phase 1: Intake
      this.setState('intake');
      this.intakeFailReason = null;
      this.intakeEmptyQueue = false;
      const intake = await this.doIntake();
      if (!intake) {
        if (this.intakeEmptyQueue) {
          // An empty queue is normal, not a failure — don't count it as an error.
          this.addLog({ type: 'info', message: this.intakeFailReason || 'No tickets to process — the queue may simply be empty.', phase: 'intake' });
          this.setState('idle');
        } else {
          this.handleError(`Intake failed — ${this.intakeFailReason || 'no ticket available'}`, { phase: 'intake', reason: this.intakeFailReason });
        }
        return;
      }
      if (this.dismissedNotFraud.has(intake.orderId)) {
        this.addLog({ type: 'info', message: `Skipping ${intake.orderId} — agent dismissed as NOT_FRAUD`, orderId: intake.orderId });
        this.setState('idle');
        return;
      }
      this.currentTicket = intake;

      await this.checkPause();
      await this.delay('between_actions_ms');

      // Phase 2: Data Extraction
      this.setState('extraction');
      const extracted = await this.doExtraction(intake);
      if (!extracted) { this.handleError('Extraction failed'); return; }

      await this.checkPause();
      await this.delay('between_actions_ms');

      // Phase 3: Rate Calculation
      this.setState('calculation');
      const rateResult = this.doCalculation(extracted);

      // Phase 3 verdict: if rate >= threshold, skip to execution
      const thresholdPct = this.settings.thresholds?.adjusted_rate_fraud_percent || 39;
      const thresholdRate = thresholdPct / 100;
      let checklistResult = null;

      // Verbose: show exactly how the rate was built (adjusted comps / success orders).
      this.addLog({
        type: rateResult.rate >= thresholdRate ? 'warning' : 'info',
        orderId: intake.orderId,
        message: `Rate: ${rateResult.ratePercent ?? '?'}% = ${rateResult.adjustedCompensations} adjusted comps ÷ ${rateResult.successOrders} success orders ` +
                 `(lifetime comps ${rateResult.totalRows}, excluded ${rateResult.excludedCount}; orders ${extracted.totalOrders ?? '?'} − failed ${extracted.failedOrders ?? '?'}). ` +
                 `Threshold ${thresholdPct}% → ${rateResult.rate >= thresholdRate ? 'OVER (FRAUD via rate, checklist skipped)' : 'under (run checklist)'}.`
      });
      if (rateResult.excludedCount > 0 && Array.isArray(rateResult.excluded)) {
        const ex = rateResult.excluded.slice(0, 6).map(e => e.rule || '?').join(', ');
        this.addLog({ type: 'info', orderId: intake.orderId, message: `Rate: excluded ${rateResult.excludedCount} row(s) (delay/modified/empty-autocomp): ${ex}${rateResult.excludedCount > 6 ? ', …' : ''}` });
      }

      if (rateResult.rate < thresholdRate) {
        await this.checkPause();
        // Phase 4: Checklist
        this.setState('checklist');
        await this.delay('between_actions_ms');
        checklistResult = await this.doChecklist(extracted, rateResult);
        this.logChecklist(checklistResult, intake.orderId);
      }

      await this.checkPause();

      // Phase 5: Verdict
      this.setState('verdict');
      const verdict = this.doVerdict(rateResult, checklistResult);

      // Verbose verdict summary: WHY, with the full reason list (always, even when clean).
      const hitN = checklistResult?.hitCount ?? 0;
      const totalChecks = checklistResult?.results?.length ?? 0;
      const reviewN = checklistResult ? checklistResult.results.filter(r => r.needsReview && !r.hit).length : 0;
      const verdictSummary = verdict.verdict === 'FRAUD'
        ? (verdict.source === 'rate'
            ? `FRAUD — adjusted rate ${rateResult.ratePercent}% ≥ ${thresholdPct}% (checklist not run)`
            : `FRAUD — ${hitN}/${totalChecks} checklist item(s) hit`)
        : `NOT FRAUD — rate ${rateResult.ratePercent ?? '?'}% < ${thresholdPct}% and 0/${totalChecks} checklist items hit${reviewN ? ` (${reviewN} need review)` : ''}`;
      this.addLog({ type: verdict.verdict === 'FRAUD' ? 'warning' : 'info', orderId: intake.orderId, message: `Verdict: ${verdictSummary} [confidence ${verdict.confidence || '?'}]` });
      verdict.reasons.forEach((r, i) => {
        this.addLog({ type: 'info', orderId: intake.orderId, message: `  reason ${i + 1}: ${r}` });
      });

      this.addLog({
        orderId: intake.orderId,
        verdict: verdict.verdict,
        reason: verdict.reasons.join('; '),
        rate: rateResult.ratePercent,
        timestamp: new Date().toISOString()
      });

      // Execution
      if (this.settings.mode === 'audit') {
        this.addLog({ type: 'audit', message: `Would execute: ${verdict.verdict}`, orderId: intake.orderId });
        this.stats.processed++;
        if (verdict.verdict === 'FRAUD') this.stats.fraud++;
        else this.stats.notFraud++;
        this.currentTicket = null;
        this.markTicketDone();
        this.setState('idle');
        await this.delay('between_tickets_ms');
        this.continueIfBatch();
      } else if (this.settings.mode === 'supervised') {
        this.pendingConfirmation = { verdict, intake, extracted };
        // Re-broadcast state now that pendingConfirmation is populated. The
        // background's setState hook emits the only STATE_UPDATE that carries
        // pendingConfirmation (via getFullState); without this re-push the
        // sidepanel/dashboard never receive the pending decision, so the
        // verdict card never renders and we sit in 'verdict' forever.
        this.setState('verdict');

        // Auto-skip if agent doesn't confirm within the timeout
        const timeoutMs = this.settings.supervised_confirmation_timeout_ms || 300000;
        this.confirmationTimeout = setTimeout(() => {
          if (this.pendingConfirmation) {
            this.addLog({ type: 'warning', message: `Supervised confirmation timed out after ${timeoutMs / 60000} min — ticket skipped`, orderId: intake.orderId });
            this.stats.skipped++;
            this.pendingConfirmation = null;
            this.currentTicket = null;
            this.markTicketDone();
            this.setState('idle');
            this.broadcast({ type: 'CONFIRMATION_TIMEOUT', payload: { orderId: intake.orderId } });
          }
        }, timeoutMs);
      } else {
        // Autonomous: optional countdown before execution
        const autoDelayMs = this.settings.autonomous_execution_delay_ms ?? 0;
        if (autoDelayMs > 0) {
          this.pendingConfirmation = { verdict, intake, extracted };
          this.setState('countdown');
          this.broadcast({ type: 'AUTONOMOUS_COUNTDOWN', payload: { orderId: intake.orderId, verdict: verdict.verdict, seconds: Math.ceil(autoDelayMs / 1000) } });

          const cancelToken = { cancelled: false };
          this.cancelCountdown = () => { cancelToken.cancelled = true; };

          const start = Date.now();
          while (!cancelToken.cancelled && Date.now() - start < autoDelayMs) {
            await this.checkPause();
            await new Promise(r => setTimeout(r, 200));
          }

          if (cancelToken.cancelled) {
            this.addLog({ type: 'info', message: 'Autonomous countdown cancelled by agent', orderId: intake.orderId });
            this.pendingConfirmation = null;
            this.cancelCountdown = null;
            this.setState('idle');
            return;
          }

          this.pendingConfirmation = null;
          this.cancelCountdown = null;
        }

        this.setState('execution');
        const execResult = await this.doExecution(verdict, intake, extracted);

        if (execResult?.skipped) {
          this.stats.skipped++;
        } else {
          this.stats.processed++;
          if (verdict.verdict === 'FRAUD') this.stats.fraud++;
          else this.stats.notFraud++;
        }

        this.currentTicket = null;
        this.markTicketDone();
        this.setState('idle');
        await this.delay('between_tickets_ms');
        this.continueIfBatch();
      }
    } catch (error) {
      // Report exactly which phase blew up, with the underlying error + stack.
      const phase = this.state || 'unknown';
      const detail = {
        phase,
        orderId: this.currentTicket?.orderId || '(none)',
        error: error?.message || String(error),
        stack: error?.stack ? String(error.stack).split('\n').slice(0, 4).join(' | ') : null
      };
      this.handleError(`Crash during '${phase}' phase: ${detail.error}`, detail);
    }
  }

  async confirmExecution(override = null, noteKey = null) {
    if (!this.pendingConfirmation) return; // double-fire guard
    if (this.confirmationTimeout) { clearTimeout(this.confirmationTimeout); this.confirmationTimeout = null; }
    let { verdict, intake, extracted } = this.pendingConfirmation;

    if (override?.verdict) {
      verdict = {
        ...verdict,
        verdict: override.verdict,
        reasons: override.reasons || [`Manual override to ${override.verdict}`],
        override: true
      };
    }

    // If a note key was supplied by the agent, stamp it on the verdict for getFraudNote.
    if (noteKey && verdict.verdict === 'FRAUD') {
      verdict._selectedNoteKey = noteKey;
    }

    this.pendingConfirmation = null; // clear before async work to prevent double-fire

    this.setState('execution');
    const execResult = await this.doExecution(verdict, intake, extracted);

    if (execResult?.skipped) {
      this.stats.skipped++;
    } else {
      this.stats.processed++;
      if (verdict.verdict === 'FRAUD') this.stats.fraud++;
      else this.stats.notFraud++;
    }

    this.currentTicket = null;
    this.markTicketDone();
    this.setState('idle');
    await this.delay('between_tickets_ms');

    // Auto-continue to next ticket after supervised execution (batch only)
    this.continueIfBatch();
  }

  // --- Phase implementations ---

  // Parse the open ticket, with an escalated-ticket fallback. Normal tickets have
  // an HS_SA intake message → orderId. Escalated tickets do NOT: they carry a free
  // "Escalate from HeroCare" thread with no order id, so we recover orderId/userId
  // from the 1VU iframe URL (the authoritative source) and proceed.
  async resolveIntake(heroTabId, label) {
    const settleMs = this.settings.extraction_settle_ms ?? 1500;
    const response = await this.sendToHeroCareContext(heroTabId, 'herocare_parent', { type: 'PARSE_INTAKE' });
    const data = response?.data || {};

    if (!data.orderId) {
      // Escalated/unstructured ticket → pull ids from the 1VU iframe URL.
      const ctx = await this.readWithRetry(
        () => this.sendToHeroCareContext(heroTabId, 'onevu_iframe', { type: 'GET_ONEVU_CONTEXT' }),
        resp => (resp && (resp.orderId || resp.userId)) ? resp : null,
        '1VU context for escalated ticket', null, 4, 600
      );
      if (ctx?.orderId) {
        data.orderId = ctx.orderId;
        data._userIdFromIframe = ctx.userId || null;
        data._fromEscalation = true;
        this.addLog({ type: 'info', message: `Intake${label ? ' (' + label + ')' : ''}: no HS_SA in the thread — recovered order ${ctx.orderId} from the 1VU iframe (escalated ticket).` });
      }
    }

    if (data.escalated || data._fromEscalation) {
      const tags = (data.escalationTags || []).join(' // ') || 'n/a';
      this.addLog({ type: data.agentSuspectsFraud ? 'warning' : 'info', message: `Intake: ESCALATED ticket — escalating agent tags: ${tags}${data.agentSuspectsFraud ? ' [agent suspects fraud — informational, verdict stays data-driven]' : ''}${data.originalTicketId ? ` (orig ticket ${data.originalTicketId})` : ''}` });
    }

    return data.orderId ? data : null;
  }

  async doIntake() {
    // Manual investigation by OP order id/URL: run directly against the OP order
    // without requiring a HeroCare ticket. HeroCare data (risk, complaint) is
    // optional in this path.
    const orderId = this.investigateOrderId;
    this.investigateOrderId = null;
    if (orderId) {
      this.currentTicketId = null;
      this.addLog({ type: 'info', message: `Intake: direct OP order investigation — ${orderId}` });
      return {
        orderId,
        _directOrder: true,
        customerEmail: null,
        customerPhotos: [],
        amountPaid: null,
        amountVoucher: null,
        refundedItems: [],
        contactReason: null,
        subject: null
      };
    }

    const heroTab = await this.findTab('herocare');
    if (!heroTab) {
      this.intakeFailReason = 'No HeroCare tab open (expected hungerstation-mena.deliveryherocare.com). Open HeroCare in a tab.';
      return null;
    }

    // Manual investigation by case id/URL: navigate straight to the case so the
    // ticket opens on its own, then parse the active ticket (no queue needed).
    const caseId = this.investigateCaseId;
    this.investigateCaseId = null;
    if (caseId) {
      this.currentTicketId = null; // manual case is not a queue ticket
      const caseUrl = `https://hungerstation-mena.deliveryherocare.com/cases/${caseId}`;
      this.addLog({ type: 'info', message: `Intake: opening case ${caseId} directly → ${caseUrl}` });
      try {
        await chrome.tabs.update(heroTab.id, { url: caseUrl });
      } catch (e) {
        this.intakeFailReason = `Could not navigate the HeroCare tab to case ${caseId}: ${e.message}`;
        return null;
      }
      const ready = await this.waitForHeroCareReady(heroTab.id);
      if (!ready) {
        this.intakeFailReason = `Case ${caseId} page did not become ready (content script not injected / slow load). Reload the HeroCare tab and retry.`;
        return null;
      }
      // Let the ticket panel + 1VU iframe settle before parsing.
      await new Promise(r => setTimeout(r, this.settings.extraction_settle_ms ?? 1500));
      const data = await this.resolveIntake(heroTab.id, `manual case ${caseId}`);
      if (!data) {
        this.intakeFailReason = `Opened case ${caseId} but could not determine an Order ID (no HS_SA in the thread and the 1VU iframe gave no orderId — is this a valid case?).`;
        return null;
      }
      this.addLog({ type: 'info', message: `Intake OK (manual case ${caseId}): order ${data.orderId}${data._fromEscalation ? ' [escalated]' : ''}` });
      return data;
    }

    // Consume any specific ticket requested via the popup selector
    const targetId = this.targetTicketId;
    this.targetTicketId = null;

    // Decide WHICH ticket to open. For a manual one-shot we open the requested
    // id. For a batch run we pick the next queue ticket we have NOT already
    // handled this run — this is the fix for "keeps solving the same case":
    // in audit/supervised the ticket isn't closed, so it stays active and the
    // old code re-opened the same one forever.
    let pickTicketId = targetId;
    if (!pickTicketId) {
      const listResp = await this.sendToHeroCareContext(heroTab.id, 'herocare_parent', { type: 'LIST_TICKETS' });
      const tickets = listResp?.tickets || [];
      this.addLog({ type: 'info', message: `Intake: queue has ${tickets.length} ticket(s); ${this.doneThisRun.size} already handled this run.` });
      if (tickets.length === 0) {
        this.intakeEmptyQueue = true;
        this.intakeFailReason = 'No tickets in the queue right now — it may simply be empty.';
        return null;
      }
      const next = tickets.find(t => t.id && !this.doneThisRun.has(t.id));
      if (!next) {
        this.intakeEmptyQueue = true;
        this.intakeFailReason = `All ${tickets.length} queued ticket(s) have been handled this run — nothing left to do.`;
        return null;
      }
      pickTicketId = next.id;
    }

    // Open the chosen ticket and remember it so the batch loop can advance past it.
    const picked = await this.sendToHeroCareContext(heroTab.id, 'herocare_parent', { type: 'PICK_UP_TICKET', payload: { ticketId: pickTicketId } });
    if (!picked?.ok) {
      this.intakeFailReason = `Could not open ticket ${pickTicketId || '(next in queue)'} (row not found or not clickable).`;
      this.addLog({ type: 'warning', message: this.intakeFailReason });
      if (pickTicketId) this.doneThisRun.add(pickTicketId); // don't get stuck retrying it
      return null;
    }
    this.currentTicketId = pickTicketId || null;
    this.addLog({ type: 'info', message: `Intake: opened ticket ${pickTicketId || '(next in queue)'}` });
    await this.delay('between_pages_ms');

    const data = await this.resolveIntake(heroTab.id, null);
    if (!data) {
      this.intakeFailReason = `Could not determine an Order ID for ticket ${pickTicketId || '(open)'} — no "HS_SA-<id>-..." in the thread and the 1VU iframe gave no orderId.`;
      return null;
    }

    this.addLog({ type: 'info', message: `Intake OK: order ${data.orderId}${data._fromEscalation ? ' [escalated]' : ''}, email ${data.customerEmail || 'n/a'}, paid ${data.amountPaid ?? '?'} SAR, ${data.customerPhotos?.length || 0} photo(s)` });
    return data;
  }

  async doExtraction(intake) {
    const isDirectOrder = !!intake._directOrder;

    // The ticket panel + 1VU iframe render asynchronously after the ticket
    // opens. Give the page a moment to settle before reading, or the first
    // reads come back empty (risk/complaint/notes glitch out).
    // For a direct OP order investigation there is no HeroCare panel to wait for.
    if (!isDirectOrder) {
      const settleMs = this.settings.extraction_settle_ms ?? 1500;
      this.addLog({ type: 'info', message: `Extraction: waiting ${settleMs}ms for the ticket + 1VU panel to finish loading…`, orderId: intake.orderId });
      await new Promise(r => setTimeout(r, settleMs));
    }

    this.stopScraping = false;

    // Get data from HeroCare parent page + 1VU iframe (right panel).
    const heroTab = await this.findTab('herocare');
    let riskStatus = null, complaintType = null, complaintRaw = null, isPreExisting = false, oneVuCtx = null, customerName = null;

    if (!heroTab) {
      if (isDirectOrder) {
        this.addLog({ type: 'info', message: 'Extraction: direct order investigation — no HeroCare tab, will use OP data only.', orderId: intake.orderId });
      } else {
        this.addLog({ type: 'warning', message: 'Extraction: no HeroCare tab found — cannot read 1VU risk / complaint / pre-existing status.', orderId: intake.orderId });
      }
    } else {
      // 1VU risk status lives in the embedded iframe — retry a few times since
      // the frame may still be registering right after the ticket opens.
      riskStatus = await this.readWithRetry(
        () => this.sendToHeroCareContext(heroTab.id, 'onevu_iframe', { type: 'GET_RISK_STATUS' }),
        resp => resp?.data,
        '1VU risk status', intake.orderId
      );

      // The contact-reason (CCR h4) lives in the 1VU IFRAME, not the parent —
      // read it there. Retry on the RAW reason text (not the mapped type), so a
      // valid-but-unmapped reason still counts as "found" and is kept for the
      // log/fallback instead of looking empty. Falls back to subject/ccrCode below.
      const ccrResp = await this.readWithRetry(
        () => this.sendToHeroCareContext(heroTab.id, 'onevu_iframe', { type: 'GET_COMPLAINT_TYPE' }),
        resp => (resp && (resp.type || resp.rawCCR)) ? resp : null,
        '1VU contact reason (CCR)', intake.orderId
      );
      complaintType = ccrResp?.type || null;
      const rawCCR = ccrResp?.rawCCR || null;
      const ccrCode = ccrResp?.ccrCode || null;
      complaintRaw = rawCCR;
      if (rawCCR && !complaintType) {
        this.addLog({ type: 'info', message: `Extraction: CCR text "${rawCCR}"${ccrCode ? ` (code ${ccrCode})` : ''} did not map to a known complaint type — keeping raw reason; refund will use a safe default.`, orderId: intake.orderId });
      }

      const preExistingResp = await this.sendToHeroCareContext(heroTab.id, 'herocare_parent', { type: 'GET_PRE_EXISTING' });
      isPreExisting = preExistingResp?.isPreExisting || false;

      // The 1VU iframe URL carries the REAL OP order id + customer user id +
      // contact-reason code — the most reliable source. Read it from the iframe.
      oneVuCtx = await this.readWithRetry(
        () => this.sendToHeroCareContext(heroTab.id, 'onevu_iframe', { type: 'GET_ONEVU_CONTEXT' }),
        resp => (resp && (resp.orderId || resp.userId)) ? resp : null,
        '1VU context (orderId/userId from iframe URL)', intake.orderId
      );

      // Customer name — best-effort, for labeling accounts/devices in the log so
      // it's clear which ids belong to whom. Falls back to the email local-part.
      try {
        const custResp = await this.sendToHeroCareContext(heroTab.id, 'onevu_iframe', { type: 'GET_CUSTOMER_DATA' });
        customerName = custResp?.data?.name || null;
      } catch (_) {}
      if (!customerName && intake.customerEmail) customerName = intake.customerEmail.split('@')[0];

      this.addLog({ type: 'info', message: `Extraction (1VU/Hero): customer=${customerName || 'n/a'}, risk=${riskStatus?.isFraudulent ? 'flagged' : (riskStatus ? 'ok' : 'n/a')}, complaint=${complaintType || 'n/a'}, preExisting=${isPreExisting}, opOrderId=${oneVuCtx?.orderId || 'n/a'}, userId=${oneVuCtx?.userId || 'n/a'}`, orderId: intake.orderId });
    }

    if (this.checkStopScraping('after HeroCare reads')) {
      return this.buildExtractionResult({ intake, riskStatus, complaintType, complaintRaw, isPreExisting, customerName, oneVuCtx, aboutUser: null, compensationRows: [], orderItems: [], riderPhotos: [], blockedData: {}, connectedAccounts: null, mainUserId: oneVuCtx?.userId || null });
    }

    await this.delay('between_pages_ms');

    // Get data from Operation Portal — actively open/navigate the OP tab to THIS
    // order's page rather than scraping whatever order happens to be open.
    let aboutUser = null, compensationRows = [], orderItems = [], riderPhotos = [], blockedData = {};
    let connectedAccounts = null, mainUserId = oneVuCtx?.userId || null;

    // Prefer the OP order id from the 1VU iframe; fall back to the intake id.
    const opOrderId = oneVuCtx?.orderId || intake.orderId;

    let opTab = null;
    if (!opOrderId) {
      this.addLog({ type: 'warning', message: 'No Order ID (neither 1VU iframe nor intake) — cannot open the Operation Portal order page.', orderId: intake.orderId });
    } else {
      opTab = await this.ensureOpTab('order', opOrderId);
      if (!opTab) {
        this.addLog({ type: 'warning', message: `Could not load OP order page for ${intake.orderId} (no OP tab could be opened/navigated, or VPN/Cloudflare blocked it). OP stats + compensation history will be empty, so the rate cannot be computed. Confirm the German VPN is on.`, orderId: intake.orderId });
      }
    }

    if (opTab) {
      this.addLog({ type: 'info', message: `OP: order page ready — reading About User, items, photos & compensation history…`, orderId: intake.orderId });

      // Navigate to About User → extract stats + blocked status
      await this.sendToTab(opTab.id, { type: 'NAVIGATE_TAB', payload: { tab: 'aboutUser' } });
      await this.delay('between_actions_ms');

      const [userResp, blockedResp] = await Promise.all([
        this.sendToTab(opTab.id, { type: 'GET_ABOUT_USER' }),
        this.sendToTab(opTab.id, { type: 'GET_BLOCKED_STATUS' })
      ]);
      aboutUser = userResp?.data;
      blockedData = blockedResp?.data || {};
      // OP About User exposes the customer's name — use it when the 1VU iframe
      // didn't give one (e.g. manual case runs with no email to fall back on).
      if (!customerName && aboutUser?.name) customerName = aboutUser.name;
      if (blockedResp?.notFound) {
        this.addLog({ type: 'warning', message: `${this.ownerLabel(mainUserId, customerName)}: OP About User page returned 404 while reading blocked status — check #5 (Blocked Device/Account) may be unreliable for this read.`, orderId: intake.orderId });
      }

      // Deleted account with agent notes: if any note contains block/ban/delete-due-to-fraud
      // keywords (Arabic), treat the account as blocked for Check #5. Faster than an API call.
      if (!blockedData.blockedAccount && /deleted|محذوف/.test(blockedData.status || '')) {
        const notes = blockedData.agentNotes || [];
        if (notes.length > 0) {
          const combined = notes.join(' ');
          // Arabic/English indicators that the account was blocked/banned/deleted for abuse or fraud
          const blockIntentPattern = /(حساب\s+سيء|تم\s+المنع|تم\s+الحذف|تم\s+الحظر|محظور|موقوف|ممنوع|banned|blocked|suspend|محذوف\s+بسبب|اعتذار\s+بسبب\s+سجل|سجل\s+سيء)/i;
          if (blockIntentPattern.test(combined)) {
            blockedData.blockedAccount = true;
            blockedData.reason = 'Deleted account inferred as blocked from agent notes (keyword match)';
            this.addLog({ type: 'warning', message: blockedData.reason, orderId: intake.orderId });
          } else {
            this.addLog({ type: 'info', message: 'Account is deleted but agent notes do not indicate a block/ban.', orderId: intake.orderId });
          }
        }
      }

      if (this.checkStopScraping('after About User')) {
        return this.buildExtractionResult({ intake, riskStatus, complaintType, complaintRaw, isPreExisting, customerName, oneVuCtx, aboutUser, compensationRows, orderItems, riderPhotos, blockedData, connectedAccounts, mainUserId });
      }

      // Customer's OP user ID for device → linked-account traversal. Prefer the
      // 1VU iframe value (already captured); only scrape the /users/{id} link if
      // the iframe didn't provide it.
      if (!mainUserId) {
        const userLinkResp = await this.sendToTab(opTab.id, { type: 'GET_USER_LINK' });
        mainUserId = userLinkResp?.userId || null;
      }

      // Get order line items (for bulk drinks check #2)
      const itemsResp = await this.sendToTab(opTab.id, { type: 'GET_ORDER_ITEMS' });
      orderItems = itemsResp?.items || [];

      if (this.checkStopScraping('after order items')) {
        return this.buildExtractionResult({ intake, riskStatus, complaintType, complaintRaw, isPreExisting, customerName, oneVuCtx, aboutUser, compensationRows, orderItems, riderPhotos, blockedData, connectedAccounts, mainUserId });
      }

      // Navigate to Track History → get rider photos (for photo mismatch check #4)
      await this.sendToTab(opTab.id, { type: 'NAVIGATE_TAB', payload: { tab: 'trackHistory' } });
      await this.delay('between_actions_ms');
      const photosResp = await this.sendToTab(opTab.id, { type: 'GET_RIDER_PHOTOS' });
      riderPhotos = photosResp?.photos || [];

      if (this.checkStopScraping('after rider photos')) {
        return this.buildExtractionResult({ intake, riskStatus, complaintType, complaintRaw, isPreExisting, customerName, oneVuCtx, aboutUser, compensationRows, orderItems, riderPhotos, blockedData, connectedAccounts, mainUserId });
      }

      // Compensation history (full, for the rate). Navigate DIRECTLY to the
      // user-filtered table — the same reliable path the linked-account scan
      // uses. The old "click the Customer Compensation History link" dance
      // sometimes scraped before the table mounted → 0 rows despite a non-zero
      // lifetime count (confirmed live). Falls back to the click path only if we
      // somehow have no user id.
      this.addLog({ type: 'info', message: `OP: opening compensation history…`, orderId: intake.orderId });
      if (mainUserId) {
        // Navigate the (foreground) OP tab directly to the user-filtered table —
        // single-tab/sequential, which loads reliably over the slow VPN. The
        // rows-loaded readiness gate + per_page=100 ensure a complete scrape.
        const compTab = await this.ensureOpTab('compensation', mainUserId);
        if (compTab) {
          await this.delay('between_actions_ms');
          const compResp = await this.sendToTab(compTab.id, { type: 'SCRAPE_COMPENSATION' });
          compensationRows = compResp?.rows || [];
        }
      } else {
        await this.sendToTab(opTab.id, { type: 'NAVIGATE_TAB', payload: { tab: 'compensation' } });
        await this.delay('between_actions_ms');
        await this.sendToTab(opTab.id, { type: 'CLICK_COMP_HISTORY' });
        await this.waitForOpReady(opTab.id, { pageType: 'compensation_history' });
        await this.delay('between_pages_ms');
        const compResp = await this.sendToTab(opTab.id, { type: 'SCRAPE_COMPENSATION' });
        compensationRows = compResp?.rows || [];
      }
      this.addLog({ type: 'info', message: `OP: scraped ${compensationRows.length} compensation row(s).`, orderId: intake.orderId });

      if (this.checkStopScraping('after compensation history')) {
        return this.buildExtractionResult({ intake, riskStatus, complaintType, complaintRaw, isPreExisting, customerName, oneVuCtx, aboutUser, compensationRows, orderItems, riderPhotos, blockedData, connectedAccounts, mainUserId });
      }

      // Connected-accounts traversal (checklist #10) — runs LAST because it
      // navigates the OP tab away to /users, /devices and per-account
      // /compensations pages. Can be disabled via settings; skipped if scraping stopped.
      if (this.settings.check_connected_accounts !== false) {
        connectedAccounts = await this.doConnectedAccounts(mainUserId, intake.orderId, customerName);
      } else {
        this.addLog({ type: 'info', message: 'Connected accounts scan disabled in settings — Check #10 marked for review.', orderId: intake.orderId });
      }
    }

    // Complaint type: prefer the 1VU CCR, but fall back to the intake subject/
    // contact-reason text (the queue label carries "… Wrong / Missing item").
    if (!complaintType && (intake.contactReason || intake.subject)) {
      const heroTab2 = heroTab;
      if (heroTab2) {
        const fallbackResp = await this.sendToHeroCareContext(heroTab2.id, 'herocare_parent', {
          type: 'GET_COMPLAINT_TYPE', payload: { text: intake.contactReason || intake.subject }
        });
        complaintType = fallbackResp?.type || complaintType;
      }
    }

    // Count comps inside the checklist window (by Operationday) for visibility —
    // the checklist evaluates on this window; the full history feeds the rate.
    const windowDays = 30;
    const cutoffMs = Date.now() - windowDays * 86400000;
    const recentComps = (compensationRows || []).filter(r => {
      if (!r || !r.date) return true;
      const d = new Date(String(r.date).replace(' ', 'T'));
      return isNaN(d.getTime()) ? true : d.getTime() >= cutoffMs;
    }).length;

    this.addLog({
      type: 'info',
      orderId: intake.orderId,
      message: `Extraction done for ${this.ownerLabel(mainUserId, customerName)}: totalOrders=${aboutUser?.totalOrders ?? '?'}, failedOrders=${aboutUser?.failedOrders ?? '?'}, compRows=${compensationRows.length} (last ${windowDays}d ${recentComps}${aboutUser?.compensationsCount != null ? `, lifetime ${aboutUser.compensationsCount}` : ''}), orderItems=${orderItems.length}, riderPhotos=${riderPhotos.length}, complaint=${complaintType || '?'}, status=${blockedData?.status || '?'}${blockedData?.blockedAccount ? ' (BLOCKED)' : ''}, risk=${riskStatus?.isFraudulent ? 'flagged' : 'ok'}`
    });

    return this.buildExtractionResult({ intake, customerName, mainUserId, riskStatus, complaintType, complaintRaw, isPreExisting, aboutUser, blockedData, orderItems, riderPhotos, compensationRows, connectedAccounts });
  }

  buildExtractionResult({ intake, customerName, mainUserId, riskStatus, complaintType, complaintRaw, isPreExisting, aboutUser, blockedData, orderItems, riderPhotos, compensationRows, connectedAccounts }) {
    return {
      ...intake,
      customerName: customerName || null,
      mainUserId: mainUserId || null,
      riskStatus: riskStatus || null,
      complaintType: complaintType || null,
      complaintRaw: complaintRaw || null,
      isPreExisting: !!isPreExisting,
      totalOrders: aboutUser?.totalOrders ?? null,
      failedOrders: aboutUser?.failedOrders ?? null,
      userCreatedAt: aboutUser?.userCreatedAt ?? null,
      blockedDevice: blockedData?.blockedDevice || false,
      blockedAccount: blockedData?.blockedAccount || false,
      orderItems: orderItems || [],
      riderPhotos: riderPhotos || [],
      compensationRows: compensationRows || [],
      connectedAccounts: connectedAccounts || null
    };
  }

  // Checklist #10 data gatherer. Discovers the cluster of accounts that share
  // device(s) with the customer, then evaluates each linked account on its OWN
  // order stats + compensation history (full checklist, 30-day window).
  //
  // Loop-safe by construction: BFS over the user<->device bipartite graph with
  // visitedUsers + visitedDevices sets, so no account or device is ever visited
  // twice (this is the cycle you were worried about — it can't happen here).
    // Bounded by connected_max_depth / connected_max_accounts / connected_max_devices.
    // Default depth is 2, which captures first-degree linked accounts without
    // over-scraping distant network nodes.
  // Returns { evaluated, accounts:[{userId, viaDeviceId, totalOrders, failedOrders,
  //   ratePercent, anyHit, hits, rowCount}], deviceCount, depth }.
  async doConnectedAccounts(mainUserId, orderId, customerName) {
    const owner = this.ownerLabel(mainUserId, customerName);
    if (!mainUserId) {
      this.addLog({ type: 'warning', message: `Connected accounts: no customer user ID found for ${owner} — cannot traverse devices. Check #10 → needs review.`, orderId });
      return { evaluated: false, reason: 'no main user id' };
    }

    const maxDevices = this.settings.connected_max_devices ?? 5;
    const maxAccounts = this.settings.connected_max_accounts ?? 6;
    const maxDepth = this.settings.connected_max_depth ?? 2;
    const windowDays = 30;
    const runChecklist = (typeof require !== 'undefined') ? require('../engine/checklist').runChecklist : self.runChecklist;
    const calcRate = (typeof require !== 'undefined') ? require('../engine/rate-calculator').calculateAdjustedRate : self.calculateAdjustedRate;

    // --- Phase 1: discover the cluster (loop-safe BFS) ---
    const visitedUsers = new Set([String(mainUserId)]);   // never revisit a user
    const visitedDevices = new Set();                      // never revisit a device
    const cluster = [];                                    // [{ userId, viaDeviceId }]
    let frontier = [String(mainUserId)];
    let depth = 0;

    this.addLog({ type: 'info', message: `Connected accounts for ${owner}: discovering device cluster (depth≤${maxDepth}, ≤${maxAccounts} accounts)…`, orderId });

    while (frontier.length && depth < maxDepth && cluster.length < maxAccounts && visitedDevices.size < maxDevices) {
      const nextFrontier = [];
      for (const userId of frontier) {
        if (cluster.length >= maxAccounts || visitedDevices.size >= maxDevices) break;
        if (this.checkStopScraping('before opening linked user')) {
          frontier = [];
          break;
        }
        const userTab = await this.ensureOpTab('user', userId);
        if (!userTab) { this.addLog({ type: 'warning', message: `Connected accounts (${owner}): /users/${userId} did not load — skipping.`, orderId }); continue; }
        await this.delay('between_actions_ms');
        const devResp = await this.sendToTab(userTab.id, { type: 'GET_DEVICES' });
        const devices = (devResp?.devices || []).filter(d => d.deviceId);

        for (const device of devices) {
          const devId = String(device.deviceId);
          if (visitedDevices.has(devId)) continue;          // <-- cycle guard (device)
          if (visitedDevices.size >= maxDevices) break;
          if (this.checkStopScraping('before opening linked device')) {
            frontier = [];
            break;
          }
          visitedDevices.add(devId);
          const dTab = await this.ensureOpTab('device', devId);
          if (!dTab) { this.addLog({ type: 'warning', message: `Connected accounts (${owner}): device ${devId} page did not load — skipping.`, orderId }); continue; }
          await this.delay('between_actions_ms');
          const accResp = await this.sendToTab(dTab.id, { type: 'GET_CONNECTED_ACCOUNTS' });
          for (const acc of accResp?.accounts || []) {
            const uid = acc.userId && String(acc.userId);
            if (!uid || visitedUsers.has(uid)) continue;     // <-- cycle guard (user)
            if (this.checkStopScraping('before collecting more linked accounts')) {
              frontier = [];
              break;
            }
            visitedUsers.add(uid);
            cluster.push({ userId: uid, viaDeviceId: devId });
            nextFrontier.push(uid);
            if (cluster.length >= maxAccounts) break;
          }
          if (cluster.length >= maxAccounts || this.stopScraping) break;
        }
        if (this.stopScraping) break;
      }
      if (this.stopScraping) break;
      frontier = nextFrontier;
      depth++;
    }

    if (this.stopScraping) {
      this.addLog({ type: 'warning', message: `Connected accounts for ${owner}: scrape stopped — evaluating ${cluster.length} account(s) already collected.`, orderId });
    }

    this.addLog({ type: 'info', message: `Connected accounts for ${owner}: cluster = ${cluster.length} linked account(s) across ${visitedDevices.size} device(s) (depth ${depth}).`, orderId });
    if (cluster.length === 0) {
      return { evaluated: true, accounts: [], deviceCount: visitedDevices.size, depth };
    }

    // --- Phase 2: evaluate each linked account on its own stats + comp history ---
    // Sequential on the single (foreground) OP tab — reliable over the slow VPN.
    const accounts = [];
    for (const { userId, viaDeviceId } of cluster.slice(0, maxAccounts)) {
      // Order stats (3-month window from the user page) so #6/#9 aren't "unknown".
      let stats = {};
      const sTab = await this.ensureOpTab('user', userId);
      if (sTab) {
        await this.delay('between_actions_ms');
        const sResp = await this.sendToTab(sTab.id, { type: 'GET_USER_STATS' });
        stats = sResp?.data || {};
      }
      // Compensation history.
      let rows = [];
      const cTab = await this.ensureOpTab('compensation', userId);
      if (cTab) {
        await this.delay('between_actions_ms');
        const compResp = await this.sendToTab(cTab.id, { type: 'SCRAPE_COMPENSATION' });
        rows = compResp?.rows || [];
      }

      const rate = calcRate(rows, stats.totalOrders, stats.failedOrders);
      // No connectedAccounts passed → this account's own #10 is a no-op (no recursion).
      const cl = runChecklist(
        { compensationRows: rows, userCreatedAt: stats.userCreatedAt, adjustedRate: rate.rate },
        { ...(this.settings.thresholds || {}), checklist_window_days: windowDays }
      );
      accounts.push({
        userId, viaDeviceId,
        totalOrders: stats.totalOrders ?? null,
        failedOrders: stats.failedOrders ?? null,
        statsWindow: stats.window || null,
        ratePercent: rate.ratePercent ?? null,
        rowCount: rows.length,
        windowedRowCount: cl.windowedRowCount,
        anyHit: cl.anyHit,
        hits: cl.hits,
        evaluated: !!(sTab || cTab)
      });
      this.addLog({ type: cl.anyHit ? 'warning' : 'info', message: `Connected accounts (${owner}): linked account user ${userId} via device ${viaDeviceId} → orders ${stats.totalOrders ?? '?'}/${stats.failedOrders ?? '?'} (3m), ${rows.length} comp (${cl.windowedRowCount} in ${windowDays}d), ${cl.anyHit ? 'FRAUD: ' + cl.hits.map(h => h.checkName).join(', ') : 'clean'}.`, orderId });
    }

    const flagged = accounts.filter(a => a.anyHit).length;
    this.addLog({ type: flagged ? 'warning' : 'info', message: `Connected accounts for ${owner}: evaluated ${accounts.length} linked account(s), ${flagged} flagged.`, orderId });
    return { evaluated: true, accounts, deviceCount: visitedDevices.size, depth };
  }

  doCalculation(extracted) {
    // Import at usage (in extension context, these would be loaded differently)
    const { calculateAdjustedRate } = typeof require !== 'undefined'
      ? require('../engine/rate-calculator')
      : { calculateAdjustedRate: self.calculateAdjustedRate };

    return calculateAdjustedRate(
      extracted.compensationRows,
      extracted.totalOrders,
      extracted.failedOrders
    );
  }

  // Verbose checklist breakdown: log the header (X hit / R review / N total over
  // the comp window) then EVERY check with its pass/fail/review state and reason —
  // so the agent sees the full evaluation, not just the items that fired.
  logChecklist(cl, orderId) {
    if (!cl || !Array.isArray(cl.results)) return;
    const total = cl.results.length;
    const hit = cl.hitCount || 0;
    const review = cl.results.filter(r => r.needsReview && !r.hit).length;
    this.addLog({
      type: hit > 0 ? 'warning' : 'info',
      orderId,
      message: `Checklist: ${hit}/${total} hit, ${review}/${total} need review, ${total - hit - review}/${total} clean ` +
               `(evaluated ${cl.windowedRowCount}/${cl.totalRowCount} comps in last ${cl.windowDays}d).`
    });
    cl.results.forEach((r, i) => {
      const state = r.hit ? 'HIT ✕' : (r.needsReview ? 'REVIEW ?' : 'pass ✓');
      this.addLog({
        type: r.hit ? 'warning' : 'info',
        orderId,
        message: `  #${i + 1}/${total} ${r.checkName || 'Check'} — ${state}: ${r.reason || ''}`
      });
    });
  }

  async doChecklist(extracted, rateResult) {
    const { runChecklist } = typeof require !== 'undefined'
      ? require('../engine/checklist')
      : { runChecklist: self.runChecklist };

    // Photo comparison is disabled from the active fraud checklist flow.
    // The Gemini service and comparePhotos() remain in extension/services/gemini.js
    // for future use (e.g., non-fraud validation or a separate review tool).
    // See git history / archived docs for the original wiring.
    let photoComparison = null;

    /* DISABLED — photo review is not a fraud checklist item per agent feedback.
    const thresholdPct = this.settings.thresholds?.adjusted_rate_fraud_percent || 39;
    const rateAlreadyFraud = rateResult.rate >= thresholdPct / 100;
    const canComparePhotos = (extracted.customerPhotos?.length > 0) &&
      (extracted.riderPhotos?.length > 0 || extracted.complaintType === 'quality_issue');

    if (!rateAlreadyFraud && canComparePhotos) {
      photoComparison = await this.doPhotoComparison(extracted);
      if (photoComparison?.status === 'NEEDS_HUMAN_REVIEW') {
        this.addLog({ type: 'warning', message: `Photo comparison needs human review — pausing.`, orderId: extracted.orderId });
        this.pause();
        this.sendPhotoReviewNotification(extracted);
      }
    } else if (rateAlreadyFraud) {
      this.addLog({ type: 'info', message: 'Photo comparison skipped — other fraud signals already present.', orderId: extracted.orderId });
    } else if (!canComparePhotos) {
      this.addLog({ type: 'info', message: 'Photo comparison skipped — required photo(s) missing.', orderId: extracted.orderId });
    }
    */

    // Connected-accounts (check #10) is OP-traversal heavy; when not populated
    // it degrades to "needs review" in the engine rather than a false pass.
    return runChecklist({
      compensationRows: extracted.compensationRows,
      orderDetails: extracted.orderItems || [],
      photoComparison,
      blockedDevice: extracted.blockedDevice || false,
      blockedAccount: extracted.blockedAccount || false,
      userCreatedAt: extracted.userCreatedAt,
      adjustedRate: rateResult.rate,
      connectedAccounts: extracted.connectedAccounts || null
    }, {
      ...(this.settings.thresholds || {}),
      checklist_window_days: 30
    });
  }

  /* DISABLED — photo comparison removed from active fraud checklist flow.
  async doPhotoComparison(extracted) {
    if (!this.settings.gemini_api_key) {
      return { status: 'NEEDS_HUMAN_REVIEW', reason: 'No Gemini API key' };
    }

    const comparePhotos = (typeof require !== 'undefined')
      ? require('../services/gemini').comparePhotos
      : self.comparePhotos;

    if (typeof comparePhotos !== 'function') {
      this.addLog({ type: 'warning', message: 'Photo comparison skipped — Gemini service (comparePhotos) is not loaded. Check #4 flagged for human review.', orderId: extracted.orderId });
      return { status: 'NEEDS_HUMAN_REVIEW', reason: 'Gemini service not available' };
    }

    const rules = this.settings.photo_comparison_rules || {};
    const rule = rules[extracted.complaintType] || rules.default || { send_rider: true, send_customer: true, prompt_focus: 'contradiction' };

    if (!rule.send_customer) {
      return { status: 'NEEDS_HUMAN_REVIEW', reason: `Customer photos disabled for ${extracted.complaintType}` };
    }

    this.addLog({ type: 'info', message: `Photo comparison: complaint=${extracted.complaintType || 'unknown'}, focus=${rule.prompt_focus}, rider=${rule.send_rider}, customer=${rule.send_customer}`, orderId: extracted.orderId });

    return await comparePhotos({
      riderPhotos: rule.send_rider ? extracted.riderPhotos : [],
      customerPhotos: extracted.customerPhotos,
      complaintType: extracted.complaintType || 'unknown',
      complaintRaw: extracted.complaintRaw || '',
      focus: rule.prompt_focus || 'contradiction',
      apiKey: this.settings.gemini_api_key,
      model: this.settings.gemini_model || 'gemini-2.0-flash'
    });
  }

  pause() {
    this.isPaused = true;
  }

  sendPhotoReviewNotification(extracted) {
    // Send notification via chrome if available
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime?.id) {
        chrome.runtime.sendMessage({
          type: 'PHOTO_REVIEW_NEEDED',
          payload: {
            orderId: extracted.orderId,
            complaintType: extracted.complaintType,
            reason: 'Gemini photo comparison returned NEEDS_HUMAN_REVIEW'
          }
        }).catch(() => {});
      }
    } catch (_) {}
  }
  */

  doVerdict(rateResult, checklistResult) {
    const { determineVerdict } = typeof require !== 'undefined'
      ? require('../engine/verdict')
      : { determineVerdict: self.determineVerdict };

    return determineVerdict(rateResult, checklistResult, this.settings.thresholds || {});
  }

  async doExecution(verdict, intake, extracted) {
    const { getFraudResponse, getFraudNote } = typeof require !== 'undefined'
      ? require('../engine/verdict')
      : { getFraudResponse: self.getFraudResponse, getFraudNote: self.getFraudNote };

    if (verdict.verdict === 'FRAUD') {
      // Allow agent-selected note key to override the auto-detected one.
      let noteVerdict = verdict;
      if (verdict._selectedNoteKey) {
        noteVerdict = {
          ...verdict,
          source: 'checklist',
          checklistResult: {
            ...(verdict.checklistResult || { hits: [] }),
            hits: [{ checkNumber: 0, checkName: verdict._selectedNoteKey, reason: 'Agent-selected note reason' }]
          }
        };
      }
      await this.executeFraud(intake, noteVerdict, getFraudResponse, getFraudNote);
      return { skipped: false };
    }
    return await this.executeNotFraud(intake, extracted, verdict);
  }

  // Fraud close sequence (in order):
  //   1) send the apology in HeroCare chat (random canned response from settings)
  //   2) add a comment on the Operation Portal order
  //   3) add a comment on the 1VU order
  //   4) wrap up / close the ticket (Wrap as: إغلاق + السماح بالرد → Submit)
  async executeFraud(intake, verdict, getFraudResponse, getFraudNote) {
    const isPreExisting = intake.isPreExisting || false;
    const response = getFraudResponse(isPreExisting, this.settings);
    const note = getFraudNote(verdict, this.settings);
    const orderId = intake.orderId;

    const heroTab = await this.findTab('herocare');
    const opTab = await this.findTab('operation');

    // 1) Apology response in the HeroCare chat.
    if (heroTab) {
      const sent = await this.sendToHeroCareContext(heroTab.id, 'herocare_parent', { type: 'SEND_RESPONSE', payload: { text: response } });
      this.addLog({ type: sent?.ok ? 'info' : 'warning', message: `FRAUD close 1/4: chat response ${sent?.ok ? 'sent' : 'may have FAILED'} (${isPreExisting ? 'pre-existing/R3' : 'new/R1'}).`, orderId });
      await this.delay('between_actions_ms');
    } else {
      this.addLog({ type: 'warning', message: 'FRAUD close: no HeroCare tab — cannot send the chat response or wrap up.', orderId });
    }

    // 2) Comment on the Operation Portal order.
    if (opTab) {
      if (intake.orderId) {
        // Ensure we are back on the order page (not stuck on the comp history tab) before writing the note.
        await this.ensureOpTab('order', intake.orderId);
      }
      const r = await this.sendToTab(opTab.id, { type: 'WRITE_NOTE', payload: { text: note } });
      this.addLog({ type: r?.ok ? 'info' : 'warning', message: `FRAUD close 2/4: OP comment ${r?.ok ? 'added' : 'may have FAILED'}.`, orderId });
      await this.delay('between_actions_ms');
    } else {
      this.addLog({ type: 'warning', message: 'FRAUD close: no OP tab — skipped the Operation Portal comment.', orderId });
    }

    // 3) Comment on the 1VU order.
    if (heroTab) {
      const r = await this.sendToHeroCareContext(heroTab.id, 'onevu_iframe', { type: 'WRITE_NOTE', payload: { text: note } });
      this.addLog({ type: r?.ok ? 'info' : 'warning', message: `FRAUD close 3/4: 1VU comment ${r?.ok ? 'added' : 'may have FAILED'}.`, orderId });
      await this.delay('between_actions_ms');

      // 4) Wrap up / close the ticket.
      const w = await this.sendToHeroCareContext(heroTab.id, 'onevu_iframe', { type: 'WRAP_UP_TICKET' });
      this.addLog({ type: w?.ok ? 'info' : 'warning', message: `FRAUD close 4/4: wrap-up ${w?.ok ? 'submitted (إغلاق)' : `incomplete — ${w?.reason || 'manual wrap-up needed'}`}.`, orderId });
    }
  }

  async executeNotFraud(intake, extracted, verdict) {
    // NOT_FRAUD cases are never auto-executed. They always surface a persistent
    // alert so a human agent reviews and processes the refund manually.
    const reasonParts = [
      verdict?.reasons?.length ? `reason: ${verdict.reasons.join('; ')}` : null,
      extracted?.complaintType ? `complaint: ${extracted.complaintType}` : null
    ].filter(Boolean);
    const reason = reasonParts.length ? reasonParts.join(' | ') : 'manual review required';
    this.addLog({ type: 'warning', message: `NOT_FRAUD alert raised — ${reason}`, orderId: intake.orderId });
    this.broadcast({ type: 'NOT_FRAUD_ALERT', payload: { orderId: intake.orderId, reason, extracted, verdict } });
    return { skipped: true, reason: 'NOT_FRAUD — awaiting manual refund by agent' };
  }

  // --- Helpers ---

  // Retry a content-script read until it yields a usable value. The 1VU iframe
  // and HeroCare panel populate asynchronously, so a single read right after the
  // ticket opens often returns null. extract(resp) pulls the value we care about.
  async readWithRetry(send, extract, label, orderId, attempts = 4, gapMs = 600) {
    for (let i = 1; i <= attempts; i++) {
      let resp = null;
      try { resp = await send(); } catch (_) {}
      const value = extract(resp);
      if (value !== undefined && value !== null && value !== '') {
        if (i > 1) this.addLog({ type: 'info', message: `Extraction: ${label} resolved on attempt ${i}/${attempts}.`, orderId });
        return value;
      }
      if (i < attempts) await new Promise(r => setTimeout(r, gapMs));
    }
    this.addLog({ type: 'warning', message: `Extraction: ${label} still empty after ${attempts} attempts — the panel may not have loaded, or the selector is stale.`, orderId });
    return null;
  }

  async findTab(system) {
    const patterns = {
      herocare: ['https://hungerstation-mena.deliveryherocare.com/*'],
      operation: ['https://*.hungerstation.com/operation/*']
    };

    const urls = patterns[system];
    if (!urls) return null;

    const tabs = await chrome.tabs.query({ url: urls });
    if (tabs.length === 0) return null;
    // Prefer an active (foreground) tab. Chrome throttles inactive/background
    // tabs, so a leftover background OP tab can fail to finish loading the SPA.
    return tabs.find(t => t.active && !t.discarded) || tabs.find(t => !t.discarded) || tabs[0];
  }

  // --- Operation Portal URL construction & navigation ---

  // Human-readable label for the ticket owner (the customer under investigation),
  // used throughout the decision log so every account/device id is attributable —
  // e.g. "Ahmed Ali (user 12345)". Falls back to "customer" when no name is known.
  ownerLabel(userId, name) {
    const who = name && String(name).trim() ? String(name).trim() : 'customer';
    return userId ? `${who} (user ${userId})` : who;
  }

  // Base host for OP. Configurable so we don't bake the domain into logic.
  opBaseUrl() {
    return (this.settings.op_base_url || 'https://hungerstation.com/operation/en').replace(/\/+$/, '');
  }

  buildOpUrl(kind, id) {
    const base = this.opBaseUrl();
    switch (kind) {
      case 'order':        return `${base}/orders/${id}`;
      // per_page=100 cuts the history into far fewer pages (≈155 rows → 2 pages
      // instead of 8) so the full-history scrape is fast and complete.
      case 'compensation': return `${base}/compensations?by_user=${id}&per_page=100`;
      case 'user':         return `${base}/users/${id}`;
      case 'device':       return `${base}/devices/${id}`;
      default:             return base;
    }
  }

  // Returns true once the HeroCare parent frame (0) answers a ping — i.e. the
  // case page has loaded and the content script is live. Used after navigating
  // straight to a case URL for manual investigation.
  async waitForHeroCareReady(tabId, timeout = 15000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      try {
        const resp = await this.sendToFrame(tabId, 0, { type: 'KEEPALIVE_PING' });
        if (resp?.alive) return true;
      } catch (_) { /* not injected yet */ }
      await new Promise(r => setTimeout(r, 400));
    }
    return false;
  }

  // Returns true once op.js reports the page has REAL content for this page type
  // (not OP's 404 "Page Not found" shell, and looking at the URL we navigated to).
  // On a genuine 404 it reloads the tab once and keeps polling — these are
  // usually a backend race where the id resolves a beat later. Polls so we never
  // scrape a half-loaded or 404 page (this is the check #5 race you hit).
  async waitForOpReady(tabId, { timeout = null, pageType = null, expectUrlPart = null, allowReload = true } = {}) {
    if (timeout == null) timeout = this.settings.op_ready_timeout_ms ?? 25000;
    const start = Date.now();
    let lastReloadTime = Date.now();
    while (Date.now() - start < timeout) {
      await this.checkPause();
      let resp = null;
      try { resp = await chrome.tabs.sendMessage(tabId, { type: 'GET_READINESS' }); } catch (_) { /* not injected yet */ }
      if (resp && resp.alive !== false) {
        const urlOk = !expectUrlPart || (resp.url && resp.url.includes(expectUrlPart));
        if (urlOk) {
          if (resp.notFound) {
            if (allowReload) {
              this.addLog({ type: 'warning', message: `OP returned 404/not found — triggering refresh/reload to retry: ${resp.url || ''}` });
              try { await chrome.tabs.reload(tabId); } catch (_) {}
              await new Promise(r => setTimeout(r, 1500));
              continue;
            }
            return false;
          }
          if (resp.contentReady) return true;
        }
      } else {
        if (Date.now() - lastReloadTime > 7000) {
          lastReloadTime = Date.now();
          this.addLog({ type: 'warning', message: `OP page loading unresponsive — triggering proactive refresh/reload to bypass timeout` });
          try { await chrome.tabs.reload(tabId); } catch (_) {}
          await new Promise(r => setTimeout(r, 1500));
          continue;
        }
      }
      await new Promise(r => setTimeout(r, 350));
    }
    return false;
  }

  // Open (or reuse) an OP tab and navigate it to the exact target URL for this
  // order. This is the core fix: previously the orchestrator only looked for an
  // already-open OP tab and never constructed the order URL, so OP-sourced
  // fields (totalOrders, failedOrders, orderItems, riderPhotos) came back empty.
  async ensureOpTab(kind, id, { reuse = true } = {}) {
    if (!id) {
      this.addLog({ type: 'warning', message: `ensureOpTab(${kind}) called with no id — cannot build OP URL.` });
      return null;
    }
    const targetUrl = this.buildOpUrl(kind, id);
    let tab = await this.findTab('operation');

    try {
      if (tab && reuse) {
        // Only navigate if the tab isn't already on this exact target.
        const already = (tab.url || '').includes(kind === 'order' ? `/orders/${id}` :
                         kind === 'user' ? `/users/${id}` :
                         kind === 'device' ? `/devices/${id}` :
                         `by_user=${id}`);
        if (!already) {
          await chrome.tabs.update(tab.id, { url: targetUrl });
        }
      } else {
        tab = await chrome.tabs.create({ url: targetUrl, active: false });
      }
    } catch (e) {
      this.addLog({ type: 'warning', message: `Failed to open OP ${kind} tab (${targetUrl}): ${e.message}` });
      return null;
    }

    this.addLog({ type: 'info', message: `OP: navigating to ${kind} → ${targetUrl}` });
    const pageTypeMap = { order: 'order', user: 'user', device: 'device', compensation: 'compensation_history' };
    const urlPartMap = { order: `/orders/${id}`, user: `/users/${id}`, device: `/devices/${id}`, compensation: `by_user=${id}` };
    const ready = await this.waitForOpReady(tab.id, { pageType: pageTypeMap[kind] || null, expectUrlPart: urlPartMap[kind] || null });
    if (!ready) {
      this.addLog({ type: 'warning', message: `OP ${kind} page did not become ready in time (VPN off / Cloudflare block / persistent 404 / slow load?). URL: ${targetUrl}` });
    }
    // Re-read the tab so callers get the post-navigation URL.
    try { tab = await chrome.tabs.get(tab.id); } catch (_) {}
    return ready ? tab : null;
  }

  async sendToTab(tabId, message) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (error) {
      console.warn(`[Orchestrator] Failed to send to tab ${tabId}:`, error.message);
      return null;
    }
  }

  async sendToFrame(tabId, frameId, message) {
    if (frameId == null) return this.sendToTab(tabId, message);
    try {
      return await chrome.tabs.sendMessage(tabId, message, { frameId });
    } catch (error) {
      console.warn(`[Orchestrator] Failed to send to frame ${frameId} on tab ${tabId}:`, error.message);
      return null;
    }
  }

  async sendToHeroCareContext(tabId, context, message) {
    let frameId = typeof self !== 'undefined' ? self.getFrameId?.(tabId, context) : null;
    // The parent page is always the top frame (0). If the registry hasn't been
    // populated yet, default to 0 rather than broadcasting tab-wide — otherwise
    // the 1VU iframe (which runs onevu.js) can answer first.
    if (frameId == null && context === 'herocare_parent') frameId = 0;
    return this.sendToFrame(tabId, frameId, message);
  }

  async checkPause() {
    if (this.isPaused) {
      this.addLog({ type: 'info', message: 'Orchestrator paused. Suspending active workflow...', orderId: this.currentTicket?.orderId });
      while (this.isPaused) {
        await new Promise(r => setTimeout(r, 400));
      }
      this.addLog({ type: 'info', message: 'Orchestrator resumed. Resuming active workflow...', orderId: this.currentTicket?.orderId });
    }
  }

  checkStopScraping(label) {
    if (this.stopScraping) {
      this.addLog({ type: 'warning', message: `Stop scraping requested${label ? ' at ' + label : ''}. Returning extracted data so far.`, orderId: this.currentTicket?.orderId });
      return true;
    }
    return false;
  }

  async delay(type) {
    await this.checkPause();
    const config = this.settings.delays?.[type];
    if (!config) return;
    const min = Math.max(0, config.min || 0);
    const max = Math.max(min, config.max || min);
    const ms = Math.floor(Math.random() * (max - min + 1)) + min;
    const chunk = 200;
    const start = Date.now();
    while (Date.now() - start < ms) {
      await this.checkPause();
      await new Promise(r => setTimeout(r, Math.min(chunk, ms - (Date.now() - start))));
    }
    await this.checkPause();
  }

  setState(state) {
    this.state = state;
    this.broadcast({ type: 'STATE_UPDATE', payload: { state, isPaused: this.isPaused, ticket: this.currentTicket } });
    this.persistState();
  }

  persistState() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage?.local) {
        chrome.storage.local.set({
          orchestratorState: {
            isPaused: this.isPaused,
            stats: this.stats
          }
        });
      }
    } catch (_) {}
  }

  handleError(message, detail = null) {
    this.stats.errors++;
    const orderId = this.currentTicket?.orderId;
    // Don't let a crashing ticket be re-opened forever by the batch loop.
    this.markTicketDone();
    this.addLog({
      type: 'error',
      message,
      phase: detail?.phase || this.state,
      orderId: orderId || detail?.orderId || null,
      detail: detail || null
    });
    this.currentTicket = null;
    this.setState('idle');
  }

  addLog(entry) {
    this.log.unshift({ ...entry, timestamp: entry.timestamp || new Date().toISOString() });
    if (this.log.length > 500) this.log.pop();
    this.broadcast({ type: 'DECISION_LOG', payload: entry });
  }

  broadcast(message) {
    chrome.runtime.sendMessage(message).catch(() => {});
  }

  pause() {
    this.isPaused = true;
    this.setState(this.state);
  }

  resume() {
    this.isPaused = false;
    this.setState(this.state);
  }

  restoreState(persisted) {
    if (!persisted) return;
    if (persisted.isPaused !== undefined) this.isPaused = persisted.isPaused;
    if (persisted.stats) this.stats = persisted.stats;
  }

  getStats() { return this.stats; }
  getLog() { return this.log; }
}

if (typeof module !== 'undefined') {
  module.exports = { Orchestrator };
}
