/**
 * Rate Calculator — computes adjusted compensation rate
 * Pure function, no DOM dependencies.
 */

const EXCLUDED_RULES = [
  'delay',
  'late_order',
  'order_delay_rd',
  'تأخير',
  'تأخر',
  'تاخير',
  'modified_order_partial_refund'
];

function isDelayRelated(rule) {
  if (!rule) return false;
  const lower = rule.toLowerCase().trim();
  return EXCLUDED_RULES.some(exc => lower.includes(exc));
}

function isEmptyAutocomp(row) {
  if (!row.rule) return false;
  const rule = row.rule.toLowerCase().trim();
  if (rule !== 'autocomp') return false;
  return !row.reason || row.reason.trim() === '';
}

function shouldExcludeRow(row) {
  if (isDelayRelated(row.rule)) return true;
  if (isEmptyAutocomp(row)) return true;
  return false;
}

function calculateAdjustedRate(compensationRows, totalOrders, failedOrders) {
  if (!compensationRows || !Array.isArray(compensationRows)) {
    return { rate: 0, adjustedCompensations: 0, successOrders: 0, excludedCount: 0, totalRows: 0 };
  }

  const totalRows = compensationRows.length;
  const excludedRows = compensationRows.filter(row => shouldExcludeRow(row));
  const excludedCount = excludedRows.length;
  const adjustedCompensations = totalRows - excludedCount;

  const successOrders = (totalOrders || 0) - (failedOrders || 0);

  if (successOrders <= 0) {
    return { rate: 0, ratePercent: 0, adjustedCompensations, successOrders: 0, excludedCount, totalRows };
  }

  const rate = adjustedCompensations / successOrders;

  return {
    rate,
    ratePercent: Math.round(rate * 100 * 100) / 100,
    adjustedCompensations,
    successOrders,
    excludedCount,
    totalRows,
    excluded: excludedRows.map(r => ({ rule: r.rule, reason: r.reason }))
  };
}

if (typeof module !== 'undefined') {
  module.exports = { calculateAdjustedRate, shouldExcludeRow, isDelayRelated, isEmptyAutocomp };
}
