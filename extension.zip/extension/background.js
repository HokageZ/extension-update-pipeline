/**
 * Background Service Worker — Orchestration & State Management
 * HungerStation Fraud Detection Extension
 *
 * Dashboard/sidepanel are now extension pages. Communication uses
 * chrome.runtime.sendMessage / chrome.runtime.connect ports.
 * Updates are distributed as an unpacked ZIP; install.bat downloads and
 * extracts the latest package. The extension only checks update.xml to
 * notify users when a new version is available.
 */

try {
  importScripts(
    'engine/rate-calculator.js',
    'engine/checklist.js',
    'engine/verdict.js',
    'engine/refund-mapper.js',
    'engine/orchestrator.js',
    'services/gemini.js',
    'services/updater.js'
  );
} catch (e) {
  console.error('[FD:init] FATAL — failed to load engine scripts:', e);
  self.addEventListener('message', () => {
    self.clients?.matchAll().then(clients => {
      clients.forEach(c => c.postMessage({
        type: 'FATAL_ERROR',
        payload: { message: 'Engine scripts failed to load. Reload the extension.', detail: e?.message }
      }));
    });
  }, { once: true });
}

let settings = {};
let orchestrator = null;
let shiftStartTime = null;

const DASHBOARD_URL = 'dashboard/index.html';
const SIDEPANEL_URL = 'sidepanel/sidepanel.html';

// Frame registry: tabId -> { herocare_parent: frameId, onevu_iframe: frameId }
const frameRegistry = new Map();

function registerFrame(tabId, context, frameId) {
  if (!frameRegistry.has(tabId)) frameRegistry.set(tabId, {});
  frameRegistry.get(tabId)[context] = frameId;
  // Frame ids must survive an SW recycle too, or post-wake messages target the
  // wrong frame. persistSession() is defined later but hoisted by the time any
  // frame registers (well after init).
  if (typeof persistSession === 'function') persistSession();
}

function getFrameId(tabId, context) {
  return frameRegistry.get(tabId)?.[context];
}

function clearFramesForTab(tabId) {
  frameRegistry.delete(tabId);
}

self.getFrameId = getFrameId;
self.frameRegistry = frameRegistry;

// ===== DASHBOARD / SIDEPANEL BROADCAST =====

const dashboardPorts = new Set();

function sendToDashboard(msg) {
  dashboardPorts.forEach(port => {
    try { port.postMessage(msg); } catch (_) { dashboardPorts.delete(port); }
  });
}

async function findDashboardTabs() {
  const dashboardUrl = chrome.runtime.getURL(DASHBOARD_URL);
  return await chrome.tabs.query({ url: dashboardUrl + '*' });
}

async function ensureDashboardOpen() {
  const dashboardUrl = chrome.runtime.getURL(DASHBOARD_URL);
  const tabs = await findDashboardTabs();
  if (tabs.length > 0) {
    await chrome.windows.update(tabs[0].windowId, { focused: true });
    await chrome.tabs.update(tabs[0].id, { active: true });
    return tabs[0];
  }
  return await chrome.tabs.create({ url: dashboardUrl });
}

async function showHumanLoopAlert({ type, orderId, title, body, requireInteraction = true }) {
  const id = `fd-alert-${type}-${orderId || Date.now()}`;

  chrome.notifications.create(id, {
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title,
    message: body,
    requireInteraction
  });

  sendToDashboard({
    type: type === 'not-fraud' ? 'NOT_FRAUD_ALERT' : 'AUTONOMOUS_COUNTDOWN',
    payload: { orderId, reason: body, title }
  });

  chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
  chrome.action.setBadgeText({ text: '!' });
}

chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith('fd-alert-')) {
    ensureDashboardOpen();
    chrome.notifications.clear(notificationId);
  }
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'dashboard') return;
  dashboardPorts.add(port);
  port.onDisconnect.addListener(() => dashboardPorts.delete(port));
  // Defer STATE_UPDATE until settings + orchestrator are fully initialized,
  // so the dashboard never receives empty settings = {} as its first state.
  (async () => {
    try { await extensionReadyPromise; } catch (_) {}
    try {
      port.postMessage({ type: 'STATE_UPDATE', payload: getFullState() });
      port.postMessage({ type: 'LOG_HISTORY', payload: LOG_BUFFER.slice(0, 100) });
    } catch (_) {}
  })();
});

// ===== LOGGING =====

const LOG_BUFFER = [];
const MAX_LOG = 500;
const DECISION_LOG_KEY = 'decisionLogHistory';

async function persistDecisionLog(entry) {
  try {
    const stored = await chrome.storage.local.get(DECISION_LOG_KEY);
    const arr = Array.isArray(stored[DECISION_LOG_KEY]) ? stored[DECISION_LOG_KEY] : [];
    arr.unshift(entry);
    while (arr.length > MAX_LOG) arr.pop();
    await chrome.storage.local.set({ [DECISION_LOG_KEY]: arr });
  } catch (_) {}
}

async function loadPersistedDecisionLog() {
  try {
    const stored = await chrome.storage.local.get(DECISION_LOG_KEY);
    const arr = Array.isArray(stored[DECISION_LOG_KEY]) ? stored[DECISION_LOG_KEY] : [];
    arr.reverse().forEach(e => LOG_BUFFER.push(e));
    if (LOG_BUFFER.length > MAX_LOG) LOG_BUFFER.splice(0, LOG_BUFFER.length - MAX_LOG);
  } catch (_) {}
}

function log(level, source, message, data = null) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    source,
    message,
    data
  };
  LOG_BUFFER.unshift(entry);
  if (LOG_BUFFER.length > MAX_LOG) LOG_BUFFER.pop();

  if (entry.verdict !== undefined || (entry.type && ['error', 'warning', 'audit', 'info'].includes(entry.type))) {
    persistDecisionLog(entry);
  }

  const prefix = `[FD:${source}]`;
  if (level === 'error') console.error(prefix, message, data || '');
  else if (level === 'warn') console.warn(prefix, message, data || '');
  else if (level === 'debug') { return; }
  else console.log(prefix, message, data || '');

  sendToDashboard({ type: 'LOG', payload: entry });
}

// ===== STATE =====

function getFullState() {
  return {
    state: orchestrator?.state || 'idle',
    isPaused: orchestrator?.isPaused ?? true,
    mode: settings.mode || 'supervised',
    settings,
    ticket: orchestrator?.currentTicket || null,
    stats: orchestrator?.getStats() || { processed: 0, fraud: 0, notFraud: 0, errors: 0, skipped: 0 },
    shiftSummary: getShiftSummary(),
    extensionConnected: true,
    pendingConfirmation: orchestrator?.pendingConfirmation ? buildPendingDetail(orchestrator.pendingConfirmation) : null
  };
}

function buildPendingDetail(pc) {
  const v = pc.verdict || {};
  const ex = pc.extracted || {};
  const intake = pc.intake || {};

  // Compute apology and note previews so the sidepanel/dashboard can show
  // exactly what will be posted — addressing friction F1 and F2.
  let apologyPreview = null;
  let notePreview = null;
  const chatLanguage = intake.chatLanguage || 'ar';
  const isPreExisting = !!ex.isPreExisting || !!intake.isPreExisting;

  if (v.verdict === 'FRAUD') {
    try {
      const { getFraudResponse, getFraudNote } = typeof require !== 'undefined'
        ? require('./engine/verdict')
        : { getFraudResponse: self.getFraudResponse, getFraudNote: self.getFraudNote };
      apologyPreview = getFraudResponse(isPreExisting, settings, chatLanguage);
      notePreview = getFraudNote(v, settings);
    } catch (_) {}
  }

  // Build the note defaults map so the UI can show text for every note key
  // even if the user hasn't customized them (fixes F4: blank note previews).
  const NOTE_DEFAULTS = {
    rate: '\u0633\u062c\u0644 \u0633\u064a\u0621 - \u0639\u062f\u062f \u062a\u0639\u0648\u064a\u0636\u0627\u062a \u0639\u0627\u0644\u064a\u0629 \u0648\u0634\u0643\u0627\u0648\u064a \u0628\u0627\u0644\u0646\u0633\u0628\u0629 \u0644\u0644\u0637\u0644\u0628\u0627\u062a \u0627\u0644\u0646\u0627\u062c\u062d\u0647 - \u0627\u0639\u062a\u0630\u0627\u0631',
    same_day_frequency: '\u0633\u062c\u0644 \u0633\u064a\u0621 \u062a\u0639\u0648\u064a\u0636\u0627\u062a \u0645\u0631\u062a\u0641\u0639\u0647 \u0627\u062e\u0631 \u0641\u062a\u0631\u0647 \u0627\u0639\u062a\u0630\u0627\u0631',
    bulk_drinks: '\u062d\u0633\u0627\u0628 \u062c\u064a\u062f -\u0643\u0645\u064a\u0647 \u0645\u0634\u0631\u0648\u0628\u0627\u062a - \u0627\u0639\u062a\u0630\u0627\u0631',
    all_system_comps: '\u0633\u062c\u0644 \u0633\u0626 \u062a\u0639\u0648\u064a\u0636\u0627\u062a \u0645\u062a\u0643\u0631\u0631\u0647 \u0627\u0639\u062a\u0630\u0627\u0631',
    photo_mismatch: '\u062d\u0633\u0627\u0628 \u0627\u0644\u0639\u0645\u064a\u0644 \u063a\u064a\u0631 \u062c\u064a\u062f \u0628\u0633\u0628\u0628 \u062a\u0646\u0627\u0642\u0636 \u0635\u0648\u0631 \u0627\u0644\u062a\u0633\u0644\u064a\u0645 \u0645\u0639 \u0634\u0643\u0648\u0649 \u0627\u0644\u0639\u0645\u064a\u0644. \u062a\u0645 \u0627\u0644\u0627\u0639\u062a\u0630\u0627\u0631.',
    blocked_device: '\u0633\u064a\u0626 \u0639\u0644\u0649 \u0627\u0644\u0628\u0648\u0627\u0628\u0629 +\u0645\u0631\u062a\u0628\u0637 \u0628\u062d\u0633\u0627\u0628 \u0633\u064a\u0626 +\u0627\u0639\u062a\u0630\u0627\u0631',
    new_account_abuse: '\u062d\u0633\u0627\u0628 \u0627\u0644\u0639\u0645\u064a\u0644 \u063a\u064a\u0631 \u062c\u064a\u062f \u0628\u0633\u0628\u0628 \u0637\u0644\u0628 \u062a\u0639\u0648\u064a\u0636\u0627\u062a \u0639\u0644\u0649 \u062d\u0633\u0627\u0628 \u062c\u062f\u064a\u062f. \u062a\u0645 \u0627\u0644\u0627\u0639\u062a\u0630\u0627\u0631.',
    duplicate_order_comp: '\u062d\u0633\u0627\u0628 \u0627\u0644\u0639\u0645\u064a\u0644 \u063a\u064a\u0631 \u062c\u064a\u062f \u0628\u0633\u0628\u0628 \u062a\u0643\u0631\u0627\u0631 \u0627\u0644\u062a\u0639\u0648\u064a\u0636 \u0644\u0646\u0641\u0633 \u0627\u0644\u0637\u0644\u0628. \u062a\u0645 \u0627\u0644\u0627\u0639\u062a\u0630\u0627\u0631.',
    same_reason_pattern: '\u0633\u062c\u0644 \u0633\u0626 \u062a\u0639\u0648\u064a\u0636\u0627\u062a \u0645\u062a\u0643\u0631\u0631\u0647 \u0627\u0639\u062a\u0630\u0627\u0631',
    excessive_comp_ratio: '\u0633\u062c\u0644 \u0633\u064a\u0621 - \u062a\u0639\u0648\u064a\u0636\u0627\u062a \u0645\u0631\u062a\u0641\u0639\u0629 \u0627\u062e\u0631 \u0641\u062a\u0631\u0647 - \u0648 \u0634\u0643\u0627\u0648\u064a \u0645\u062a\u0643\u0631\u0631\u0647 - \u0627\u0639\u062a\u0630\u0627\u0631',
    connected_accounts: '\u0633\u062c\u0644 \u0633\u0626 //\u0645\u0631\u062a\u0628\u0637 \u0628\u062d\u0633\u0627\u0628 \u0645\u062d\u0638\u0648\u0631// \u0627\u0639\u062a\u0630\u0627\u0631'
  };
  const userNotes = settings.fraud_notes || {};
  const noteDefaults = {};
  for (const key in NOTE_DEFAULTS) {
    noteDefaults[key] = userNotes[key] || NOTE_DEFAULTS[key];
  }

  return {
    orderId: intake.orderId || ex.orderId || null,
    customerName: ex.customerName || null,
    mainUserId: ex.mainUserId || null,
    verdict: v.verdict || null,
    source: v.source || null,
    confidence: v.confidence || null,
    reason: v.reasons?.[0] || v.reasoning || null,
    reasons: v.reasons || [],
    ratePercent: v.rateResult?.ratePercent ?? null,
    checks: (v.checklistResult?.results || []).map((r, i) => ({
      n: i + 1, name: r.checkName || `Check ${i + 1}`, hit: !!r.hit, reason: r.reason, needsReview: !!r.needsReview
    })),
    // Previews of what will be posted (F1/F2 fix)
    apologyPreview: apologyPreview || null,
    notePreview: notePreview || null,
    chatLanguage,
    isPreExisting,
    noteDefaults,
    extracted: {
      totalOrders: ex.totalOrders ?? null,
      failedOrders: ex.failedOrders ?? null,
      complaintType: ex.complaintType || ex.complaintRaw || null,
      risk: ex.riskStatus?.isFraudulent ? 'flagged' : (ex.riskStatus ? 'ok' : null),
      compRows: Array.isArray(ex.compensationRows) ? ex.compensationRows.length : null,
      preExisting: !!ex.isPreExisting,
      connectedAccounts: ex.connectedAccounts?.accounts
        ? ex.connectedAccounts.accounts.map(a => ({
            userId: a.userId, viaDeviceId: a.viaDeviceId, anyHit: !!a.anyHit,
            hits: (a.hits || []).map(h => h.checkName).filter(Boolean)
          }))
        : null
    }
  };
}

// ===== SESSION PERSISTENCE =====
//
// The service worker terminates after ~30s idle; every global (orchestrator,
// frameRegistry, shiftStartTime) is wiped on the next wake. The most painful
// loss is `pendingConfirmation` in supervised mode: the verdict is computed,
// processTicket returns, the SW idles out, and the agent's "Confirm" click then
// hits the double-fire guard and silently does nothing — the ticket is stuck.
//
// We snapshot the in-flight state to chrome.storage.session (survives SW
// restarts, cleared on browser close) on every state transition and frame
// registration, and rehydrate it on wake. confirmExecution() is a fresh message
// entry point, so a restored pendingConfirmation makes the Confirm button work
// again across an SW recycle.

const SESSION_STATE_KEY = 'fdSessionState';

async function persistSession() {
  try {
    if (!orchestrator) return;
    await chrome.storage.session.set({
      [SESSION_STATE_KEY]: {
        state: orchestrator.state,
        isPaused: orchestrator.isPaused,
        stats: orchestrator.stats,
        currentTicket: orchestrator.currentTicket || null,
        currentTicketId: orchestrator.currentTicketId || null,
        pendingConfirmation: orchestrator.pendingConfirmation || null,
        doneThisRun: Array.from(orchestrator.doneThisRun || []),
        dismissedNotFraud: Array.from(orchestrator.dismissedNotFraud || []),
        shiftStartTime,
        frames: Array.from(frameRegistry.entries()),
        savedAt: Date.now()
      }
    });
  } catch (_) { /* session storage may be momentarily unavailable */ }
}

async function restoreSession() {
  try {
    const stored = await chrome.storage.session.get(SESSION_STATE_KEY);
    const s = stored[SESSION_STATE_KEY];
    if (!s || !orchestrator) return false;

    if (s.stats) orchestrator.stats = s.stats;
    if (typeof s.isPaused === 'boolean') orchestrator.isPaused = s.isPaused;
    orchestrator.currentTicket = s.currentTicket || null;
    orchestrator.currentTicketId = s.currentTicketId || null;
    orchestrator.pendingConfirmation = s.pendingConfirmation || null;
    orchestrator.doneThisRun = new Set(s.doneThisRun || []);
    orchestrator.dismissedNotFraud = new Set(s.dismissedNotFraud || []);
    if (s.shiftStartTime) shiftStartTime = s.shiftStartTime;
    if (Array.isArray(s.frames)) {
      frameRegistry.clear();
      for (const [tabId, ctx] of s.frames) frameRegistry.set(tabId, ctx);
    }

    // A pending confirmation is a resumable entry point — keep state on 'verdict'
    // so the UI re-renders the verdict card and confirmExecution() accepts it.
    // Any other non-idle state belonged to an async flow that died with the SW;
    // we cannot resume that promise chain, so fall back to idle.
    if (s.pendingConfirmation) {
      orchestrator.state = 'verdict';
      log('info', 'init', 'Restored a pending confirmation from a previous worker lifetime', { orderId: s.currentTicket?.orderId });
    } else {
      orchestrator.state = 'idle';
    }
    return true;
  } catch (_) {
    return false;
  }
}

// ===== BADGE =====

const BADGE_COLORS = { autonomous: '#22c55e', supervised: '#eab308', audit: '#9ca3af', paused: '#ef4444' };
const BADGE_TEXT = { autonomous: 'AUTO', supervised: 'SUP', audit: 'DRY', paused: '||' };

function updateBadge() {
  if (!orchestrator) return;
  const key = orchestrator.isPaused ? 'paused' : (settings.mode || 'supervised');
  chrome.action.setBadgeBackgroundColor({ color: BADGE_COLORS[key] || '#9ca3af' });
  chrome.action.setBadgeText({ text: BADGE_TEXT[key] || '' });
}

// ===== PROCESSING =====

function startProcessing() {
  if (!orchestrator) { log('error', 'process', 'Orchestrator not initialized'); return; }
  if (orchestrator.state !== 'idle') { log('warn', 'process', `Cannot start — state is ${orchestrator.state}`); return; }
  if (orchestrator.isPaused) { log('warn', 'process', 'Cannot start — paused'); return; }

  if (!shiftStartTime) shiftStartTime = Date.now();
  orchestrator.oneShot = false;
  orchestrator.doneThisRun.clear();
  orchestrator.currentTicketId = null;
  log('info', 'process', 'Starting ticket processing...');
  orchestrator.processTicket().catch(e => {
    log('error', 'process', 'processTicket threw', e.message);
  });
}

async function listQueueTickets() {
  try {
    const heroTabs = await chrome.tabs.query({ url: 'https://hungerstation-mena.deliveryherocare.com/*' });
    if (!heroTabs.length) return { ok: false, error: 'No HeroCare tab found', tickets: [] };
    const resp = await chrome.tabs.sendMessage(heroTabs[0].id, { type: 'LIST_TICKETS' }, { frameId: 0 });
    return { ok: true, tickets: resp?.tickets || [] };
  } catch (e) {
    return { ok: false, error: e.message, tickets: [] };
  }
}

function solveSpecificTicket(ticketId) {
  if (!orchestrator) return { ok: false, error: 'Orchestrator not initialized' };
  if (orchestrator.state !== 'idle') return { ok: false, error: `Busy (${orchestrator.state})` };
  orchestrator.isPaused = false;
  updateBadge();
  if (!shiftStartTime) shiftStartTime = Date.now();
  log('info', 'process', `Solving ticket on command: ${ticketId || '(next in queue)'}`);
  orchestrator.solveTicket(ticketId).catch(e => {
    log('error', 'process', 'solveTicket threw', e.message);
  });
  return { ok: true };
}

function parseInvestigationInput(input) {
  if (!input) return null;
  const s = String(input).trim();

  const opMatch = s.match(/\/operation\/[^/]+\/orders\/(\d+)/);
  if (opMatch) return { type: 'order', value: opMatch[1] };

  const uuidMatch = s.match(/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/);
  if (uuidMatch) return { type: 'case', value: uuidMatch[0] };

  if (/^\d+$/.test(s)) return { type: 'order', value: s };

  return null;
}

function investigateCase(input) {
  if (!orchestrator) return { ok: false, error: 'Orchestrator not initialized' };
  if (orchestrator.state !== 'idle') return { ok: false, error: `Busy (${orchestrator.state})` };
  const parsed = parseInvestigationInput(input);
  if (!parsed) return { ok: false, error: 'Could not find a case id or order id in that input. Paste a HeroCare case URL/UUID, an OP order URL, or a raw order id.' };

  orchestrator.isPaused = false;
  updateBadge();
  if (!shiftStartTime) shiftStartTime = Date.now();

  if (parsed.type === 'order') {
    log('info', 'process', `Manual investigation: OP order ${parsed.value}`);
    orchestrator.solveOrder(parsed.value).catch(e => {
      log('error', 'process', 'solveOrder threw', e.message);
    });
    return { ok: true, orderId: parsed.value };
  }

  log('info', 'process', `Manual investigation: case ${parsed.value}`);
  orchestrator.solveCase(parsed.value).catch(e => {
    log('error', 'process', 'solveCase threw', e.message);
  });
  return { ok: true, caseId: parsed.value };
}

function skipCurrentTicket() {
  if (orchestrator?.currentTicket?.orderId) {
    log('info', 'process', `Skipping ticket: ${orchestrator.currentTicket.orderId}`);
    orchestrator.dismissedNotFraud.add(orchestrator.currentTicket.orderId);
    orchestrator.stats.skipped++;
    orchestrator.pendingConfirmation = null;
    orchestrator.currentTicket = null;
    orchestrator.markTicketDone();
    orchestrator.setState('idle');
  }
}

// ===== SHIFT SUMMARY =====

function getShiftSummary() {
  if (!orchestrator || !shiftStartTime) return null;
  const elapsed = Date.now() - shiftStartTime;
  const h = Math.floor(elapsed / 3600000);
  const m = Math.floor((elapsed % 3600000) / 60000);
  const stats = orchestrator.getStats();
  return {
    shiftStart: new Date(shiftStartTime).toLocaleTimeString(),
    duration: `${h}h ${m}m`,
    durationMs: elapsed,
    ...stats,
    avgTimePerTicket: stats.processed > 0 ? Math.round(elapsed / stats.processed / 1000) + 's' : '—',
    fraudRate: stats.processed > 0 ? Math.round((stats.fraud / stats.processed) * 100) + '%' : '—'
  };
}

// ===== KEEPALIVE =====
//
// Keepalive MUST be driven by chrome.alarms, not setInterval. A service worker
// terminates after ~30s idle, which silently cancels any setInterval — the old
// implementation stopped pinging (and stopped detecting VPN drops) the first
// time the SW recycled. The alarm both wakes the SW and runs the work.
// See chrome.alarms.onAlarm listener + ensureKeepaliveAlarm() below.

const KEEPALIVE_ALARM = 'keepalive';

async function runKeepalive() {
  // The alarm can fire on a freshly-woken SW before init finished — wait so
  // `settings`/`orchestrator` are populated rather than acting on empty globals.
  try { await extensionReadyPromise; } catch (_) {}

  let opTabFound = false;
  const tabs = await chrome.tabs.query({
    url: ['https://hungerstation-mena.deliveryherocare.com/*', 'https://*.hungerstation.com/operation/*']
  }).catch(() => []);

  for (const tab of (tabs || [])) {
    chrome.tabs.sendMessage(tab.id, { type: 'KEEPALIVE_PING' }).catch(() => {});
    if (tab.url?.includes('/operation/') && settings.vpn_check_before_op && orchestrator && !orchestrator.isPaused && orchestrator.state !== 'idle') {
      opTabFound = true;
      chrome.tabs.sendMessage(tab.id, { type: 'CHECK_VPN' }).then(resp => {
        if (resp && !resp.active) {
          orchestrator.pause();
          updateBadge();
          log('warn', 'vpn', 'VPN disconnect detected — processing paused');
          sendToDashboard({ type: 'VPN_DISCONNECTED', payload: { message: 'VPN appears offline. Processing paused. Reconnect VPN and resume.' } });
          chrome.notifications.create('fd-alert-vpn_disconnect', {
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'Fraud Detection — VPN Disconnected',
            message: 'VPN appears offline. Processing has been paused.'
          });
        }
      }).catch(() => {});
    }
  }
  if (!opTabFound && settings.vpn_check_before_op && orchestrator && !orchestrator.isPaused && orchestrator.state !== 'idle') {
    log('warn', 'vpn', 'No OP tab found during keepalive — cannot verify VPN');
  }
}

// (Re)create the keepalive alarm using the configured interval. chrome.alarms
// enforces a 30s floor, so sub-30s settings are clamped. Called at init and
// whenever settings change.
function ensureKeepaliveAlarm() {
  const ms = settings.session_keepalive_interval_ms || 60000;
  const periodInMinutes = Math.max(0.5, ms / 60000); // 0.5 min = 30s floor
  chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === KEEPALIVE_ALARM) runKeepalive();
});

// ===== DIAGNOSTICS =====

async function runDiagnostics() {
  const results = {
    timestamp: new Date().toISOString(),
    extensionContext: !!chrome.runtime?.id,
    serverConnected: true,
    mode: settings.mode || 'supervised',
    state: orchestrator?.state || 'idle',
    isPaused: orchestrator?.isPaused ?? true,
    tabs: []
  };

  try {
    const heroTabs = await chrome.tabs.query({ url: 'https://hungerstation-mena.deliveryherocare.com/*' });
    const opTabs = await chrome.tabs.query({ url: 'https://*.hungerstation.com/operation/*' });

    for (const tab of heroTabs) {
      let contentScriptOk = false;
      let ticketCount = 0;
      try {
        const resp = await chrome.tabs.sendMessage(tab.id, { type: 'KEEPALIVE_PING' });
        contentScriptOk = !!resp;
        if (contentScriptOk) {
          const detect = await chrome.tabs.sendMessage(tab.id, { type: 'DETECT_TICKET' }, { frameId: 0 });
          ticketCount = detect?.count || 0;
        }
      } catch (e) {
        contentScriptOk = false;
      }
      results.tabs.push({
        system: 'herocare',
        id: tab.id,
        url: tab.url,
        title: tab.title,
        active: tab.active,
        contentScript: contentScriptOk ? 'connected' : 'missing (refresh page)',
        ticketsFound: ticketCount
      });
    }

    for (const tab of opTabs) {
      let contentScriptOk = false;
      let vpnActive = false;
      try {
        const resp = await chrome.tabs.sendMessage(tab.id, { type: 'KEEPALIVE_PING' });
        contentScriptOk = !!resp;
        if (contentScriptOk) {
          const vpn = await chrome.tabs.sendMessage(tab.id, { type: 'CHECK_VPN' });
          vpnActive = vpn?.active || false;
        }
      } catch (e) {
        contentScriptOk = false;
      }
      results.tabs.push({
        system: 'operation',
        id: tab.id,
        url: tab.url,
        title: tab.title,
        active: tab.active,
        contentScript: contentScriptOk ? 'connected' : 'missing (refresh page)',
        vpnActive
      });
    }

    if (results.tabs.length === 0) {
      results.warning = 'No HeroCare or Operation Portal tabs found. Open them in Chrome.';
    }
  } catch (e) {
    results.error = e.message;
  }

  return results;
}

async function testTicketDetection() {
  try {
    const heroTabs = await chrome.tabs.query({ url: 'https://hungerstation-mena.deliveryherocare.com/*' });
    if (heroTabs.length === 0) {
      return { system: 'herocare', ok: false, error: 'No HeroCare tab found' };
    }
    const tab = heroTabs[0];
    try {
      await chrome.tabs.sendMessage(tab.id, { type: 'KEEPALIVE_PING' });
    } catch (e) {
      if (e.message.includes('Receiving end does not exist')) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content-scripts/selector-helper.js', 'content-scripts/herocare.js']
        });
      }
    }
    const detect = await chrome.tabs.sendMessage(tab.id, { type: 'DETECT_TICKET' }, { frameId: 0 });
    const intake = await chrome.tabs.sendMessage(tab.id, { type: 'PARSE_INTAKE' }, { frameId: 0 });
    if (intake?.data?.orderId) {
      try { await chrome.tabs.sendMessage(tab.id, { type: 'PICK_UP_TICKET' }, { frameId: 0 }); } catch (_) {}
    }
    return {
      system: 'herocare',
      ok: true,
      ticketsInQueue: detect?.count || 0,
      intake: intake?.data || null
    };
  } catch (e) {
    return { system: 'herocare', ok: false, error: e.message };
  }
}

async function testVpn() {
  try {
    const opTabs = await chrome.tabs.query({ url: 'https://*.hungerstation.com/operation/*' });
    if (opTabs.length === 0) {
      return { system: 'operation', ok: false, error: 'No Operation Portal tab found', vpnActive: false };
    }
    const tab = opTabs[0];
    try {
      await chrome.tabs.sendMessage(tab.id, { type: 'KEEPALIVE_PING' });
    } catch (e) {
      if (e.message.includes('Receiving end does not exist')) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content-scripts/selector-helper.js', 'content-scripts/op.js']
        });
      }
    }
    const vpn = await chrome.tabs.sendMessage(tab.id, { type: 'CHECK_VPN' });
    const pageType = await chrome.tabs.sendMessage(tab.id, { type: 'GET_PAGE_TYPE' });
    return {
      system: 'operation',
      ok: true,
      vpnActive: vpn?.active || false,
      pageType: pageType?.pageType || 'unknown'
    };
  } catch (e) {
    return { system: 'operation', ok: false, error: e.message, vpnActive: false };
  }
}

function testOpUrlParsing() {
  const cases = [
    { input: 'https://hungerstation.com/operation/en/orders/375076306', expected: '375076306' },
    { input: '375076306', expected: '375076306' },
    { input: 'https://hungerstation-mena.deliveryherocare.com/cases/123e4567-e89b-12d3-a456-426614174000', expected: '123e4567-e89b-12d3-a456-426614174000' },
    { input: '123e4567-e89b-12d3-a456-426614174000', expected: '123e4567-e89b-12d3-a456-426614174000' }
  ];
  const results = cases.map(c => {
    const parsed = parseInvestigationInput(c.input);
    const ok = parsed?.value === c.expected;
    return { input: c.input, ok, got: parsed?.value };
  });
  return { ok: results.every(r => r.ok), results };
}

function testStopScraping() {
  if (orchestrator) {
    orchestrator.stopScraping = true;
    return { ok: true, stopScrapingFlag: orchestrator.stopScraping };
  }
  return { ok: false, error: 'Orchestrator not initialized' };
}

function testDeletedAccountNotes() {
  const samples = [
    { notes: ['حساب سيء تم الحظر'], expected: true },
    { notes: ['account deleted due to fraud'], expected: true },
    { notes: ['normal follow-up'], expected: false }
  ];
  const pattern = /(حساب\s+سيء|تم\s+المنع|تم\s+الحذف|تم\s+الحظر|محظور|موقوف|ممنوع|banned|blocked|suspend|محذوف\s+بسبب|اعتذار\s+بسبب\s+سجل|سجل\s+سيء)/i;
  const results = samples.map(s => ({
    notes: s.notes,
    expected: s.expected,
    got: pattern.test(s.notes.join(' '))
  }));
  return { ok: results.every(r => r.expected === r.got), results };
}

function testConnectedDepth() {
  const enabled = settings.check_connected_accounts !== false;
  return {
    ok: true,
    enabled,
    connected_max_depth: settings.connected_max_depth ?? 2,
    connected_max_devices: settings.connected_max_devices ?? 5,
    connected_max_accounts: settings.connected_max_accounts ?? 6
  };
}

async function verifyFlow() {
  const results = {
    settingsLoaded: !!settings.mode,
    orchestratorReady: !!orchestrator,
    tabs: await runDiagnostics()
  };
  return { ok: results.settingsLoaded && results.orchestratorReady, ...results };
}

// ===== MESSAGE HANDLER =====

function handleDashboardMessage(message, sendResponse) {
  switch (message.type) {
    case 'GET_STATE':
      (async () => {
        try { await extensionReadyPromise; } catch (_) {}
        sendResponse({ type: 'STATE_UPDATE', payload: getFullState() });
      })();
      return true;
    case 'SET_PAUSE':
      if (orchestrator?.state === 'countdown' && orchestrator.cancelCountdown) {
        orchestrator.cancelCountdown();
      }
      if (message.payload) { orchestrator?.pause(); }
      else { orchestrator?.resume(); if (!shiftStartTime) shiftStartTime = Date.now(); }
      updateBadge();
      sendResponse({ ok: true });
      break;
    case 'SET_MODE':
      settings.mode = message.payload;
      chrome.storage.local.set({ settings });
      if (orchestrator) orchestrator.settings = settings;
      updateBadge();
      // Push the new mode to every connected surface (sidepanel + dashboard)
      // so their mode selector re-renders the active state.
      sendToDashboard({ type: 'STATE_UPDATE', payload: getFullState() });
      sendResponse({ ok: true });
      break;
    case 'UPDATE_SETTINGS':
      settings = { ...settings, ...message.payload };
      chrome.storage.local.set({ settings });
      if (orchestrator) orchestrator.settings = settings;
      ensureKeepaliveAlarm();
      updateBadge();
      log('info', 'settings', 'Settings updated from dashboard');
      sendResponse({ ok: true });
      break;
    case 'GET_LOG':
      sendResponse({ type: 'LOG_HISTORY', payload: LOG_BUFFER.slice(0, 100) });
      break;
    case 'CLEAR_LOG':
      LOG_BUFFER.length = 0;
      if (orchestrator) orchestrator.log = [];
      chrome.storage.local.set({ [DECISION_LOG_KEY]: [] });
      log('info', 'sys', 'All logs cleared from worker memory');
      sendResponse({ ok: true, log: [] });
      break;
    case 'START_PROCESSING':
      startProcessing();
      sendResponse({ ok: true });
      break;
    case 'LIST_TICKETS':
      listQueueTickets().then(result => sendResponse(result));
      return true;
    case 'SOLVE_TICKET':
      sendResponse(solveSpecificTicket(message.payload?.ticketId));
      break;
    case 'INVESTIGATE_CASE':
      sendResponse(investigateCase(message.payload?.input));
      break;
    case 'SKIP_TICKET':
      if (orchestrator?.state === 'countdown' && orchestrator.cancelCountdown) {
        orchestrator.cancelCountdown();
      }
      skipCurrentTicket();
      sendResponse({ ok: true });
      break;
    case 'STOP_SCRAPING':
      if (orchestrator) {
        orchestrator.stopScraping = true;
        log('info', 'process', 'Stop scraping requested from dashboard — extraction will return current data and continue to calculation/checklist');
      }
      sendResponse({ ok: true, state: orchestrator?.state || 'idle' });
      break;
    case 'CONFIRM_EXECUTION':
      if (orchestrator?.state === 'countdown' && orchestrator.cancelCountdown) {
        orchestrator.cancelCountdown();
      }
      orchestrator?.confirmExecution(
        message.payload?.override || null,
        message.payload?.noteKey || null,
        message.payload?.editedApology || null,
        message.payload?.editedNote || null
      );
      sendResponse({ ok: true });
      break;
    case 'DISMISS_NOT_FRAUD':
      if (orchestrator && message.payload?.orderId) {
        orchestrator.dismissedNotFraud.add(message.payload.orderId);
        log('info', 'not-fraud-alert', `Agent dismissed NOT_FRAUD alert for ${message.payload.orderId}`);
      }
      sendResponse({ ok: true });
      break;
    case 'END_SHIFT':
      const summary = getShiftSummary();
      shiftStartTime = null;
      sendResponse({ type: 'SHIFT_SUMMARY', payload: summary });
      break;
    case 'DIAGNOSE':
      runDiagnostics().then(result => sendResponse({ type: 'DIAGNOSTIC_RESULT', payload: result }));
      return true;
    case 'TEST_TICKET_DETECTION':
      testTicketDetection().then(result => sendResponse({ type: 'DIAGNOSTIC_RESULT', payload: result }));
      return true;
    case 'TEST_VPN':
      testVpn().then(result => sendResponse({ type: 'DIAGNOSTIC_RESULT', payload: result }));
      return true;
    case 'PHOTO_REVIEW_NEEDED':
      sendResponse({ ok: true, disabled: true });
      break;
    case 'VERIFY_FLOW':
      verifyFlow().then(result => sendResponse({ type: 'DIAGNOSTIC_RESULT', payload: result }));
      return true;
    case 'TEST_OP_URL_PARSING':
      sendResponse({ type: 'DIAGNOSTIC_RESULT', payload: testOpUrlParsing() });
      break;
    case 'TEST_STOP_SCRAPING':
      sendResponse({ type: 'DIAGNOSTIC_RESULT', payload: testStopScraping() });
      break;
    case 'TEST_DELETED_ACCOUNT_NOTES':
      sendResponse({ type: 'DIAGNOSTIC_RESULT', payload: testDeletedAccountNotes() });
      break;
    case 'TEST_CONNECTED_DEPTH':
      sendResponse({ type: 'DIAGNOSTIC_RESULT', payload: testConnectedDepth() });
      break;
    case 'CHECK_FOR_UPDATE':
      if (typeof Updater !== 'undefined') {
        Updater.checkForUpdates({ notify: true }).then(result => {
          sendResponse({ type: 'UPDATE_CHECK_RESULT', payload: result });
        });
        return true;
      }
      sendResponse({ type: 'UPDATE_CHECK_RESULT', payload: { error: 'Updater not loaded' } });
      break;
    case 'EXECUTE_UPDATE':
      if (typeof Updater !== 'undefined') {
        sendResponse({ type: 'UPDATE_INFO', payload: { message: 'Please re-run install.bat to update the extension.', installBatUrl: Updater.installBatUrl } });
      } else {
        sendResponse({ type: 'UPDATE_ERROR', payload: { error: 'Updater not loaded' } });
      }
      break;
    default:
      log('warn', 'msg', `Unknown message type: ${message.type}`);
      sendResponse({ error: 'Unknown message type' });
  }
  return false;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.tab?.id != null && message.type === 'REGISTER_FRAME') {
    const context = message.payload?.context || 'unknown';
    registerFrame(sender.tab.id, context, sender.frameId);
    sendResponse({ ok: true });
    return false;
  }
  return handleDashboardMessage(message, sendResponse);
});

// ===== ORCHESTRATOR HOOKS =====

function setupOrchestratorHooks() {
  const origSetState = orchestrator.setState.bind(orchestrator);
  orchestrator.setState = function(state) {
    origSetState(state);
    updateBadge();
    // Snapshot in-flight state to storage.session so a pending confirmation /
    // current ticket survives an SW recycle (see SESSION PERSISTENCE).
    persistSession();
    log('info', 'state', `→ ${state}`, { ticket: this.currentTicket?.orderId });
    sendToDashboard({ type: 'STATE_UPDATE', payload: getFullState() });
  };

  const origHandleError = orchestrator.handleError.bind(orchestrator);
  orchestrator.handleError = function(message, detail = null) {
    const msg = typeof message === 'string' ? message : (message?.message || JSON.stringify(message));
    const orderId = this.currentTicket?.orderId || detail?.orderId || null;
    origHandleError(msg, detail);
    log('error', `orchestrator:${detail?.phase || this.state || '?'}`, msg, {
      orderId,
      phase: detail?.phase,
      reason: detail?.reason,
      underlyingError: detail?.error,
      stack: detail?.stack
    });
    updateBadge();
  };

  const origAddLog = orchestrator.addLog.bind(orchestrator);
  orchestrator.addLog = function(entry) {
    origAddLog(entry);
    const level = entry.type === 'error' ? 'error' : entry.type === 'warning' ? 'warn' : 'info';
    const src = entry.phase ? `decision:${entry.phase}` : 'decision';
    log(level, src, entry.message || entry.verdict || entry.type, entry);
    sendToDashboard({ type: 'DECISION_LOG', payload: entry });
  };

  const origBroadcast = orchestrator.broadcast.bind(orchestrator);
  orchestrator.broadcast = function(message) {
    origBroadcast(message);
    if (message?.type === 'NOT_FRAUD_ALERT') {
      const orderId = message.payload?.orderId;
      log('warn', 'not-fraud-alert', `NOT_FRAUD alert for ${orderId}`, message.payload);
      showHumanLoopAlert({
        type: 'not-fraud',
        orderId,
        title: 'Fraud Cockpit — manual refund required',
        body: `Order #${orderId} was marked NOT FRAUD. Review and process the refund manually.`,
        requireInteraction: true
      });
    }
    if (message?.type === 'AUTONOMOUS_COUNTDOWN') {
      const { orderId, verdict, seconds } = message.payload || {};
      showHumanLoopAlert({
        type: 'countdown',
        orderId,
        title: `Autonomous execution in ${seconds}s`,
        body: `Order #${orderId} · ${verdict}. Open sidepanel to cancel.`,
        requireInteraction: false
      });
    }
  };
}

// ===== LIFECYCLE: INSTALL / UPDATE / STARTUP =====
//
// Mirrors the manifest content_scripts so we can re-inject into already-open
// tabs. The manifest auto-injects on navigation, but NOT into tabs that were
// already open when the extension updated — and updater.js calls
// chrome.runtime.reload() on every self-update, orphaning those content scripts.
const CONTENT_SCRIPT_GROUPS = [
  { matches: ['https://hungerstation-mena.deliveryherocare.com/*'], files: ['content-scripts/selector-helper.js', 'content-scripts/herocare.js'], allFrames: false },
  { matches: ['https://oneview-mercury-hungerstation-mena.deliveryherocare.com/*'], files: ['content-scripts/selector-helper.js', 'content-scripts/onevu.js'], allFrames: true },
  { matches: ['https://*.hungerstation.com/operation/*'], files: ['content-scripts/selector-helper.js', 'content-scripts/op.js'], allFrames: false }
];

async function reinjectContentScripts() {
  for (const group of CONTENT_SCRIPT_GROUPS) {
    let tabs = [];
    try { tabs = await chrome.tabs.query({ url: group.matches }); } catch (_) { continue; }
    for (const tab of tabs) {
      if (!tab.id) continue;
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: group.allFrames },
          files: group.files
        });
      } catch (_) { /* discarded/restricted tab — manifest will inject on its next load */ }
    }
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  ensureKeepaliveAlarm();
  // Re-inject fresh content scripts so agents don't have to manually refresh
  // every open HeroCare / Operation Portal tab after an install or update.
  if (details.reason === 'update' || details.reason === 'install') {
    reinjectContentScripts();
  }
});

chrome.runtime.onStartup.addListener(() => {
  // Re-arm the keepalive alarm on browser restart (alarms persist, but this is
  // cheap and idempotent and guards against a cleared alarm store).
  ensureKeepaliveAlarm();
});

// ===== ALARMS =====
// The keepalive alarm is (re)created from settings in ensureKeepaliveAlarm(),
// called during init and on settings changes. onInstalled/onStartup also call
// it so the alarm is restored after updates and browser restarts.

// ===== SETTINGS =====

async function loadSettings() {
  try {
    const result = await chrome.storage.local.get('settings');
    if (result.settings) {
      settings = result.settings;
    } else {
      const response = await fetch(chrome.runtime.getURL('config/default-settings.json'));
      settings = await response.json();
      await chrome.storage.local.set({ settings });
    }
    log('info', 'init', 'Settings loaded', { mode: settings.mode });
  } catch (e) {
    log('error', 'init', 'Failed to load settings', e.message);
    settings = { mode: 'supervised', delays: {}, thresholds: {} };
  }
  return settings;
}

// ===== INITIALIZE =====

const extensionReadyPromise = loadSettings().then(async () => {
  await loadPersistedDecisionLog();

  orchestrator = new Orchestrator(settings);
  setupOrchestratorHooks();

  try {
    const stored = await chrome.storage.local.get('orchestratorState');
    if (stored.orchestratorState) {
      orchestrator.restoreState(stored.orchestratorState);
      log('info', 'init', 'Restored previous session state', { stats: orchestrator.stats });
    }
  } catch (e) {
    log('warn', 'init', 'Could not restore session state', e.message);
  }

  // Rehydrate live in-flight state (current ticket, pending confirmation, frame
  // registry) from storage.session — survives an SW recycle within the same
  // browser session and takes precedence over the coarser local snapshot above.
  try {
    await restoreSession();
  } catch (e) {
    log('warn', 'init', 'Could not restore session snapshot', e.message);
  }

  ensureKeepaliveAlarm();
  updateBadge();

  // Start the self-updater checker for unpacked installs.
  try {
    if (typeof Updater !== 'undefined') {
      Updater.startUpdateChecker();
    }
  } catch (e) {
    log('warn', 'updater', 'Could not start update checker', e.message);
  }

  try {
    if (chrome.sidePanel?.setPanelBehavior) {
      await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    }
  } catch (e) {
    log('warn', 'init', 'Could not set side panel behavior', e.message);
  }

  log('info', 'init', `Background worker ready — mode: ${settings.mode}`);
}).catch(e => {
  console.error('[FD:init] FATAL:', e);
});
