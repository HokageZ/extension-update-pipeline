/* Fraud Cockpit — merged side-panel controller (replaces the old toolbar popup).
   Uses the existing background message types: GET_STATE, GET_LOG, LIST_TICKETS,
   SOLVE_TICKET, INVESTIGATE_CASE, SET_MODE, SET_PAUSE, START_PROCESSING,
   STOP_SCRAPING, SKIP_TICKET, CONFIRM_EXECUTION, VERIFY_FLOW, DIAGNOSE, TEST_TICKET_DETECTION. */
(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

  const MODE_LABEL = { supervised: 'SUPERVISED', autonomous: 'AUTONOMOUS', audit: 'AUDIT (DRY RUN)' };

  let port = null;
  let prevState = 'idle'; // tracks last orchestrator state to detect idle re-entry

  function connectPort() {
    if (port) {
      try { port.disconnect(); } catch (_) {}
      port = null;
    }
    if (!chrome.runtime?.id) return;
    try {
      port = chrome.runtime.connect({ name: 'dashboard' });
      port.onMessage.addListener(handlePortMessage);
      port.onDisconnect.addListener(() => {
        port = null;
        setTimeout(connectPort, 2000);
      });
      port.postMessage({ type: 'GET_STATE' });
      port.postMessage({ type: 'GET_LOG' });
      loadQueue();
    } catch (_) {}
  }

  function send(msg, cb) {
    try {
      if (!chrome.runtime?.id) { if (cb) cb({ ok: false, error: 'extension reloading' }); return; }
      chrome.runtime.sendMessage(msg, (resp) => {
        // Always invoke the callback, even on lastError, so callers that flip a
        // busy flag (e.g. queueBusy on SOLVE_TICKET) can always reset it.
        if (chrome.runtime.lastError) { if (cb) cb({ ok: false, error: chrome.runtime.lastError.message }); return; }
        if (cb) cb(resp);
      });
    } catch (e) { if (cb) cb({ ok: false, error: e.message }); }
  }

  function handlePortMessage(msg) {
    if (!msg || !msg.type) return;
    switch (msg.type) {
      case 'STATE_UPDATE':
        renderState(msg.payload);
        break;
      case 'LOG_HISTORY':
        renderLog(msg.payload);
        break;
      case 'DECISION_LOG':
        prependLogEntry(msg.payload);
        break;
      case 'LOG':
        prependLogEntry(msg.payload);
        break;
      case 'NOT_FRAUD_ALERT':
        maybeRenderNotFraudBanner(msg.payload);
        break;
      case 'AUTONOMOUS_COUNTDOWN':
        maybeRenderCountdownBanner(msg.payload);
        break;
      case 'UPDATE_AVAILABLE':
        renderUpdateBadge(msg.payload);
        break;
    }
  }

  function renderUpdateBadge(payload) {
    const badge = $('updateBadge');
    if (!badge) return;
    if (payload?.hasUpdate) {
      badge.style.display = 'inline-block';
      badge.title = `Update v${payload.latest} available. Open dashboard to install.`;
      badge.onclick = () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/index.html') });
      };
    } else {
      badge.style.display = 'none';
    }
  }

  let activeBannerOrderId = null;
  function maybeRenderNotFraudBanner(payload) {
    const orderId = payload?.orderId;
    if (!orderId || activeBannerOrderId === orderId) return;
    activeBannerOrderId = orderId;
    const card = $('decisionCard');
    const banner = document.createElement('div');
    banner.className = 'decision';
    banner.style.marginBottom = '12px';
    banner.innerHTML = `
      <div class="d-head"><span class="d-label">Manual Refund Required</span><span class="d-order">#${esc(orderId)}</span></div>
      <div class="verdict NOT_FRAUD">✓ NOT FRAUD</div>
      <div class="kv"><span class="k">Reason</span><span class="v">${esc(payload.reason || 'review required')}</span></div>
      <div class="d-actions"><button class="btn-exec" id="dismissNotFraudBtn">DISMISS</button></div>`;
    card.parentNode.insertBefore(banner, card);
    $('dismissNotFraudBtn').addEventListener('click', () => {
      banner.remove();
      activeBannerOrderId = null;
      send({ type: 'DISMISS_NOT_FRAUD', payload: { orderId } });
    });
  }

  let countdownInterval = null;
  function maybeRenderCountdownBanner(payload) {
    const orderId = payload?.orderId;
    const seconds = payload?.seconds || 0;
    if (!orderId || seconds <= 0) return;
    const card = $('decisionCard');
    let banner = document.getElementById('countdownBanner');
    if (banner) banner.remove();
    banner = document.createElement('div');
    banner.id = 'countdownBanner';
    banner.className = 'decision';
    banner.style.marginBottom = '12px';
    banner.innerHTML = `
      <div class="d-head"><span class="d-label">Autonomous Execution</span><span class="d-order">#${esc(orderId)}</span></div>
      <div class="verdict">${esc(payload.verdict || '?')} · <span id="countdownSec">${seconds}</span>s</div>
      <div class="d-actions"><button class="btn-flip" id="cancelCountdownBtn">CANCEL & REVIEW</button></div>`;
    card.parentNode.insertBefore(banner, card);
    if (countdownInterval) clearInterval(countdownInterval);
    const end = Date.now() + seconds * 1000;
    countdownInterval = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((end - Date.now()) / 1000));
      const secEl = document.getElementById('countdownSec');
      if (secEl) secEl.textContent = remaining;
      if (remaining <= 0) {
        clearInterval(countdownInterval);
        countdownInterval = null;
        if (banner) banner.remove();
      }
    }, 250);
    $('cancelCountdownBtn').addEventListener('click', () => {
      clearInterval(countdownInterval);
      countdownInterval = null;
      banner.remove();
      send({ type: 'SET_MODE', payload: 'supervised' });
      send({ type: 'SET_PAUSE', payload: true });
    });
  }

  function prependLogEntry(entry) {
    const box = $('log');
    const empty = box.querySelector('.q-empty');
    if (empty) empty.remove();
    const lvl = entry.level || (entry.type === 'error' ? 'error' : entry.type === 'warning' ? 'warn' : 'info');
    const t = entry.ts || entry.timestamp;
    const time = t ? new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';
    const src = (entry.source || entry.phase || '').replace('decision:', '');
    const div = document.createElement('div');
    div.className = `le ${lvl}`;
    div.innerHTML = `<span class="lt">${time}</span><span class="ls">${esc(src)}</span><span class="lm">${esc(entry.message || entry.verdict || entry.type || '')}</span>`;
    box.insertBefore(div, box.firstChild);
    while (box.children.length > 80) box.removeChild(box.lastChild);
  }

  // ---------- State / header / stats ----------
  function renderState(s) {
    if (!s || s.ok === false) return; // ignore degraded error responses from send()
    isPaused = s.isPaused ?? true;
    mode = s.mode || s.settings?.mode || 'supervised';

    // Auto-refresh the queue whenever we (re)enter idle — picks up newly-arrived
    // tickets and refreshes after a solve completes, without a manual LOAD.
    const newState = s.state || 'idle';
    if (newState === 'idle' && prevState !== 'idle' && !queueBusy) loadQueue();
    prevState = newState;

    const badge = $('modeBadge');
    badge.textContent = MODE_LABEL[mode] || 'SUP';
    badge.className = 'mode-badge ' + mode;
    document.querySelectorAll('.mode-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));

    const dot = $('statusDot');
    const startBtn = $('startBtn');
    const stopScrapeBtn = $('stopScrapeBtn');
    if (isPaused) {
      dot.className = 'dot paused';
      startBtn.textContent = 'START'; startBtn.className = 'btn-start';
      if (stopScrapeBtn) stopScrapeBtn.style.display = 'none';
    } else {
      dot.className = 'dot ' + (s.state && s.state !== 'idle' ? 'running' : 'connected');
      startBtn.textContent = 'PAUSE'; startBtn.className = 'btn-pause';
      // Show Stop Scraping only while actively extracting data
      if (stopScrapeBtn) stopScrapeBtn.style.display = (s.state === 'extraction') ? 'inline-flex' : 'none';
    }

    const stateVal = s.state || 'idle';
    const stateEl = $('stateLabel');
    if (stateEl) {
      stateEl.textContent = stateVal.toUpperCase();
      stateEl.parentElement.className = 'state-banner' + (stateVal !== 'idle' ? ' active' : '');
    }

    const st = s.stats || {};
    const total = st.processed || 0;
    const fCount = st.fraud || 0;
    const nfCount = st.notFraud || 0;
    const eCount = st.errors || 0;

    const fPct = total > 0 ? ((fCount / total) * 100).toFixed(0) : '0';
    const nfPct = total > 0 ? ((nfCount / total) * 100).toFixed(0) : '0';
    const ePct = total > 0 ? ((eCount / total) * 100).toFixed(0) : '0';

    $('sDone').textContent = total;
    $('sFraud').innerHTML = `${fCount}<span style="font-size: 10px; opacity: 0.6; font-weight: normal; margin-left: 2px;">(${fPct}%)</span>`;
    $('sClean').innerHTML = `${nfCount}<span style="font-size: 10px; opacity: 0.6; font-weight: normal; margin-left: 2px;">(${nfPct}%)</span>`;
    $('sErr').innerHTML = `${eCount}<span style="font-size: 10px; opacity: 0.6; font-weight: normal; margin-left: 2px;">(${ePct}%)</span>`;

    lastPending = s.pendingConfirmation || null;
    renderDecision();
  }

  // ---------- Pending decision detail ----------
  function renderDecision() {
    const card = $('decisionCard');
    const pc = lastPending;
    if (!pc || !pc.verdict) { card.style.display = 'none'; card.innerHTML = ''; return; }
    card.style.display = '';
    card.className = 'decision';

    const who = pc.customerName
      ? `${esc(pc.customerName)}${pc.mainUserId ? ' (user ' + esc(pc.mainUserId) + ')' : ''}`
      : (pc.mainUserId ? 'user ' + esc(pc.mainUserId) : '—');

    const reasons = (pc.reasons || []).map(r => `<li>${esc(r)}</li>`).join('');
    const checks = (pc.checks || []).map(c => {
      const icon = c.hit ? '✕' : (c.needsReview ? '?' : '✓');
      const cls = c.hit ? 'hit' : (c.needsReview ? 'review' : '');
      return `<div class="chk ${cls}"><span class="ci">${icon}</span>
        <div><div class="cn">${c.n}. ${esc(c.name)}</div><div class="cr">${esc(c.reason || '')}</div></div></div>`;
    }).join('');

    const ca = pc.extracted?.connectedAccounts;
    const accts = Array.isArray(ca) && ca.length
      ? `<div class="sec-head" style="margin-top:7px"><span>Linked accounts</span></div><div class="accts">` +
        ca.map(a => {
          const tag = `user ${esc(a.userId)} via device ${esc(a.viaDeviceId)}`;
          return `<div class="acct ${a.anyHit ? 'hit' : ''}">${a.anyHit ? '✕ ' : '✓ '}${tag}${a.anyHit && a.hits?.length ? ' — ' + esc(a.hits.join(', ')) : ''}</div>`;
        }).join('') + `</div>`
      : '';

    const ex = pc.extracted || {};
    card.innerHTML = `
      <div class="d-head"><span class="d-label">Awaiting Confirmation</span>${pc.orderId ? '<span class="d-order">#' + esc(pc.orderId) + '</span>' : ''}</div>
      <div class="verdict ${pc.verdict}">${pc.verdict === 'FRAUD' ? '⚠ FRAUD' : '✓ NOT FRAUD'}
        <span class="vmeta">${esc(pc.source || '')}${pc.confidence ? ' · ' + esc(pc.confidence) : ''}</span></div>
      ${reasons ? `<ul class="reasons">${reasons}</ul>` : ''}
      <div class="kv"><span class="k">Customer</span><span class="v">${who}</span></div>
      <div class="kv"><span class="k">Adjusted rate</span><span class="v">${pc.ratePercent != null ? pc.ratePercent + '%' : '—'}</span></div>
      <div class="kv"><span class="k">Orders (total/failed)</span><span class="v">${ex.totalOrders ?? '?'} / ${ex.failedOrders ?? '?'}</span></div>
      <div class="kv"><span class="k">Compensations</span><span class="v">${ex.compRows ?? '?'}</span></div>
      <div class="kv"><span class="k">Complaint</span><span class="v">${esc(ex.complaintType || '—')}</span></div>
      <div class="kv"><span class="k">Risk</span><span class="v">${esc(ex.risk || '—')}${ex.preExisting ? ' · pre-existing' : ''}</span></div>
      ${checks ? `<div class="checks">${checks}</div>` : ''}
      ${accts}
      <div class="d-actions">
        ${pc.verdict === 'FRAUD'
          ? `<button class="btn-exec" id="execBtn">Apologize</button><button class="btn-flip" id="flipBtn">NOT FRAUD</button>`
          : `<button class="btn-exec" id="execBtn">Confirm NOT FRAUD</button><button class="btn-flip" id="flipBtn">FRAUD</button>`}
      </div>`;

    $('execBtn').addEventListener('click', () =>
      send({ type: 'CONFIRM_EXECUTION' }, () => send({ type: 'GET_STATE' }, renderState)));
    $('flipBtn').addEventListener('click', () => {
      const flipped = pc.verdict === 'FRAUD'
        ? { verdict: 'NOT_FRAUD', reasons: ['Manual override from cockpit'], reasoning: 'Manual override from cockpit' }
        : { verdict: 'FRAUD', reasons: ['Manual override from cockpit'], reasoning: 'Manual override from cockpit' };
      send({ type: 'CONFIRM_EXECUTION', payload: { override: flipped } }, () => send({ type: 'GET_STATE' }, renderState));
    });
  }

  // ---------- Queue ----------
  function loadQueue() {
    if (queueBusy) return;
    send({ type: 'LIST_TICKETS' }, renderQueue);
  }

  function renderQueue(resp) {
    if (queueBusy) return;
    const list = $('queueList');
    const tickets = resp?.tickets || [];
    if (!tickets.length) {
      list.innerHTML = `<div class="q-empty">${esc(resp?.error || 'No tickets in queue')}</div>`;
      return;
    }
    list.innerHTML = '';
    tickets.forEach(t => {
      const row = document.createElement('div');
      row.className = 'q-item' + (t.isActive ? ' active' : '') + (t.isManual ? ' manual' : '');
      row.dataset.id = t.id || '';
      const label = (t.label || t.id || '(unnamed ticket)');
      row.title = label;
      row.textContent = (t.isActive ? '● ' : '') + label;
      row.addEventListener('click', () => {
        if (queueBusy || row.classList.contains('solving')) return;
        queueBusy = true;
        list.querySelectorAll('.q-item').forEach(el => el.style.pointerEvents = 'none');
        row.classList.add('solving');
        row.textContent = '⟳ ' + label;
        send({ type: 'SOLVE_TICKET', payload: { ticketId: t.id } }, (r) => {
          queueBusy = false;
          if (r && r.ok) { row.classList.remove('solving'); row.classList.add('done'); row.textContent = '▶ ' + label; }
          else { row.classList.remove('solving'); row.classList.add('fail'); row.textContent = '✕ ' + ((r && r.error) || 'failed') + ' — ' + label; }
          list.querySelectorAll('.q-item').forEach(el => el.style.pointerEvents = '');
          send({ type: 'GET_STATE' }, renderState);
        });
      });
      list.appendChild(row);
    });
  }

  // ---------- Decision log (full trail) ----------
  function renderLog(resp) {
    const items = (resp?.log || []).slice(0, 80);
    const box = $('log');
    if (!items.length) { box.innerHTML = '<div class="q-empty">No activity yet</div>'; return; }
    box.innerHTML = items.map(e => {
      const lvl = e.level || (e.type === 'error' ? 'error' : e.type === 'warning' ? 'warn' : 'info');
      const t = e.ts || e.timestamp;
      const time = t ? new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';
      const src = (e.source || e.phase || '').replace('decision:', '');
      return `<div class="le ${lvl}"><span class="lt">${time}</span><span class="ls">${esc(src)}</span><span class="lm">${esc(e.message || e.verdict || e.type || '')}</span></div>`;
    }).join('');
  }

  // ---------- Verify flow ----------
  function runVerify() {
    $('verifyOut').textContent = 'Verifying selectors against open tabs…';
    send({ type: 'VERIFY_FLOW' }, (r) => {
      if (!r || !r.summary) { $('verifyOut').textContent = 'Verify failed (no response)'; return; }
      $('verifyOut').innerHTML = r.summary.map(s => {
        if (s.error) return `<div>· ${esc(s.surface)}: ${esc(s.error)}</div>`;
        const ok = s.resolved === s.total;
        const color = ok ? '#4af626' : '#f5a623';
        const miss = (s.missing && s.missing.length) ? ' — missing: ' + esc(s.missing.join(', ')) : '';
        return `<div style="color:${color}">· ${esc(s.surface)}: ${s.resolved}/${s.total}${miss}</div>`;
      }).join('');
    });
  }

  // ---------- Diagnostics ----------
  function showDiag(result) {
    const out = $('diagOutput');
    if (!result) { out.textContent = 'No result'; return; }
    if (result.error) { out.textContent = `ERR: ${result.error}`; return; }
    let text = '';
    if (result.tabs) for (const tab of result.tabs) {
      text += `[${(tab.system || '').toUpperCase()}] ${tab.contentScript === 'connected' ? 'OK' : 'MISSING'}`;
      if (tab.ticketsFound !== undefined) text += ` | tickets:${tab.ticketsFound}`;
      if (tab.vpnActive !== undefined) text += ` | VPN:${tab.vpnActive ? 'ON' : 'OFF'}`;
      text += '\n';
    }
    if (result.ok !== undefined) {
      text += `TEST: ${result.ok ? 'PASS' : 'FAIL'} | ${result.system || ''}`;
      if (result.ticketsInQueue !== undefined) text += ` | queue:${result.ticketsInQueue}`;
      if (result.intake?.orderId) text += ` | order:${result.intake.orderId}`;
      text += '\n';
    }
    if (result.warning) text += `WARN: ${result.warning}\n`;
    out.textContent = text || 'Done';
  }

  // ---------- Dashboard ----------
  // The full dashboard is now an extension page. Focus an existing tab if one
  // is open, otherwise open a new one.
  function openDashboard() {
    const dashboardUrl = chrome.runtime.getURL('dashboard/index.html');
    try {
      chrome.tabs.query({ url: dashboardUrl + '*' }, (tabs) => {
        if (chrome.runtime.lastError) { chrome.tabs.create({ url: dashboardUrl }); return; }
        if (tabs && tabs.length) chrome.tabs.update(tabs[0].id, { active: true });
        else chrome.tabs.create({ url: dashboardUrl });
      });
    } catch (_) { chrome.tabs.create({ url: dashboardUrl }); }
  }

  // ---------- Manual investigation ----------
function investigate() {
  const input = $('caseInput'), hint = $('caseHint');
  const val = (input.value || '').trim();
  if (!val) { hint.style.color = '#f5a623'; hint.textContent = 'Paste a HeroCare case URL/UUID, an OP order URL, or a raw order id first.'; return; }
  hint.style.color = '#6b7080'; hint.textContent = 'Opening case/order…';
  send({ type: 'INVESTIGATE_CASE', payload: { input: val } }, (r) => {
    if (r && r.ok) { hint.style.color = '#4af626'; hint.textContent = 'Investigating ' + (r.caseId || r.orderId || 'case') + ' — watch the log.'; input.value = ''; }
    else { hint.style.color = '#e61919'; hint.textContent = (r && r.error) || 'Failed to start.'; }
    send({ type: 'GET_STATE' }, renderState);
  });
}

  // ---------- Wire up ----------
  document.querySelectorAll('.mode-btn').forEach(b =>
    b.addEventListener('click', () => {
      const newMode = b.dataset.mode;
      // Optimistic UI update so the selector reflects the click immediately;
      // the background also broadcasts a STATE_UPDATE that confirms it.
      mode = newMode;
      const badge = $('modeBadge');
      if (badge) { badge.textContent = MODE_LABEL[newMode] || 'SUP'; badge.className = 'mode-badge ' + newMode; }
      document.querySelectorAll('.mode-btn').forEach(x => x.classList.toggle('active', x.dataset.mode === newMode));
      send({ type: 'SET_MODE', payload: newMode });
    }));

  $('startBtn').addEventListener('click', () => {
    if (isPaused) send({ type: 'SET_PAUSE', payload: false }, () => send({ type: 'START_PROCESSING' }));
    else send({ type: 'SET_PAUSE', payload: true });
  });
  const stopScrapeBtn = $('stopScrapeBtn');
  if (stopScrapeBtn) stopScrapeBtn.addEventListener('click', () => send({ type: 'STOP_SCRAPING' }));
  $('skipBtn').addEventListener('click', () => send({ type: 'SKIP_TICKET' }));
  $('dashBtn').addEventListener('click', openDashboard);
  $('reloadQueue').addEventListener('click', loadQueue);
  $('clearLog').addEventListener('click', () => {
    send({ type: 'CLEAR_LOG' });
    $('log').innerHTML = '<div class="q-empty">Cleared (live log resumes on next event)</div>';
  });
  $('investigateBtn').addEventListener('click', investigate);
  $('caseInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') investigate(); });

  // Initial load via persistent port (push-driven updates)
  connectPort();
})();
