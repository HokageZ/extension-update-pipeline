/**
 * HeroCare Content Script — runs ONLY in the HeroCare parent page
 * Handles: ticket queue monitoring, intake parsing, chat responses,
 * pre-existing ticket detection.
 *
 * 1VU iframe interaction is handled by onevu.js (separate content script).
 *
 * DOM selectors verified against live HeroCare (2026-06-18).
 * See extension/config/selectors.json for the full selector map with
 * confirmation annotations and fallback chains.
 */

(function() {
  'use strict';

  let selectors = {};
  const context = 'herocare_parent';

  async function loadSelectors() {
    const response = await fetch(chrome.runtime.getURL('config/selectors.json'));
    const all = await response.json();
    selectors = all.herocare;
  }

  function registerFrame() {
    chrome.runtime.sendMessage({
      type: 'REGISTER_FRAME',
      payload: { context, frameId: -1, url: window.location.href }
    }).catch(() => {});
  }

  // Delegates to SelectorHelper.waitForAny for fallback-aware waiting.
  // Accepts a single selector string or an array of fallback candidates.
  function waitForElement(selectors, timeout = 10000) {
    if (window.SelectorHelper) return window.SelectorHelper.waitForAny(
      typeof selectors === 'string' ? [selectors] : selectors, timeout
    );
    // Inline fallback if SelectorHelper hasn't loaded yet
    const arr = typeof selectors === 'string' ? [selectors] : selectors;
    return new Promise((resolve, reject) => {
      for (const sel of arr) { try { const el = document.querySelector(sel); if (el) return resolve(el); } catch (_) {} }
      const observer = new MutationObserver(() => {
        for (const sel of arr) { try { const el = document.querySelector(sel); if (el) { observer.disconnect(); return resolve(el); } } catch (_) {} }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { observer.disconnect(); reject(new Error(`Timeout: ${arr.join(' | ')}`)); }, timeout);
    });
  }

  function randomDelay(min = 800, max = 2500) {
    return new Promise(r => setTimeout(r, min + Math.random() * (max - min)));
  }

  // ===== QUEUE OPERATIONS =====

  function getTicketListContainer() {
    // HeroCare uses JSS-hashed class names that change on every deploy.
    // Confirmed live 2026-06-18: ticketPanelContainer class does NOT exist.
    // Rely on data-testid and ant-list fallbacks.
    return document.querySelector(selectors.queue?.container || '[data-testid*="ticket-list"]') ||
           document.querySelector('[data-testid*="ticket-list"]') ||
           document.querySelector('[class*="ticketList"]') ||
           document.querySelector('ul.ant-list-items') ||
           null;
  }

  // Find ticket <li> elements using progressively looser strategies so a single
  // changed class/testid can't zero out detection. Returns a NodeList/array.
  function findTicketItems() {
    const sel = selectors.queue || {};
    const container = getTicketListContainer();

    // Only look inside the actual queue container. Do NOT fall back to
    // document-wide list items, because case-detail pages contain antd list
    // items / dropdowns (e.g. ticket-status-switch) that are not queue tickets.
    if (!container) return [];

    const list = container.querySelector(sel.list || '.ant-list-items') ||
                 container.querySelector('ul.ant-list-items') ||
                 container;
    let items = list.querySelectorAll(sel.ticketItem || '.ant-list-item[data-testid^="ticket-"]');
    if (items.length === 0) items = list.querySelectorAll('[data-testid^="ticket-"]');
    if (items.length === 0) items = list.querySelectorAll('li.ant-list-item');

    return Array.from(items).filter(el => isRealTicketRow(el));
  }

  function isRealTicketRow(el) {
    const testid = (el.getAttribute('data-testid') || '').trim().toLowerCase();
    // Real queue rows have data-testid="ticket-...".
    // Reject UI controls like ticket-status-switch, dropdown menus, etc.
    if (testid) {
      const isTicket = testid.startsWith('ticket-');
      const isUiControl = /(status|switch|menu|dropdown|popover|tooltip|action)/.test(testid);
      return isTicket && !isUiControl;
    }

    // Fallback: if no data-testid, require the row to be a direct list item
    // inside the queue container and contain at least some text.
    const text = (el.textContent || '').trim();
    return text.length >= 5 && el.tagName === 'LI';
  }

  function getQueueTickets() {
    const items = findTicketItems();

    return Array.from(items).map(item => {
      // NOTE: HeroCare ticket rows carry a normal styling class like
      // `container-d0-0-1-67` on EVERY row — it is NOT an active marker.
      // Only aria-selected / data-active reliably indicate the open ticket.
      const isActive = item.getAttribute('aria-selected') === 'true' ||
                       item.getAttribute('data-active') === 'true';

      return {
        element: item,
        text: item.textContent.trim(),
        isActive
      };
    });
  }

  // The queue loads asynchronously behind an ant-spin loader, so a single
  // synchronous read right after navigation can see zero tickets. Poll briefly.
  async function waitForTickets(timeout = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const tickets = getQueueTickets();
      if (tickets.length > 0) return tickets;
      await new Promise(r => setTimeout(r, 300));
    }
    return getQueueTickets();
  }

  // Wait for the intake message panel to render and contain a parseable order.
  async function waitForIntake(timeout = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const parsed = parseIntakeMessage();
      if (parsed && parsed.orderId) return parsed;
      await new Promise(r => setTimeout(r, 300));
    }
    return parseIntakeMessage();
  }

  function detectNewTicket() {
    const tickets = getQueueTickets();
    if (tickets.length === 0) return null;
    // Return first non-active ticket, or first ticket
    const unselected = tickets.find(t => !t.isActive);
    return (unselected || tickets[0]).element;
  }

  function getActiveTicket() {
    const tickets = getQueueTickets();
    const active = tickets.find(t => t.isActive);
    return active ? active.element : null;
  }

  // Serializable queue snapshot for the popup ticket selector.
  function listQueueTickets() {
    const tickets = getQueueTickets();
    if (tickets.length === 0) {
      // When no real queue exists (e.g. direct case URL), expose a single
      // manual-investigation marker so the UI can show case info instead.
      const caseIdMatch = String(window.location.pathname).match(/\/cases\/([0-9a-f-]+)/i);
      const caseId = caseIdMatch ? caseIdMatch[1] : null;
      return [{
        id: 'MANUAL_INVESTIGATION',
        index: 0,
        label: caseId
          ? `Manual investigation — case ${caseId}`
          : 'Manual investigation — single case',
        isActive: true,
        isManual: true,
        caseId,
        url: window.location.href
      }];
    }

    return tickets.map((t, i) => ({
      id: t.element.getAttribute('data-testid') || null,
      index: i,
      label: (t.text || '').replace(/\s+/g, ' ').trim().slice(0, 90),
      isActive: t.isActive
    }));
  }

  // ===== INTAKE PARSING =====

  function getMessagePanel() {
    // Confirmed live 2026-06-18: [data-testid='message-panel-main-container'] and
    // [data-testid='has-messages-container'] both resolve. [class*='messagePanelContainer']
    // does NOT exist on live DOM.
    return document.querySelector(selectors.queue?.intakeMessage || '[data-testid="message-panel-main-container"]') ||
           document.querySelector('[data-testid="message-panel-main-container"]') ||
           document.querySelector('[data-testid="has-messages-container"]') ||
           document.querySelector('[class*="messagePanel"]');
  }

  // Returns the text that should contain the intake fields. Prefer the single
  // message body that contains the automation payload because full panel
  // textContent glues separate chat messages together (email + timestamp,
  // refund_items + later customer messages), which breaks field parsing.
  function getIntakeText(panel) {
    const bodyBlocks = document.querySelectorAll('[data-testid="panel-body-content"], [data-testid^="message-content-"]');
    for (const block of bodyBlocks) {
      const text = block.textContent || '';
      if (/HS_SA-\d+/.test(text) || /Escalate from HeroCare|Additional Info:/i.test(text)) {
        return text;
      }
    }

    const text = panel?.textContent || '';
    if (/HS_SA-\d+|Escalate from HeroCare|Additional Info:/i.test(text)) return text;

    const joined = Array.from(bodyBlocks).map(b => b.textContent).join('\n');
    return joined || text;
  }

  function parseIntakeMessage() {
    const intakeEl = getMessagePanel();
    if (!intakeEl) return null;

    const allText = getIntakeText(intakeEl);
    if (!allText || allText.trim().length < 10) return null;
    const panelText = intakeEl.textContent || '';

    // TLD is letter-only to avoid swallowing adjacent timestamp digits from
    // HeroCare's glued textContent (e.g. "user@icloud.com07:24").
    const emailMatch = allText.match(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,24}/) ||
                       panelText.match(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,24}/);
    const transactionMatch = allText.match(/HS_SA-(\d+)-\d+/);
    const orderId = transactionMatch ? transactionMatch[1] : null;

    const amountPaidMatch = allText.match(/(?:amount_paid_by_customer|paid by customer|المبلغ المدفوع)[:\s]*([\d.]+)/i);
    const amountVoucherMatch = allText.match(/(?:amount_paid_by_voucher|paid by voucher|قسيمة)[:\s]*([\d.]+)/i);
    const totalAmountMatch = allText.match(/(?:total_order_amount|total order amount)[:\s]*([\d.]+)/i);

    // Find photos — first extract from image_url field in plain text (the primary
    // source confirmed live 2026-06-18), then fall back to <a>/<img> elements.
    const imageUrlMatch = allText.match(/image_url:\s*(https?:\/\/\S+)/i);
    const photoLinks = intakeEl.querySelectorAll('a[href*="image"], a[href*="photo"], a[href*="upload"], a[href*="files-api"], a[href*="usehurrier"], img[src*="http"]');
    const customerPhotos = imageUrlMatch ? [imageUrlMatch[1]] : [];
    // Append any additional photos from DOM elements (deduped)
    for (const el of photoLinks) {
      const url = el.href || el.src;
      if (url && !customerPhotos.includes(url)) customerPhotos.push(url);
    }

    // Extract refund items: "refund_items: 116923011: Iced Café Americano x 1"
    const refundMatch = allText.match(/refund[_\s]?items?[:\s]*(.*?)(?:\n|$)/i);
    const refundedItems = refundMatch ? [refundMatch[1].trim()] : extractRefundedItems(intakeEl);

    // Extract contact reason from the subject line if present.
    // Live format (2026-06-18):
    //   subject: R - OD - DELIVERED - Wrong / Missing item :: Missing item (Automation fallback)
    // Strategy: capture everything after "subject:", strip the R/OD/STATUS prefix
    // and the ":: ... (Automation fallback)" suffix to get the complaint type.
    const subjectRaw = allText.match(/subject:\s*(.+?)(?:\n|transaction_id)/i);
    let contactReason = null;
    if (subjectRaw) {
      let subj = subjectRaw[1].trim();
      // Strip "R - OD - STATUS - " prefix (e.g. "R - OD - DELIVERED - ")
      subj = subj.replace(/^[A-Z]\s*-\s*OD\s*-\s*\w+\s*-\s*/i, '');
      // If there's a "::" separator, take the part after it (more specific)
      if (subj.includes('::')) {
        subj = subj.split('::').pop().trim();
      }
      // Strip "(Automation fallback)" suffix
      subj = subj.replace(/\s*\(Automation\s+fallback\)\s*$/i, '').trim();
      if (subj) contactReason = subj;
    }

    // Escalated tickets are NOT structured: instead of an HS_SA intake message
    // they carry a system "Escalate from HeroCare" line with an "Additional Info"
    // tag list (e.g. "صنف ناقص // متلاعب // تصعيد") and the originating ticket id.
    // There is no HS_SA/order id in the thread — that comes from the 1VU iframe.
    const escalated = /Escalate from HeroCare|تصعيد/i.test(allText);
    const addInfoMatch = allText.match(/Additional Info:\s*([^]*?)(?:Customer|Agent|$)/i);
    const escalationTags = addInfoMatch
      ? addInfoMatch[1].split(/\/\/|\||،|,/).map(s => s.trim()).filter(s => s && s.length < 40)
      : [];
    const origTicketMatch = allText.match(/TicketID:\s*([0-9a-fA-F-]{8,})/);
    // "متلاعب" (manipulator) — the escalating agent's fraud suspicion. INFORMATIONAL
    // ONLY: surfaced in the log/cockpit; the verdict stays data-driven (rate+checklist).
    const agentSuspectsFraud = escalationTags.some(t => /متلاعب|manipulat|fraud|تلاعب/i.test(t));

    if (!contactReason && escalationTags.length) {
      contactReason = escalationTags.find(t => !/متلاعب|تصعيد|manipulat|escalat|fraud/i.test(t)) || null;
    }

    return {
      customerEmail: emailMatch ? emailMatch[0] : null,
      transactionId: transactionMatch ? transactionMatch[0] : null,
      orderId: orderId,
      amountPaid: amountPaidMatch ? parseFloat(amountPaidMatch[1]) : null,
      amountVoucher: amountVoucherMatch ? parseFloat(amountVoucherMatch[1]) : null,
      totalOrderAmount: totalAmountMatch ? parseFloat(totalAmountMatch[1]) : null,
      refundedItems: refundedItems,
      customerPhotos: customerPhotos,
      contactReason: contactReason,
      escalated: escalated,
      escalationTags: escalationTags,
      agentSuspectsFraud: agentSuspectsFraud,
      originalTicketId: origTicketMatch ? origTicketMatch[1] : null
    };
  }

  function extractRefundedItems(container) {
    const items = [];
    const listItems = container.querySelectorAll('li, [class*="item"]');
    listItems.forEach(li => {
      const text = li.textContent.trim();
      if (text && text.length > 2 && text.length < 200) {
        items.push(text);
      }
    });
    return items;
  }

  // ===== PRE-EXISTING TICKET DETECTION =====

  function isPreExistingTicket() {
    const escalationBadge = document.querySelector(
      '[class*="escalat"], [data-testid*="escalat"], [class*="reopened"], [class*="re-open"]'
    );
    if (escalationBadge) return true;

    const ticketSubject = document.querySelector('[class*="ticketSubject"], [class*="ticket-title"], h1[class*="subject"]');
    if (ticketSubject) {
      const text = ticketSubject.textContent.toLowerCase();
      if (text.includes('re-open') || text.includes('reopen') || text.includes('follow up') ||
          text.includes('متابعة') || text.includes('إعادة')) {
        return true;
      }
    }

    // Escalated tickets carry a system "Escalate from HeroCare" line and/or a
    // "تصعيد" tag — these are pre-existing by definition, so they should get the
    // R3 response ("already escalated, track via My Tickets"), not R1.
    const messagePanel = getMessagePanel();
    if (messagePanel) {
      const text = messagePanel.textContent;
      if (text.includes('Back Office') || text.includes('باك أوفيس') ||
          text.includes('تم تصعيد') || text.includes('escalated previously') ||
          text.includes('Escalate from HeroCare') || text.includes('تصعيد')) {
        return true;
      }
    }

    return false;
  }

  // ===== WRITE OPERATIONS =====

  async function pickUpTicket(ticketId) {
    if (ticketId === 'MANUAL_INVESTIGATION') return true;
    let ticketEl = null;
    if (ticketId) {
      ticketEl = document.querySelector(`li.ant-list-item[data-testid='${ticketId}']`) ||
                 document.querySelector(`[data-testid='${ticketId}']`);
    }
    if (!ticketEl) ticketEl = detectNewTicket();
    if (ticketEl) {
      ticketEl.click();
      await randomDelay(500, 1000);
      return true;
    }
    return false;
  }

  async function sendChatMessage(text, retries = 2) {
    const messagePanel = getMessagePanel();
    if (!messagePanel) return false;

    // Confirmed live 2026-06-18: [data-testid='compose-message-input'] resolves,
    // also textarea with placeholder "Type your message here".
    const input = document.querySelector(selectors.queue?.chatInput || '[data-testid="compose-message-input"]') ||
                  messagePanel.querySelector('textarea') ||
                  messagePanel.querySelector('[contenteditable="true"]') ||
                  messagePanel.querySelector('input[type="text"]');
    if (!input) return false;

    for (let attempt = 0; attempt <= retries; attempt++) {
      input.focus();
      await randomDelay(200, 400);

      if (input.tagName === 'TEXTAREA' || input.tagName === 'INPUT') {
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
          window.HTMLTextAreaElement.prototype, 'value'
        )?.set || Object.getOwnPropertyDescriptor(
          window.HTMLInputElement.prototype, 'value'
        )?.set;
        if (nativeInputValueSetter) {
          nativeInputValueSetter.call(input, text);
        } else {
          input.value = text;
        }
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      } else {
        input.textContent = text;
        input.dispatchEvent(new InputEvent('input', { bubbles: true, data: text }));
      }

      await randomDelay(300, 600);

      // Confirmed live 2026-06-18: [data-testid='send-btn'] resolves.
      const sendBtn = document.querySelector(selectors.queue?.sendButton || '[data-testid="send-btn"]') ||
                      messagePanel.querySelector('button[type="submit"]') ||
                      messagePanel.querySelector('button:last-of-type');
      if (!sendBtn) return false;

      const bubbleSelector = '[data-testid^="message-content-"], [class*="message"], [class*="bubble"]';
      const msgCountBefore = messagePanel.querySelectorAll(bubbleSelector).length;
      sendBtn.click();

      // Wait and check if a new message appeared in the panel (send confirmation)
      await randomDelay(800, 1500);
      const msgCountAfter = messagePanel.querySelectorAll(bubbleSelector).length;
      if (msgCountAfter > msgCountBefore) return true;

      // Message count didn't change — retry
      if (attempt < retries) {
        console.warn(`[FraudDetection] sendChatMessage attempt ${attempt + 1} unconfirmed, retrying...`);
        await randomDelay(1000, 2000);
      }
    }

    console.error('[FraudDetection] sendChatMessage: could not confirm send after retries');
    return false;
  }

  // ===== SELECTOR SELF-TEST (read-only) =====

  const PROBE_SPEC = {
    queue_container: ["[data-testid*='ticket-list']", "[class*='ticketList']", "ul.ant-list-items"],
    queue_items: ["li.ant-list-item[data-testid^='ticket-']", "[data-testid^='ticket-']", "li.ant-list-item"],
    queue_active: ["li.ant-list-item[aria-selected='true']", "li.ant-list-item[data-active='true']"],
    intake_panel: ["[data-testid='message-panel-main-container']", "[data-testid='has-messages-container']"],
    intake_messages: ["[data-testid^='message-content-']"],
    chat_input: ["[data-testid='compose-message-input']", "textarea[placeholder*='message']", "textarea", "[contenteditable='true']"],
    send_button: ["[data-testid='send-btn']", "button[type='submit']", ".ant-btn-primary"]
  };

  function probeSelectors() {
    const results = {};
    for (const [key, candidates] of Object.entries(PROBE_SPEC)) {
      let resolved = null, count = 0, sampleText = '';
      for (const sel of candidates) {
        let els = [];
        try { els = document.querySelectorAll(sel); } catch (_) { continue; }
        if (els.length > 0) {
          resolved = sel;
          count = els.length;
          sampleText = (els[0].textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80);
          break;
        }
      }
      results[key] = { resolved: !!resolved, selector: resolved, count, sampleText };
    }
    return { context, url: window.location.href, results };
  }

  // ===== MESSAGE HANDLING =====

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case 'REGISTER_FRAME':
        sendResponse({ context, url: window.location.href, ok: true });
        break;

      case 'PROBE_SELECTORS':
        sendResponse(probeSelectors());
        break;

      case 'DETECT_TICKET':
        waitForTickets().then(tickets => {
          sendResponse({
            found: tickets.length > 0,
            count: tickets.length,
            hasActiveTicket: !!getActiveTicket(),
            ticketListFound: !!getTicketListContainer(),
            messagePanelFound: !!getMessagePanel()
          });
        });
        return true;

      case 'PARSE_INTAKE':
        waitForIntake().then(intake => {
          sendResponse({
            data: intake,
            debug: {
              messagePanelFound: !!getMessagePanel(),
              hasContent: !!(getMessagePanel()?.textContent?.trim())
            }
          });
        });
        return true;

      case 'GET_PRE_EXISTING':
        sendResponse({ isPreExisting: isPreExistingTicket() });
        break;

      case 'LIST_TICKETS':
        waitForTickets().then(() => sendResponse({ tickets: listQueueTickets() }));
        return true;

      case 'PICK_UP_TICKET':
        pickUpTicket(message.payload?.ticketId).then(ok => sendResponse({ ok }));
        return true;

      case 'SEND_RESPONSE':
        sendChatMessage(message.payload.text).then(ok => sendResponse({ ok }));
        return true;

      case 'KEEPALIVE_PING':
        sendResponse({ alive: true, context, url: window.location.href });
        break;
    }
    return true;
  });

  loadSelectors().then(() => {
    const ticketContainer = getTicketListContainer();
    const tickets = ticketContainer ? ticketContainer.querySelectorAll('li.ant-list-item') : [];
    const msgPanel = getMessagePanel();
    console.log('[FraudDetection] HeroCare content script loaded', {
      context,
      ticketListFound: !!ticketContainer,
      ticketCount: tickets.length,
      messagePanelFound: !!msgPanel,
      url: window.location.href
    });
    registerFrame();
  });
})();
