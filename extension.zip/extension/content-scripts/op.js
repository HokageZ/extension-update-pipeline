/**
 * Operation Portal Content Script
 * Handles: order page, About User tab, Compensation tab, notes
 * Also handles: compensation history page (separate URL)
 * URL patterns:
 *   - /operation/en/orders/{id} (order page)
 *   - /operation/en/compensations?by_user={id} (comp history)
 *   - /operation/en/users/{id} (user page - devices)
 *   - /operation/en/devices/{id} (device page - linked accounts)
 * Requires German VPN
 *
 * DOM selectors verified against live OP (2026-06-18).
 * See extension/config/selectors.json for the full selector map with
 * confirmation annotations and fallback chains.
 */

(function() {
  'use strict';

  let selectors = {};

  async function loadSelectors() {
    const response = await fetch(chrome.runtime.getURL('config/selectors.json'));
    const all = await response.json();
    selectors = all.operationPortal;
  }

  function randomDelay(min = 800, max = 2500) {
    return new Promise(r => setTimeout(r, min + Math.random() * (max - min)));
  }

  function getCurrentPageType() {
    const url = window.location.pathname;
    if (url.includes('/compensations')) return 'compensation_history';
    if (url.includes('/orders/')) return 'order';
    if (url.includes('/users/')) return 'user';
    if (url.includes('/devices/')) return 'device';
    return 'unknown';
  }

  // ===== ORDER PAGE: TAB NAVIGATION =====

  async function navigateToTab(tabName) {
    const tabMap = {
      aboutUser: 'a#about_user_tab',
      trackHistory: 'a#track_history_tab',
      compensation: 'a#compensation_tab'
    };

    const selector = tabMap[tabName] || selectors.tabs?.[tabName];
    if (!selector) return false;

    const tab = document.querySelector(selector);
    if (!tab) return false;
    tab.click();
    await randomDelay(800, 1500);
    return true;
  }

  function getActiveTab() {
    const activeTab = document.querySelector('ul.nav.nav-tabs li.active a.tab-title');
    return activeTab ? activeTab.id.replace('_tab', '') : null;
  }

  // ===== ORDER PAGE: ABOUT USER TAB =====

  function getAboutUserData() {
    const container = document.querySelector('div#about_user_tab_content');
    if (!container) return { totalOrders: null, failedOrders: null, userCreatedAt: null };

    const data = {
      name: null,
      totalOrders: null,
      failedOrders: null,
      successfulOrders: null,
      compensationsCount: null,
      userCreatedAt: null
    };

    // PRIMARY (confirmed live 2026-06-13): About User is a <dl> of dt/dd pairs:
    //   <dt>Total Orders</dt><dd>153</dd>, <dt>Failed Orders</dt><dd>34</dd>,
    //   <dt>created at</dt><dd>2017-07-27 ...</dd>, <dt>Compensations</dt><dd>68</dd>
    const dts = container.querySelectorAll('dt');
    for (const dt of dts) {
      const label = dt.textContent.trim().toLowerCase();
      const dd = dt.nextElementSibling;
      if (!dd) continue;
      const value = dd.textContent.trim();
      if (label === 'name' || label === 'الاسم') {
        if (!data.name && value) data.name = value;
      } else if (label === 'total orders' || (label.includes('total') && label.includes('order'))) {
        data.totalOrders = parseInt(value.replace(/[^\d]/g, ''), 10) || data.totalOrders;
      } else if (label === 'failed orders' || label.includes('failed') || label.includes('cancelled')) {
        data.failedOrders = parseInt(value.replace(/[^\d]/g, ''), 10) ?? data.failedOrders;
        if (isNaN(data.failedOrders)) data.failedOrders = null;
      } else if (label === 'successful orders' || label.includes('successful')) {
        data.successfulOrders = parseInt(value.replace(/[^\d]/g, ''), 10) || data.successfulOrders;
      } else if (label === 'compensations' || label.includes('compensation')) {
        data.compensationsCount = parseInt(value.replace(/[^\d]/g, ''), 10);
        if (isNaN(data.compensationsCount)) data.compensationsCount = null;
      } else if (label.includes('created') || label.includes('registered') || label.includes('joined') || label.includes('since')) {
        if (!data.userCreatedAt) data.userCreatedAt = value;
      }
    }

    // FALLBACK 1: table label/value rows (older OP layout)
    if (data.totalOrders == null) {
      const tables = container.querySelectorAll('table');
      for (const table of tables) {
        for (const row of table.querySelectorAll('tr')) {
          const cells = row.querySelectorAll('td, th');
          if (cells.length >= 2) {
            const label = cells[0].textContent.trim().toLowerCase();
            const value = cells[1].textContent.trim();
            if (label.includes('total') && label.includes('order') && data.totalOrders == null) data.totalOrders = parseInt(value, 10) || null;
            else if ((label.includes('failed') || label.includes('cancelled')) && data.failedOrders == null) data.failedOrders = parseInt(value, 10);
            else if (label.includes('successful') && data.successfulOrders == null) data.successfulOrders = parseInt(value, 10) || null;
            else if ((label.includes('created') || label.includes('registered')) && !data.userCreatedAt) data.userCreatedAt = value;
          }
        }
      }
    }

    // FALLBACK 2: free-text regex over stat panels
    if (data.totalOrders == null) {
      const panels = container.querySelectorAll('.panel-body, div[class*="stat"], div[class*="info"]');
      for (const panel of panels) {
        const text = panel.textContent;
        const totalMatch = text.match(/(?:total|all)\s*(?:orders?)?[:\s]*(\d+)/i);
        const failedMatch = text.match(/(?:failed|cancelled)\s*(?:orders?)?[:\s]*(\d+)/i);
        const createdMatch = text.match(/(?:created|registered|member since|joined)[:\s]*([\d\-/.]+[\s,]*[\d:APMapm]*)/i);
        if (totalMatch && data.totalOrders == null) data.totalOrders = parseInt(totalMatch[1], 10);
        if (failedMatch && data.failedOrders == null) data.failedOrders = parseInt(failedMatch[1], 10);
        if (createdMatch && !data.userCreatedAt) data.userCreatedAt = createdMatch[1].trim();
      }
    }

    return data;
  }

  // ===== ORDER PAGE: COMPENSATION TAB =====

  function getCompensationHistoryLink() {
    const compTab = document.querySelector('div#compensation_tab_content');
    if (!compTab) return null;

    const historyLink = compTab.querySelector('a.btn.btn-white') ||
                        compTab.querySelector('a[href*="/compensations"]') ||
                        compTab.querySelector('a[href*="by_user"]');
    return historyLink ? historyLink.href : null;
  }

  function clickCompensationHistoryLink() {
    const compTab = document.querySelector('div#compensation_tab_content');
    if (!compTab) return false;

    const link = compTab.querySelector('a.btn.btn-white') ||
                 compTab.querySelector('a[href*="/compensations"]') ||
                 compTab.querySelector('a[href*="by_user"]');
    if (link) {
      link.click();
      return true;
    }
    return false;
  }

  // ===== ORDER PAGE: NOTES =====

  // Add a comment on the Operation Portal order. Confirmed live 2026-06-19:
  //   form#new_note > input#note_content (name="note[content]",
  //   placeholder "Type a note here...") submitted by input[type=submit].btn-danger,
  //   POSTing to /operation/en/support/notes. This is the primary path.
  async function writeNote(text) {
    const setNativeValue = (el, val) => {
      const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(el, val); else el.value = val;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    };

    // PRIMARY: the confirmed note form.
    const form = document.querySelector('form#new_note') || document.querySelector('form.new_note');
    if (form) {
      const input = form.querySelector('#note_content') || form.querySelector('input#note_content') || form.querySelector('input.form-control') || form.querySelector('[name="note[content]"]');
      if (input) {
        input.focus();
        setNativeValue(input, text);
        await randomDelay(300, 600);
        const submitBtn = form.querySelector('input[type="submit"]') ||
                          form.querySelector('button[type="submit"]') ||
                          form.querySelector('.btn-primary, .btn-danger') ||
                          form.querySelector('button');
        if (submitBtn) { submitBtn.click(); await randomDelay(600, 1200); return true; }
        form.submit();
        return true;
      }
    }

    // FALLBACK: a note/textarea in the Track History tab.
    const trackInput = document.querySelector('div#track_history_tab_content input[placeholder*="note"], div#track_history_tab_content textarea');
    if (trackInput) {
      trackInput.focus();
      setNativeValue(trackInput, text);
      await randomDelay(300, 600);
      const trackRoot = document.querySelector('div#track_history_tab_content') || document;
      const sendBtn = trackInput.parentElement?.querySelector('button[type="submit"]') ||
                      (window.SelectorHelper && window.SelectorHelper.findByText('button', 'SEND', trackRoot)) ||
                      trackRoot.querySelector('button[type="submit"]');
      if (sendBtn) { sendBtn.click(); return true; }
    }

    return false;
  }

  // ===== ORDER PAGE: ORDER HIGHLIGHTS =====

  function getOrderHighlights() {
    const data = {};
    const wrapper = document.querySelector('section.wrapper') || document.querySelector('div.order-details');
    if (!wrapper) return data;

    // Try dl/dt/dd structure first (real OP uses definition lists)
    const dts = wrapper.querySelectorAll('dt');
    for (const dt of dts) {
      const label = dt.textContent.trim().toLowerCase();
      const dd = dt.nextElementSibling;
      if (!dd) continue;
      const value = dd.textContent.trim();

      if (label.includes('id') && !data.orderId) data.orderId = value;
      else if (label.includes('created')) data.createdAt = value;
      else if (label.includes('user') && !label.includes('about')) data.user = value;
      else if (label.includes('location') || label.includes('city')) data.location = value;
      else if (label.includes('restaurant') || label.includes('vendor')) data.restaurant = value;
      else if (label.includes('store type') || label.includes('vertical')) data.storeType = value;
      else if (label.includes('total') && !label.includes('order')) data.total = value;
      else if (label.includes('payment method')) data.paymentMethod = value;
      else if (label.includes('status')) data.status = value;
      else if (label.includes('mobile') || label.includes('phone')) data.mobile = value;
    }

    // Fallback to table/row structure
    if (!data.orderId) {
      const panels = wrapper.querySelectorAll('section.panel');
      for (const panel of panels) {
        const rows = panel.querySelectorAll('tr, .row > div');
        for (const row of rows) {
          const cells = row.querySelectorAll('td');
          if (cells.length >= 2) {
            const label = cells[0].textContent.trim().toLowerCase();
            const value = cells[1].textContent.trim();

            if (label.includes('id') && !data.orderId) data.orderId = value;
            else if (label.includes('created')) data.createdAt = value;
            else if (label.includes('user') && !label.includes('about')) data.user = value;
            else if (label.includes('location') || label.includes('city')) data.location = value;
            else if (label.includes('restaurant') || label.includes('vendor')) data.restaurant = value;
            else if (label.includes('store type') || label.includes('vertical')) data.storeType = value;
            else if (label.includes('total') && !label.includes('order')) data.total = value;
            else if (label.includes('payment')) data.paymentMethod = value;
            else if (label.includes('status')) data.status = value;
            else if (label.includes('mobile') || label.includes('phone')) data.mobile = value;
          }
        }
      }
    }

    return data;
  }

  // ===== ORDER PAGE: LINE ITEMS =====

  // Check #2 (Bulk Drinks) needs the ordered line items with names + quantities.
  // Confirmed live 2026-06-14: under #ordered_items_tab_content the FIRST table is
  // the items table with columns: # | menu group | menu item | count | note |
  // total cost. (The same container also holds sub-item and offer/discount tables
  // — we must scope to the items table and map by header, not blindly read td[0/1].)
  function getOrderItems() {
    const items = [];
    const wrapper = document.querySelector('div#ordered_items_tab_content') ||
                    document.querySelector('section.wrapper, div.order-details, div#order_items_content');
    if (!wrapper) return items;

    const table = wrapper.querySelector('table');
    if (table) {
      const headers = Array.from(table.querySelectorAll('thead th')).map(th => th.textContent.trim().toLowerCase());
      let nameIdx = headers.findIndex(h => h.includes('menu item') || h === 'item' || h.includes('item name'));
      let countIdx = headers.findIndex(h => h === 'count' || h.includes('quantity') || h.includes('qty'));
      // Fall back to the known column order if headers are unexpected.
      if (nameIdx < 0) nameIdx = 2;
      if (countIdx < 0) countIdx = 3;

      table.querySelectorAll('tbody tr').forEach(row => {
        const cells = row.querySelectorAll('td');
        if (!cells.length) return;
        const name = cells[nameIdx] ? cells[nameIdx].textContent.trim() : '';
        const qtyText = cells[countIdx] ? cells[countIdx].textContent.trim() : '1';
        const qty = parseInt(qtyText.replace(/[^\d]/g, ''), 10) || 1;
        // Skip offer/discount rows: their first cell is a long numeric id and they
        // have no readable menu-item name in the name column.
        if (name && name.length > 1 && !/^\d{6,}$/.test(name)) items.push({ name, quantity: qty });
      });
      if (items.length) return items;
    }

    // Fallback: item name spans with quantity badges (older/other layouts)
    const nameEls = wrapper.querySelectorAll('[class*="item-name"], [class*="itemName"], [class*="product-name"]');
    nameEls.forEach(el => {
      const qtyEl = el.closest('[class*="item"]')?.querySelector('[class*="qty"], [class*="quantity"], [class*="count"]');
      const qty = qtyEl ? parseInt(qtyEl.textContent, 10) || 1 : 1;
      items.push({ name: el.textContent.trim(), quantity: qty });
    });
    return items;
  }

  // ===== ORDER PAGE: RIDER DELIVERY PHOTOS =====

  // Check #4 — rider/delivery proof photos. Confirmed live 2026-06-14: real
  // attachment photos are S3-signed URLs on `attachments.hsobjects.com` (served
  // via s3.eu-central-1.amazonaws.com), e.g.
  //   https://s3.eu-central-1.amazonaws.com/attachments.hsobjects.com/final-…?X-Amz-…
  // The page is full of NON-photo images (UI assets on platform.hsobjects.com/
  // assets/*.svg, agent gravatars) — those must be excluded. Search document-wide
  // because the proof can sit in a complaints/notes block, not just track history.
  function getRiderDeliveryPhotos() {
    const photos = new Set();
    const isNoise = (u) => /\/assets\/|platform\.hsobjects\.com|gravatar|\.svg(\?|$)|\/logo|sprite/i.test(u || '');
    const looksLikePhoto = (u) =>
      /attachments\.hsobjects\.com|s3[.-].*amazonaws|usehurrier|files-api|cloudfront|\.(jpe?g|png|webp)(\?|$)/i.test(u || '');

    // <img src> across the document
    document.querySelectorAll('img[src]').forEach(img => {
      const src = img.src;
      if (looksLikePhoto(src) && !isNoise(src)) photos.add(src);
    });
    // <a href> thumbnails linking to the full-size attachment
    document.querySelectorAll('a[href]').forEach(a => {
      const href = a.href;
      if (looksLikePhoto(href) && !isNoise(href)) photos.add(href);
    });

    return Array.from(photos);
  }

  // ===== ORDER PAGE/USER PAGE: BLOCKED STATUS =====

  // Check #5 — account/device blocked status.
  // Confirmed live 2026-06-14 (OP order > About User): the account's CURRENT
  // status renders as a button whose class encodes it:
  //   btn btn-user-status-<status> btn-xs
  // where <status> ∈ verified | pending | blocked | locked | awaiting_approval | deleted.
  // IMPORTANT: do NOT keyword-scan the About User text for "blocked" — the Status
  // field is a <select> whose option text contains ALL states ("…blocked locked…"),
  // which is why the old scan false-fired. Read the active badge instead.
  function getBlockedStatus() {
    const blocked = { blockedDevice: false, blockedAccount: false, status: null, reason: null, agentNotes: [] };

    const badge = document.querySelector("button[class*='btn-user-status-'][class*='btn-xs']:not(.dropdown-toggle)") ||
                  document.querySelector("button[class*='btn-user-status-']:not(.dropdown-toggle)");
    if (badge) {
      const m = (badge.className || '').match(/btn-user-status-([a-z_-]+)/i);
      const fromClass = m ? m[1].toLowerCase().replace(/-/g, '_') : '';
      const fromText = (badge.textContent || '').trim().toLowerCase();
      const status = fromClass || fromText;
      if (status) {
        blocked.status = status;
        // blocked / locked / banned / suspended → restricted account = fraud signal.
        if (/block|lock|ban|suspend/.test(status)) {
          blocked.blockedAccount = true;
          blocked.reason = `Account status: ${status}`;
        }
      }
    }

    // Strong-word fallback (Arabic / banned / suspended) — these words are NOT in
    // the status dropdown options, so they won't false-fire like "blocked" would.
    if (!blocked.blockedAccount) {
      const userSection = document.querySelector('div#about_user_tab_content, div#user_info, div.user-status');
      if (userSection && /(محظور|موقوف|\bbanned\b|\bsuspended\b)/i.test(userSection.textContent)) {
        blocked.blockedAccount = true;
        blocked.reason = 'Blocked/suspended indicator in user section';
      }
    }

    // Collect agent notes from the page (any visible note/comment blocks).
    // We try several common selectors; some pages show notes in a list or table.
    const noteSelectors = [
      '.note-body',
      '.note-text',
      '.comment-body',
      '.activity-note',
      '[class*="note"] p',
      '[class*="comment"] p',
      '.timeline-item .content',
      '.order-notes .note',
      '.user-notes .note'
    ];
    const seen = new Set();
    for (const sel of noteSelectors) {
      document.querySelectorAll(sel).forEach(el => {
        const text = (el.textContent || '').trim();
        if (text && text.length >= 3 && !seen.has(text)) {
          seen.add(text);
          blocked.agentNotes.push(text);
        }
      });
    }

    return blocked;
  }

  // ===== COMPENSATION HISTORY PAGE =====

  function scrapeCompensationTable(root = document) {
    const tableContainer = root.querySelector('section#flip-scroll') ||
                           root.querySelector('div.table-responsive') ||
                           root.querySelector('.shared-table');
    if (!tableContainer) return [];

    const table = tableContainer.tagName === 'TABLE' ? tableContainer : tableContainer.querySelector('table');
    if (!table) return [];

    const headers = [];
    const headerRow = table.querySelector('thead tr');
    if (headerRow) {
      headerRow.querySelectorAll('th').forEach(th => {
        headers.push(th.textContent.trim().toLowerCase().replace(/\s+/g, '_'));
      });
    }

    // Map header names to known columns
    const colIndex = {
      id: headers.indexOf('id'),
      date: headers.indexOf('operationday'),
      orderId: headers.indexOf('order'),
      agent: headers.indexOf('agent'),
      rule: headers.indexOf('rule'),
      amount: headers.indexOf('amount'),
      type: headers.indexOf('category')
    };

    const rows = table.querySelectorAll('tbody tr');
    return Array.from(rows).map(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length < 3) return null;

      const getCell = (key, fallbackIndex) => {
        const idx = colIndex[key];
        if (idx >= 0 && cells[idx]) return cells[idx].textContent.trim();
        if (fallbackIndex >= 0 && cells[fallbackIndex]) return cells[fallbackIndex].textContent.trim();
        return '';
      };

      const ruleValue = getCell('rule', 5);
      return {
        id: getCell('id', 0), // unique compensation id — used to dedupe across pages
        date: getCell('date', 7),
        orderId: getCell('orderId', 2),
        agent: getCell('agent', 4),
        rule: ruleValue,
        reason: ruleValue, // OP table doesn't have separate reason column; use rule as reason
        amount: parseFloat(getCell('amount', 6).replace(/[^\d.]/g, '')) || 0,
        type: getCell('type', 9),
        raw: Array.from(cells).map(c => c.textContent.trim())
      };
    }).filter(Boolean);
  }

  // The comp pager's real "next" control is <a rel="next"> (confirmed live; its
  // href is e.g. ?...&page=2&per_page=100&sort_by=id and DOES preserve per_page).
  // The old code looked for it inside div.footer-container-width / li.next, which
  // didn't match — so page 2 was never reached and a 105-comp user scraped 100.
  function getNextPageUrl() {
    const nextLink = document.querySelector('a[rel="next"]');
    return nextLink ? nextLink.href : null;
  }

  function hasMorePages() {
    return !!document.querySelector('a[rel="next"]');
  }


  // The comp table loads its rows via AJAX after the shell renders. Poll until
  // at least one data row exists (or a definitive "no results" state) so we never
  // scrape an empty table → 0 rows despite a non-zero lifetime count.
  function compRowCount() {
    const cont = document.querySelector('section#flip-scroll') ||
                 document.querySelector('div.table-responsive') ||
                 document.querySelector('.shared-table') || document;
    return cont.querySelectorAll('tbody tr').length;
  }

  async function waitForCompRows(timeout = 9000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (compRowCount() > 0) return true;
      await new Promise(r => setTimeout(r, 300));
    }
    return false;
  }

  // Scrape the FULL compensation history by fetching each page's HTML directly
  // from the OP origin and parsing it. This is far more robust than clicking the
  // pager: no Turbolinks/DOM-swap timing, no stale content script, no tab state.
  // Confirmed live 2026-06-18: the server SILENTLY caps per_page at 20 — any
  // value above that (100, 500, 1000) still returns only 20 rows. We must page
  // through in 20-row increments. Dedupe by the unique compensation Id.
  async function scrapeAllCompensationPages() {
    const byKey = new Map();
    const keyOf = (r) => r.id || `${r.orderId}|${r.date}|${r.rule}|${r.amount}`;
    const perPage = 20; // server hard cap — confirmed live 2026-06-18
    const maxPages = 200; // 20 rows × 200 pages = 4000 comps max (generous ceiling)

    const userId = new URLSearchParams(window.location.search).get('by_user');

    if (userId) {
      for (let pageNum = 1; pageNum <= maxPages; pageNum++) {
        let doc = null;
        try {
          const url = `${window.location.origin}/operation/en/compensations?by_user=${encodeURIComponent(userId)}&per_page=${perPage}&page=${pageNum}&direction=desc&sort_by=id`;
          const resp = await fetch(url, { credentials: 'include' });
          if (!resp.ok) break;
          doc = new DOMParser().parseFromString(await resp.text(), 'text/html');
        } catch (_) { break; }

        const rows = scrapeCompensationTable(doc);
        let added = 0;
        for (const r of rows) {
          if (!r) continue;
          const k = keyOf(r);
          if (byKey.has(k)) continue;
          byKey.set(k, r);
          added++;
        }

        if (rows.length < perPage) break; // fewer than a full page → last page
        if (added === 0) break;           // safety: nothing new
      }
    }

    // Fallback: if the fetch path yielded nothing (no by_user in URL, auth
    // redirect, etc.), scrape whatever rows are live in the current DOM.
    if (byKey.size === 0) {
      await waitForCompRows();
      for (const r of scrapeCompensationTable()) {
        if (!r) continue;
        byKey.set(keyOf(r), r);
      }
    }

    return Array.from(byKey.values());
  }

  function getCompensationTableHeaders() {
    const tableContainer = document.querySelector('section#flip-scroll') ||
                           document.querySelector('div.table-responsive');
    if (!tableContainer) return [];

    const headerRow = tableContainer.querySelector('thead tr');
    if (!headerRow) return [];

    return Array.from(headerRow.querySelectorAll('th')).map(th => th.textContent.trim());
  }

  // ===== ORDER/USER PAGE: CUSTOMER USER LINK =====

  function getUserLink() {
    // The order/About User page links to the customer's user record at /users/{id}.
    const link = document.querySelector('a[href*="/users/"]');
    if (!link) return { userId: null, href: null };
    const m = link.href.match(/\/users\/(\d+)/);
    return { userId: m ? m[1] : null, href: link.href };
  }

  // ===== USER PAGE: DEVICES =====

  function getDeviceLinks() {
    // Prefer the devices panel, but fall back to any /devices/ link on the page
    // so a changed wrapper class doesn't zero out the traversal.
    const devicesTable = document.querySelector('div.panel-body.devices_table');
    const root = devicesTable || document;
    let links = root.querySelectorAll('a[href*="/devices/"]');
    if (links.length === 0) links = document.querySelectorAll('a[href*="/devices/"]');
    const seen = new Set();
    const out = [];
    for (const link of links) {
      const deviceId = link.href.match(/\/devices\/(\d+)/)?.[1] || null;
      if (!deviceId || seen.has(deviceId)) continue;
      seen.add(deviceId);
      out.push({ href: link.href, text: link.textContent.trim(), deviceId });
    }
    return out;
  }

  // ===== DEVICE PAGE: CONNECTED ACCOUNTS =====

  function getConnectedAccounts() {
    const userTable = document.querySelector('div.panel-body.user_table');
    const root = userTable || document;
    let links = root.querySelectorAll('a[href*="/users/"]');
    if (links.length === 0) links = document.querySelectorAll('a[href*="/users/"]');
    const seen = new Set();
    const out = [];
    for (const link of links) {
      const userId = link.href.match(/\/users\/(\d+)/)?.[1] || null;
      if (!userId || seen.has(userId)) continue;
      seen.add(userId);
      out.push({ href: link.href, text: link.textContent.trim(), userId });
    }
    return out;
  }

  // ===== USER PAGE: STATISTICS (for linked-account evaluation) =====
  // The /users/{id} "User Statistics" panel is a <dl>; note its order counts are
  // a 3-MONTH window (labelled "(3m)"), unlike the order page's lifetime stats.
  function getUserStats() {
    const data = { totalOrders: null, failedOrders: null, successfulOrders: null, userCreatedAt: null, window: '3m' };
    document.querySelectorAll('dt').forEach(dt => {
      const label = dt.textContent.trim().toLowerCase();
      const dd = dt.nextElementSibling;
      if (!dd) return;
      const num = () => parseInt(dd.textContent.replace(/[^\d]/g, ''), 10);
      if (label.includes('total orders')) { const n = num(); if (!isNaN(n) && data.totalOrders == null) data.totalOrders = n; }
      else if (label.includes('failed orders')) { const n = num(); if (!isNaN(n) && data.failedOrders == null) data.failedOrders = n; }
      else if (label.includes('successful orders')) { const n = num(); if (!isNaN(n) && data.successfulOrders == null) data.successfulOrders = n; }
      else if (label.includes('created') && !data.userCreatedAt) data.userCreatedAt = dd.textContent.trim();
    });
    return data;
  }

  // ===== VPN CHECK =====

  function isVpnActive() {
    const body = document.body?.textContent || '';
    if (body.includes('Access Denied') || body.includes('403 Forbidden') || body.includes('ERR_CONNECTION')) {
      return false;
    }
    if (document.querySelector('section#main-content') || document.querySelector('div.order-details')) {
      return true;
    }
    return document.readyState === 'complete' && body.length > 500;
  }

  // ===== PAGE READINESS / 404 DETECTION =====
  // OP occasionally serves its 404 screen ("Page Not found! The page that you've
  // requested does not exist.") when a /users, /devices or /orders id is hit a
  // beat too early (backend race). The content script is still injected on that
  // page, so a plain KEEPALIVE_PING answers "alive" and we'd scrape an empty
  // shell. These helpers let the orchestrator wait for REAL content (and reload
  // once on a genuine 404) instead of parsing early.

  function detectNotFound() {
    const body = document.body ? document.body.textContent : '';
    if (!body) return false;
    return /page\s*not\s*found/i.test(body) ||
           /requested[\s\S]{0,40}does\s*not\s*exist/i.test(body) ||
           /الصفحة\s*غير\s*موجودة/.test(body);
  }

  // Has the page actually rendered the content this page type needs?
  function isContentReady(pageType) {
    switch (pageType) {
      case 'order':
        return !!(document.querySelector('a#about_user_tab') ||
                  document.querySelector('div#about_user_tab_content') ||
                  document.querySelector('section.wrapper') ||
                  document.querySelector('div.order-details') ||
                  document.querySelector('ul.nav.nav-tabs'));
      case 'user':
        return !!(document.querySelector('a[href*="/devices/"]') ||
                  document.querySelector('div.panel-body.devices_table') ||
                  document.querySelector('dl dt'));
      case 'device':
        return !!(document.querySelector('a[href*="/users/"]') ||
                  document.querySelector('div.panel-body.user_table') ||
                  document.querySelector('dl dt'));
      case 'compensation_history':
        // Require actual rows, not just the table SHELL — the comp table renders
        // its header first and loads rows via AJAX a beat later. Gating on the
        // shell is exactly what made SCRAPE run early and return 0 rows.
        return !!(document.querySelector('section#flip-scroll tbody tr') ||
                  document.querySelector('div.table-responsive tbody tr') ||
                  document.querySelector('table.shared-table tbody tr') ||
                  document.querySelector('table tbody tr'));
      default:
        return document.readyState === 'complete';
    }
  }

  function getReadiness() {
    const pageType = getCurrentPageType();
    const notFound = detectNotFound();
    return {
      alive: true,
      pageType,
      notFound,
      contentReady: !notFound && isContentReady(pageType),
      readyState: document.readyState,
      vpnActive: isVpnActive(),
      url: window.location.href
    };
  }

  // ===== SELECTOR SELF-TEST (read-only) =====

  // Logical targets → ordered selector candidates, per page type. Reports which
  // candidate resolves on the live OP page WITHOUT navigating or clicking.
  const PROBE_SPECS = {
    order: {
      about_user_tab: ["a#about_user_tab"],
      track_history_tab: ["a#track_history_tab"],
      compensation_tab: ["a#compensation_tab"],
      about_user_content: ["div#about_user_tab_content"],
      stats_tables: ["div#about_user_tab_content table", "section.panel table", "table"],
      order_items: ["section.wrapper table tbody tr", "div.order-details table tbody tr", "div#order_items_content"],
      rider_photos: ["div#track_history_tab_content img[src*='http']", "img[src*='usehurrier']", "img[src*='s3.']"],
      comp_history_link: ["div#compensation_tab_content a.btn.btn-white[href*='/compensations']", "a[href*='/compensations']", "a[href*='by_user']"],
      user_link: ["a[href*='/users/']"],
      note_input: ["div#track_history_tab_content textarea", "form#new_note input", "input#note_content"]
    },
    compensation_history: {
      table_container: ["section#flip-scroll", "div.table-responsive", ".shared-table"],
      table: ["table.shared-table", "section#flip-scroll table", "div.table-responsive table"],
      header_cells: ["thead tr th"],
      body_rows: ["tbody tr"],
      pagination: ["div.footer-container-width", "ul.pagination"],
      next_page: ["a[rel='next']", "ul.pagination li.next a"]
    },
    user: {
      devices_table: ["div.panel-body.devices_table"],
      device_links: ["a[href*='/devices/']"]
    },
    device: {
      user_table: ["div.panel-body.user_table"],
      account_links: ["a[href*='/users/']"]
    },
    unknown: {}
  };

  function probeSelectors() {
    const pageType = getCurrentPageType();
    const spec = PROBE_SPECS[pageType] || {};
    const results = {};
    for (const [key, candidates] of Object.entries(spec)) {
      let resolved = null, count = 0, sampleText = '';
      for (const sel of candidates) {
        let els = [];
        try { els = document.querySelectorAll(sel); } catch (_) { continue; }
        if (els.length > 0) {
          resolved = sel;
          count = els.length;
          sampleText = (els[0].textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80);
          break;
        }
      }
      results[key] = { resolved: !!resolved, selector: resolved, count, sampleText };
    }
    return { system: 'operation', pageType, url: window.location.href, vpnActive: isVpnActive(), results };
  }

  // ===== MESSAGE HANDLING =====

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const pageType = getCurrentPageType();

    switch (message.type) {
      case 'CHECK_VPN':
        sendResponse({ active: isVpnActive() });
        break;

      case 'PROBE_SELECTORS':
        sendResponse(probeSelectors());
        break;

      case 'GET_PAGE_TYPE':
        sendResponse({ pageType, url: window.location.href });
        break;

      case 'NAVIGATE_TAB':
        if (pageType === 'order') {
          navigateToTab(message.payload.tab).then(ok => sendResponse({ ok }));
        } else {
          sendResponse({ ok: false, reason: 'Not on order page' });
        }
        return true;

      case 'GET_ABOUT_USER':
        sendResponse({ data: getAboutUserData() });
        break;

      case 'GET_ORDER_HIGHLIGHTS':
        sendResponse({ data: getOrderHighlights() });
        break;

      case 'GET_COMP_HISTORY_LINK':
        sendResponse({ url: getCompensationHistoryLink() });
        break;

      case 'CLICK_COMP_HISTORY':
        sendResponse({ ok: clickCompensationHistoryLink() });
        break;

      case 'SCRAPE_COMPENSATION':
        if (pageType === 'compensation_history') {
          scrapeAllCompensationPages().then(rows => sendResponse({ rows }));
        } else {
          sendResponse({ rows: [], reason: 'Not on compensation history page' });
        }
        return true;

      case 'GET_COMP_HEADERS':
        sendResponse({ headers: getCompensationTableHeaders() });
        break;

      case 'HAS_MORE_PAGES':
        sendResponse({ hasMore: hasMorePages(), nextUrl: getNextPageUrl() });
        break;

      case 'WRITE_NOTE':
        if (pageType === 'order') {
          writeNote(message.payload.text).then(ok => sendResponse({ ok }));
        } else {
          sendResponse({ ok: false, reason: 'Not on order page' });
        }
        return true;

      case 'GET_ORDER_ITEMS':
        sendResponse({ items: getOrderItems() });
        break;

      case 'GET_RIDER_PHOTOS':
        sendResponse({ photos: getRiderDeliveryPhotos() });
        break;

      case 'GET_BLOCKED_STATUS':
        sendResponse({ data: getBlockedStatus(), notFound: detectNotFound() });
        break;

      case 'GET_USER_LINK':
        sendResponse(getUserLink());
        break;

      case 'GET_DEVICES':
        if (pageType === 'user') {
          sendResponse({ devices: getDeviceLinks() });
        } else {
          sendResponse({ devices: [] });
        }
        break;

      case 'GET_USER_STATS':
        sendResponse({ data: getUserStats(), pageType });
        break;

      case 'GET_CONNECTED_ACCOUNTS':
        if (pageType === 'device') {
          sendResponse({ accounts: getConnectedAccounts() });
        } else {
          sendResponse({ accounts: [] });
        }
        break;

      case 'KEEPALIVE_PING':
        sendResponse(getReadiness());
        break;

      case 'GET_READINESS':
        sendResponse(getReadiness());
        break;
    }
    return true;
  });

  loadSelectors().then(() => {
    console.log('[FraudDetection] Operation Portal content script loaded — page type:', getCurrentPageType());
  });
})();
