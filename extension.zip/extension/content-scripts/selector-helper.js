/**
 * Selector Resilience Utility
 * Tries primary selector first, then a list of fallbacks.
 * Shared by content scripts for DOM element finding.
 */

const SelectorHelper = {
  /**
   * querySelector with fallbacks — returns the first match across all candidates.
   * @param {string[]} selectors - Array of selectors to try in order
   * @param {Element} root - Root element to search within (default: document)
   * @returns {Element|null}
   */
  queryOne(selectors, root = document) {
    if (typeof selectors === 'string') selectors = [selectors];
    for (const sel of selectors) {
      try {
        const el = root.querySelector(sel);
        if (el) return el;
      } catch (e) {
        // Invalid selector, skip
      }
    }
    return null;
  },

  /**
   * querySelectorAll with fallbacks — returns results from the first selector that matches anything.
   * @param {string[]} selectors - Array of selectors to try in order
   * @param {Element} root - Root element to search within (default: document)
   * @returns {NodeList|Element[]}
   */
  queryAll(selectors, root = document) {
    if (typeof selectors === 'string') selectors = [selectors];
    for (const sel of selectors) {
      try {
        const els = root.querySelectorAll(sel);
        if (els.length > 0) return els;
      } catch (e) {
        // Invalid selector, skip
      }
    }
    return [];
  },

  /**
   * Wait for any of the given selectors to appear in the DOM.
   * @param {string[]} selectors - Array of selectors to watch for
   * @param {number} timeout - Max wait time in ms (default 10000)
   * @returns {Promise<Element>}
   */
  waitForAny(selectors, timeout = 10000) {
    if (typeof selectors === 'string') selectors = [selectors];
    return new Promise((resolve, reject) => {
      const found = SelectorHelper.queryOne(selectors);
      if (found) return resolve(found);

      const observer = new MutationObserver(() => {
        const el = SelectorHelper.queryOne(selectors);
        if (el) { observer.disconnect(); resolve(el); }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Timeout waiting for: ${selectors.join(' | ')}`));
      }, timeout);
    });
  },

  /**
   * Find element by visible text content.
   * @param {string} tag - Tag/selector to search
   * @param {string} text - Text to match (partial, case-insensitive)
   * @param {Element} root - Root element
   * @returns {Element|null}
   */
  findByText(tag, text, root = document) {
    const elements = root.querySelectorAll(tag);
    const lower = text.toLowerCase();
    for (const el of elements) {
      if (el.textContent.trim().toLowerCase().includes(lower)) return el;
    }
    return null;
  },

  /**
   * Get computed background color category (green/orange/red).
   * @param {Element} el
   * @returns {string} 'green'|'orange'|'red'|'unknown'
   */
  getColorCategory(el) {
    if (!el) return 'unknown';
    const bg = window.getComputedStyle(el).backgroundColor;
    if (!bg || bg === 'transparent' || bg === 'rgba(0, 0, 0, 0)') return 'unknown';

    const match = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (!match) return 'unknown';
    const [, r, g, b] = match.map(Number);

    if (r > 200 && g < 100 && b < 100) return 'red';
    if (r > 200 && g > 150 && g < 230 && b < 100) return 'orange';
    if (r < 100 && g > 150 && b < 100) return 'green';
    if (r > 240 && g > 200 && b < 180) return 'orange';

    return 'unknown';
  }
};

if (typeof window !== 'undefined') {
  window.SelectorHelper = SelectorHelper;
}
