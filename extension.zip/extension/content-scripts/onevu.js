/**
 * 1VU (OneView) Content Script — runs ONLY inside the 1VU iframe
 * Handles: data extraction, risk status, contact reason, complaint type,
 * refund panel, notes, wrap-up, escalate, tab navigation.
 *
 * Split from herocare.js (2026-06-18) for clean separation of concerns.
 * DOM selectors verified against live 1VU iframe (2026-06-18).
 * See extension/config/selectors.json for the full selector map.
 */

(function() {
  'use strict';

  let selectors = {};
  const context = 'onevu_iframe';

  async function loadSelectors() {
    const response = await fetch(chrome.runtime.getURL('config/selectors.json'));
    const all = await response.json();
    selectors = all.onevu;
  }

  function registerFrame() {
    chrome.runtime.sendMessage({
      type: 'REGISTER_FRAME',
      payload: { context, frameId: -1, url: window.location.href }
    }).catch(() => {});
  }

  function randomDelay(min = 800, max = 2500) {
    return new Promise(r => setTimeout(r, min + Math.random() * (max - min)));
  }

  // ===== URL CONTEXT =====

  // The 1VU iframe URL carries the real OP order id, customer user id,
  // contact-reason code, case id, and global entity id as query params.
  // This is the single most reliable source for these ids.
  function getOneVuContext() {
    try {
      const p = new URLSearchParams(window.location.search);
      return {
        orderId: p.get('orderId') || null,
        userId: p.get('userId') || null,
        ccrCode: p.get('ccrCode') || null,
        caseId: p.get('caseId') || null,
        globalEntityId: p.get('globalEntityId') || null
      };
    } catch (_) {
      return { orderId: null, userId: null, ccrCode: null };
    }
  }

  // ===== DATA POINT EXTRACTION =====

  function getDataPointValue(datapoint) {
    const selector = selectors.dataPoints?.[datapoint];
    if (selector) {
      const el = document.querySelector(selector);
      if (el) return el.textContent.trim();
    }
    const container = document.querySelector(`[data-datapoint='${datapoint}']`);
    if (!container) return null;
    const valueEl = container.querySelector('[data-datapoint-value="true"] [class*="body"] span') ||
                    container.querySelector('span.ant-typography') ||
                    container.querySelector('[class*="body"] span') ||
                    container.querySelector('span');
    return valueEl ? valueEl.textContent.trim() : container.textContent.trim();
  }

  function getOrderData() {
    return {
      orderId: getDataPointValue('order_id'),
      paymentMethod: getDataPointValue('payment_method'),
      orderStatus: getDataPointValue('order_status'),
      vertical: getDataPointValue('vertical'),
      deliveryType: getDataPointValue('delivery_type'),
      amountPaid: getDataPointValue('amount_paid'),
      paymentStatus: getDataPointValue('payment_status'),
      createdTime: getDataPointValue('created_time'),
      country: getDataPointValue('country')
    };
  }

  function getCustomerData() {
    return {
      name: getDataPointValue('customerName'),
      email: getDataPointValue('emailId'),
      customerId: getDataPointValue('customerId'),
      phone: getDataPointValue('phoneNumber'),
      address: getDataPointValue('address')
    };
  }

  // ===== RISK STATUS =====

  function getCustomerRiskStatus() {
    // Confirmed live 2026-06-18: green/safe = check-circle icon.
    // Red/risky = exclamation-circle with red color. reject-circle-icon
    // does NOT exist in this UI.
    let isFraudulent = false;
    let color = 'green';
    let hasWarning = false;

    const exclamations = document.querySelectorAll("[data-icon='exclamation-circle'], .anticon-exclamation-circle");
    for (const icon of exclamations) {
      hasWarning = true;
      const c = (icon.getAttribute('style') || '') + ';' + window.getComputedStyle(icon).color;
      if (/255,\s*77,\s*79/.test(c) || /rgb\(2[2-5]\d,\s*[0-7]?\d,\s*[0-7]?\d\)/.test(c)) {
        isFraudulent = true;
        color = 'red';
        break;
      }
      if (/255,\s*1[0-9]\d/.test(c)) color = 'orange';
    }

    // Legacy/explicit indicators still honored if present.
    const rejectIcon = document.querySelector("[data-testid='reject-circle-icon'], [data-icon='close-circle']");
    if (rejectIcon) { isFraudulent = true; color = 'red'; }

    return { isFraudulent, color, hasWarning };
  }

  // ===== CONTACT REASON =====

  function getContactReason() {
    // Confirmed live 2026-06-18: CCR renders as <h4 class="ccr-..."> (e.g. "صنف ناقص").
    // The class is "ant-typography ccr-1-1-10 css-14b9xhs".
    const ccrEl = document.querySelector('h4[class*="ccr"]') ||
                  document.querySelector('[class*="ccr"]') ||
                  document.querySelector('[data-testid="ticket-details-contact-reason"] + * h4');
    const txt = ccrEl ? ccrEl.textContent.trim() : '';
    return txt || null;
  }

  // ===== COMPLAINT TYPE DETECTION =====

  const CCR_TO_COMPLAINT_MAP = [
    { keywords: ['missing', 'صنف ناقص', 'ناقص', 'مفقود', 'لم يصل', 'not delivered', 'missing item'], type: 'missing_item' },
    { keywords: ['wrong item', 'صنف خطأ', 'صنف خاطئ', 'صنف غير صحيح', 'غلط', 'خطأ في الصنف', 'incorrect item', 'خطأ'], type: 'wrong_item' },
    { keywords: ['wrong order', 'طلب خاطئ', 'طلب خطأ', 'طلب غلط', 'wrong bag', 'wrong restaurant'], type: 'wrong_order' },
    { keywords: ['quality', 'جودة', 'bad food', 'expired', 'منتهي', 'taste', 'طعم'], type: 'quality_issue' },
    { keywords: ['damaged', 'تالف', 'broken', 'spilled', 'مسكوب'], type: 'damaged_order' },
    { keywords: ['incomplete', 'partial', 'جزئي', 'not complete'], type: 'incomplete_order' }
  ];

  function mapCCRToComplaintType(ccr) {
    if (!ccr) return null;
    const lower = ccr.toLowerCase();
    for (const mapping of CCR_TO_COMPLAINT_MAP) {
      if (mapping.keywords.some(kw => lower.includes(kw))) {
        return mapping.type;
      }
    }
    return null;
  }

  // ===== CUSTOMER PROOF =====

  function getCustomerProofUrl() {
    const proofEl = document.querySelector(selectors.dataPoints?.customerProof || "[data-datapoint='customer_proof']");
    if (!proofEl) return null;
    const link = proofEl.querySelector('a[href]');
    return link ? link.href : null;
  }

  // ===== TAB NAVIGATION =====

  // Live DOM 2026-06-18: tabs are DIVs with [data-node-key] and class
  // `ant-tabs-tab` / `ant-tabs-tab-active`. Keys: ticket, orders, profile,
  // activity. aria-selected is ALWAYS null — use class-based active detection.
  async function clickTab(tabName) {
    // Normalize common aliases to the actual data-node-key values
    const keyMap = {
      ticket: 'ticket',
      orders: 'orders',
      'user-account': 'profile',
      userAccount: 'profile',
      profile: 'profile',
      notes: 'activity',
      activity: 'activity'
    };
    const nodeKey = keyMap[tabName] || tabName;

    // Primary: click by data-node-key (most reliable, confirmed live)
    const tab = document.querySelector(`[data-node-key='${nodeKey}']`);
    if (tab) {
      if (tab.classList.contains('ant-tabs-tab-active')) return true; // already active
      tab.click();
      await randomDelay(500, 1200);
      return true;
    }

    // Fallback: try selectors.json config
    const tabNameMap = {
      ticket: 'ticketTab',
      orders: 'ordersTab',
      profile: 'userAccountTab',
      activity: 'notesTab'
    };
    const mappedName = tabNameMap[nodeKey] || tabName;
    const tabSelector = selectors.tabs?.[mappedName] || selectors.navigation?.[mappedName];
    if (tabSelector) {
      const el = document.querySelector(tabSelector);
      if (el) { el.click(); await randomDelay(500, 1200); return true; }
    }

    return false;
  }

  // The order/customer datapoints and the refund/compensation action buttons
  // only MOUNT on the 1VU "orders" tab. Activate it before reading those or
  // clicking refund. Confirmed live 2026-06-18.
  //
  // BUG FIX: aria-selected is ALWAYS null on live 1VU tabs. The active tab is
  // identified by the Ant Design class `ant-tabs-tab-active` on the
  // [data-node-key] DIV element itself.
  async function ensureOrdersTab() {
    const tab = document.querySelector("[data-node-key='orders']");
    if (tab && !tab.classList.contains('ant-tabs-tab-active')) {
      tab.click();
      await randomDelay(800, 1400);
    }
  }

  function ensureTab(tabKey) {
    const tab = document.querySelector(`[data-node-key='${tabKey}']`);
    if (tab && !tab.classList.contains('ant-tabs-tab-active')) {
      tab.click();
      return true;
    }
    return false;
  }

  // ===== ACTION BUTTONS =====

  function findRadioByText(root, text) {
    return [...root.querySelectorAll('.ant-radio-wrapper')].find(
      w => (w.textContent || '').replace(/\s+/g, ' ').trim().includes(text)
    ) || null;
  }

  // Full fraud wrap-up / close flow (confirmed live 2026-06-19):
  //   open the wrap-up drawer → تعديل (Edit) → "Wrap as" = إغلاق →
  //   set "السماح بالرد" (allow reply) → Submit.
  // The drawer is an ant-drawer; the radio group is enabled only after Edit, and
  // Submit only enables once the disposition is valid.
  async function clickWrapUp() {
    const openSel = selectors.actions?.closeTicketButton || "[data-test-id='dh.herocare.wrap-up-plugin']";
    const openBtn = document.querySelector(openSel) ||
                    (window.SelectorHelper && window.SelectorHelper.findByText('button', 'انهاء التذكرة'));
    if (!openBtn) return { ok: false, reason: 'wrap-up button not found' };
    openBtn.click();
    await randomDelay(1000, 1800);

    const drawer = document.querySelector('.ant-drawer-content');
    if (!drawer) return { ok: false, reason: 'wrap-up drawer did not open' };

    // Enter edit mode (تعديل / Edit) so the "Wrap as" radios become enabled.
    const editBtn = [...drawer.querySelectorAll('button')].find(b => /تعديل|edit/i.test((b.textContent || '').trim()));
    if (editBtn) { editBtn.click(); await randomDelay(700, 1300); }

    // Choose "Wrap as: إغلاق" (close).
    let closeRadio = findRadioByText(drawer, 'إغلاق');
    if (closeRadio) {
      const input = closeRadio.querySelector('input[type="radio"]') || closeRadio;
      input.click();
      await randomDelay(500, 1000);
    } else {
      return { ok: false, reason: 'إغلاق (close) option not found in wrap-up drawer' };
    }

    // Set "السماح بالرد" (allow reply). It may be a radio/checkbox or a select
    // depending on the chosen disposition — handle all three.
    const allowText = 'السماح بالرد';
    const allowRadio = findRadioByText(drawer, allowText) || findRadioByText(drawer, 'السماح');
    if (allowRadio) {
      (allowRadio.querySelector('input') || allowRadio).click();
    } else {
      const allowChk = [...drawer.querySelectorAll('.ant-checkbox-wrapper')].find(c => /السماح/.test(c.textContent || ''));
      if (allowChk) { (allowChk.querySelector('input') || allowChk).click(); }
      else {
        // try an empty disposition select labelled around "السماح"/reply
        const sel = [...drawer.querySelectorAll('.ant-select')].find(s => /السماح|رد|reply|-/.test((s.textContent || '').trim()));
        if (sel) await selectAntOptionByText(sel, allowText);
      }
    }
    await randomDelay(500, 1000);

    // Submit.
    const submitBtn = drawer.querySelector("button[data-test-id='submit-button']") ||
                      [...drawer.querySelectorAll('button')].find(b => /submit|تأكيد|حفظ/i.test((b.textContent || '').trim()));
    if (!submitBtn) return { ok: false, reason: 'Submit button not found in wrap-up drawer' };
    if (submitBtn.disabled) return { ok: false, reason: 'Submit still disabled (disposition incomplete — manual wrap-up needed)' };
    submitBtn.click();
    await randomDelay(1200, 2000);
    return { ok: true };
  }


  async function clickNewComment() {
    // Confirmed live 2026-06-18: data-test-id='new_comment'
    const btn = document.querySelector(selectors.actions?.addCommentButton || "[data-test-id='new_comment']");
    if (btn) { btn.click(); return true; }
    return false;
  }

  async function clickFullRefund() {
    await ensureOrdersTab();
    const btn = document.querySelector(selectors.actions?.fullRefundButton || "[data-test-id='full_refund']");
    if (btn) { btn.click(); return true; }
    return false;
  }

  async function clickPartialRefund() {
    await ensureOrdersTab();
    const btn = document.querySelector(selectors.actions?.partialRefundButton || "[data-test-id='partial_refund']");
    if (btn) { btn.click(); return true; }
    return false;
  }

  async function clickCompensation() {
    await ensureOrdersTab();
    const btn = document.querySelector(selectors.actions?.compensationButton || "[data-test-id='compensation']");
    if (btn) { btn.click(); return true; }
    return false;
  }

  // ===== REFUND PANEL =====

  async function selectAntOptionByText(selectEl, searchText) {
    if (!selectEl) return false;
    const normalizedSearch = searchText.toLowerCase().trim();
    selectEl.click();
    await randomDelay(400, 700);

    // Wait for dropdown to render
    let options = [];
    for (let attempt = 0; attempt < 10; attempt++) {
      options = Array.from(document.querySelectorAll('.ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option-content'));
      if (options.length > 0) break;
      await randomDelay(100, 200);
    }

    for (const opt of options) {
      const optText = opt.textContent.trim().toLowerCase();
      if (optText === normalizedSearch ||
          optText.includes(normalizedSearch) ||
          normalizedSearch.includes(optText)) {
        opt.closest('.ant-select-item-option')?.click();
        await randomDelay(300, 500);
        return true;
      }
    }

    // If no match, close dropdown by pressing Escape
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    return false;
  }

  async function processRefund(reasonCode, compensationCode, amount) {
    await ensureOrdersTab();

    let openBtn = document.querySelector(selectors.actions?.compensationButton || "[data-test-id='compensation']");
    if (!openBtn) {
      openBtn = document.querySelector(selectors.actions?.fullRefundButton || "[data-test-id='full_refund']");
    }
    if (!openBtn) return { ok: false, reason: 'Refund/compensation button not found (orders tab not loaded?)' };

    openBtn.click();
    await randomDelay(1200, 2000);

    const selects = Array.from(document.querySelectorAll(selectors.refundPanel?.selects || '.ant-select'));

    const reasonKeywords = {
      missing_item: ['صنف ناقص', 'missing', 'ناقص', 'مفقود'],
      wrong_item: ['صنف خاطئ', 'wrong item', 'خاطئ'],
      wrong_order: ['طلب خاطئ', 'wrong order', 'طلب غلط'],
      quality: ['جودة', 'quality', 'طعم', 'taste'],
      damaged: ['تالف', 'damaged', 'مكسور'],
      incomplete: ['ناقص', 'incomplete', 'غير مكتمل']
    };

    const compKeywords = {
      sorry_missing: ['صنف ناقص', 'missing', 'ناقص'],
      sorry_wrong_item: ['صنف خاطئ', 'wrong item'],
      sorry_wrong_order: ['طلب خاطئ', 'wrong order'],
      sorry_quality: ['جودة', 'quality'],
      sorry_damaged: ['تالف', 'damaged'],
      sorry_incomplete: ['ناقص', 'incomplete']
    };

    // Set refund reason
    let reasonSet = false;
    for (const select of selects) {
      if (reasonSet) break;
      const current = select.textContent.trim();
      if (current.includes('محفظة') || current.includes('wallet') || current.includes('بنك') || current.includes('bank')) continue;
      const keywords = reasonKeywords[reasonCode] || [reasonCode];
      for (const kw of keywords) {
        if (await selectAntOptionByText(select, kw)) { reasonSet = true; break; }
      }
    }

    // Set compensation reason
    let compSet = false;
    for (const select of selects) {
      if (compSet) break;
      const current = select.textContent.trim();
      if (current.includes('محفظة') || current.includes('wallet') || current.includes('بنك') || current.includes('bank')) continue;
      if (['-', 'حدد اختيارا', 'select'].some(def => current === def || current.includes(def))) {
        const keywords = compKeywords[compensationCode] || [compensationCode];
        for (const kw of keywords) {
          if (await selectAntOptionByText(select, kw)) { compSet = true; break; }
        }
      }
    }

    // Set payment destination to wallet (default safest)
    let destinationSet = false;
    for (const select of selects) {
      if (destinationSet) break;
      const current = select.textContent.trim().toLowerCase();
      if (current.includes('محفظة') || current.includes('wallet') || current.includes('بنك') || current.includes('bank') || current.includes('حدد اختيارا')) {
        if (await selectAntOptionByText(select, 'محفظة') || await selectAntOptionByText(select, 'wallet')) {
          destinationSet = true;
        }
      }
    }

    // Set compensation amount
    if (amount) {
      const amountInput = Array.from(document.querySelectorAll('input')).find(i => {
        const p = i.parentElement?.textContent?.toLowerCase() || '';
        return (i.type === 'number' || i.type === 'text') &&
               (p.includes('amount') || p.includes('مبلغ') || p.includes('تعويض') || p.includes('compensation'));
      });
      if (amountInput) {
        amountInput.focus();
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        if (nativeSetter) nativeSetter.call(amountInput, String(amount));
        else amountInput.value = String(amount);
        amountInput.dispatchEvent(new Event('input', { bubbles: true }));
        amountInput.dispatchEvent(new Event('change', { bubbles: true }));
        await randomDelay(300, 500);
      }
    }

    // Submit
    const saveText = selectors.refundPanel?.saveButtonText || 'حفظ';
    const submitBtn = (window.SelectorHelper && window.SelectorHelper.findByText('button', saveText)) ||
                      document.querySelector('button.ant-btn-primary');
    if (!submitBtn) return { ok: false, reason: 'Save button not found' };
    submitBtn.click();
    await randomDelay(1500, 2500);

    const successIndicator = document.querySelector('.ant-message-success, [class*="success"]');
    const errorIndicator = document.querySelector('.ant-message-error, [class*="error"]');
    return {
      ok: true,
      confirmed: !!successIndicator,
      error: errorIndicator ? errorIndicator.textContent?.trim() : null
    };
  }

  // ===== NOTES =====

  async function writeNote(text) {
    // The "أضف تعليق" (add comment) button is a top-level action button
    // (data-test-id='new_comment') visible on ALL tabs — no tab switch needed.
    const addCommentBtn = document.querySelector(selectors.notes?.addCommentButton || "[data-test-id='new_comment']") ||
                          (window.SelectorHelper && window.SelectorHelper.findByText('button', 'أضف تعليق'));
    if (addCommentBtn) {
      addCommentBtn.click();
      await randomDelay(500, 900);
    }

    const noteInput = document.querySelector(selectors.notes?.noteInput || 'textarea[placeholder="تعليق جديد"]') ||
                      document.querySelector('textarea[placeholder*="تعليق"]') ||
                      document.querySelector('textarea');
    if (!noteInput) return false;

    noteInput.focus();
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
    if (setter) setter.call(noteInput, text); else noteInput.value = text;
    noteInput.dispatchEvent(new Event('input', { bubbles: true }));
    noteInput.dispatchEvent(new Event('change', { bubbles: true }));
    await randomDelay(300, 500);

    const saveBtn = document.querySelector(selectors.notes?.saveNoteButton || '') ||
                    (window.SelectorHelper && window.SelectorHelper.findByText('button', 'حفظ'));
    if (saveBtn) { saveBtn.click(); return true; }
    return false;
  }

  // ===== SELECTOR SELF-TEST (read-only) =====

  const PROBE_SPEC = {
    risk_safe_icon: ["[data-icon='check-circle']"],
    risk_blocked_icon: ["[data-icon='close-circle']"],
    risk_warning_icon: ["[data-icon='exclamation-circle']", ".anticon-exclamation-circle"],
    ccr_heading: ["h4[class*='ccr']", "[class*='ccr']"],
    order_display_value: ["[data-testid$='-display-value']"],
    contact_reason_label: ["[data-testid='ticket-details-contact-reason']"],
    escalate_button: ["[data-testid='escalate-button']"],
    hold_button: ["[data-testid='hold-ticket-button']"],
    other_tickets: ["[data-testid='other-tickets-container']"],
    datapoint_any: ["[data-datapoint]"],
    customer_proof: ["[data-datapoint='customer_proof']"],
    refund_button: ["[data-test-id='full_refund']", "[data-test-id='partial_refund']"],
    compensation_button: ["[data-test-id='compensation']"],
    new_comment: ["[data-test-id='new_comment']"],
    wrap_up: ["[data-test-id='dh.herocare.wrap-up-plugin']"],
    ant_selects: [".ant-select"],
    note_input: ["textarea[placeholder='تعليق جديد']", "textarea[placeholder*='تعليق']", "textarea"],
    note_save: ["button.ant-btn-primary"],
    tabs: ["[data-node-key]"],
    active_tab: [".ant-tabs-tab-active"]
  };

  function probeSelectors() {
    const results = {};
    for (const [key, candidates] of Object.entries(PROBE_SPEC)) {
      let resolved = null, count = 0, sampleText = '';
      for (const sel of candidates) {
        let els = [];
        try { els = document.querySelectorAll(sel); } catch (_) { continue; }
        if (els.length > 0) {
          resolved = sel;
          count = els.length;
          sampleText = (els[0].textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80);
          break;
        }
      }
      results[key] = { resolved: !!resolved, selector: resolved, count, sampleText };
    }
    return { context, url: window.location.href, results };
  }

  // ===== MESSAGE HANDLING =====

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case 'REGISTER_FRAME':
        sendResponse({ context, url: window.location.href, ok: true });
        break;

      case 'PROBE_SELECTORS':
        sendResponse(probeSelectors());
        break;

      case 'GET_ONEVU_CONTEXT':
        sendResponse(getOneVuContext());
        break;

      case 'GET_ORDER_DATA':
        sendResponse({ data: getOrderData() });
        break;

      case 'GET_CUSTOMER_DATA':
        sendResponse({ data: getCustomerData() });
        break;

      case 'GET_RISK_STATUS':
        sendResponse({ data: getCustomerRiskStatus() });
        break;

      case 'GET_CONTACT_REASON':
        sendResponse({ data: getContactReason() });
        break;

      case 'GET_COMPLAINT_TYPE': {
        const ccr = getContactReason();
        const ccrCode = getOneVuContext().ccrCode;
        let type = mapCCRToComplaintType(ccr) ||
                   (message.payload?.text ? mapCCRToComplaintType(message.payload.text) : null) ||
                   (ccrCode ? mapCCRToComplaintType(ccrCode) : null);
        sendResponse({ type, rawCCR: ccr || message.payload?.text || null, ccrCode: ccrCode || null });
        break;
      }

      case 'GET_CUSTOMER_PROOF':
        sendResponse({ url: getCustomerProofUrl() });
        break;

      case 'CLICK_TAB':
        clickTab(message.payload.tab).then(ok => sendResponse({ ok }));
        return true;

      case 'WRAP_UP_TICKET':
        clickWrapUp().then(res => sendResponse(res)).catch(e => sendResponse({ ok: false, reason: e.message }));
        return true;


      case 'CLICK_NEW_COMMENT':
        clickNewComment().then(ok => sendResponse({ ok }));
        return true;

      case 'CLICK_FULL_REFUND':
        clickFullRefund().then(ok => sendResponse({ ok }));
        return true;

      case 'CLICK_PARTIAL_REFUND':
        clickPartialRefund().then(ok => sendResponse({ ok }));
        return true;

      case 'CLICK_COMPENSATION':
        clickCompensation().then(ok => sendResponse({ ok }));
        return true;

      case 'WRITE_NOTE':
        writeNote(message.payload.text).then(ok => sendResponse({ ok }));
        return true;

      case 'PROCESS_REFUND':
        processRefund(
          message.payload.reasonCode,
          message.payload.compensationCode,
          message.payload.amount
        ).then(result => sendResponse(result));
        return true;

      case 'KEEPALIVE_PING':
        sendResponse({ alive: true, context, url: window.location.href });
        break;
    }
    return true;
  });

  loadSelectors().then(() => {
    console.log('[FraudDetection] 1VU content script loaded', {
      context,
      url: window.location.href,
      orderId: getOneVuContext().orderId,
      userId: getOneVuContext().userId
    });
    registerFrame();
  });
})();
